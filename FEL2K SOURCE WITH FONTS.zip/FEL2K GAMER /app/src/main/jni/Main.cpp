#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <iomanip>

#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "Includes/MonoString.h"
#include "Includes/Strings.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "Addrtools.h"
//Target lib here
#define targetLibName OBFUSCATE("libnba2k20_clean_opt.so")
#define targetRange OBFUSCATE("libc_malloc")

#include "Includes/Macros.h"


struct My_Patches {
   
    MemoryPatch Skins1,Skins2,Skins3,Skins4,Skins5,Skins6,Skins7,Portrait1,Portrait2,Portrait3,Portrait4,Portrait5,Portrait6,Portrait7,Hdacs,Hdacs2,Green1,Green2,Green3,Green4,Colors1,Colors2,Colors3,Colors4,Skin1,Skin2,Skin3,Skin4,Haircolor1,Haircolor2,Haircolor3,Haircolor4,Wings,Wings2,Wings3,Wings4,Wings5,Wings6,Wings7,Coins1,Coins2,Coins3,Coins4,Cloths1,Cloths2,Cloths3,Cloths4,Cloths5,Hdingame,Color1,Color2,Color3,Neon1,Neon2,Neon3,Fastdunk1,Fastdunk2,Fastdunk3,Fastdunk4,Fastdunk5,Fastdunk6,Fastdunk7,Fastlayup1,Fastlayup2,Fastlayup3,Fastlayup4,Fastlayup5,Fastlayup6,Fastlayup7,Hangtime1,Hangtime2,Hangtime3,Hangtime4,Hangtime5,Hangtime6,Hangtime7,Black1,Black2,Black3,Black4,Black5,Black6,Black7,Black8,Black9,Black10,Black11,Adjuster1,Adjuster2,Adjuster3,Adjuster4,Adjuster5,Adjuster6,Adjuster7,Adjuster8,Adjuster9,Adjuster10,Adjuster11,Adjuster12,Adjuster13,Adjuster14,Adjuster15,Adjuster16,Adjuster17,Adjuster18,Adjuster19,Adjuster20,Adjuster21,Adjuster22,Adjuster23,Adjuster24,Adjuster25,Adjuster26,Adjuster27,Adjuster28,Adjuster29,Adjuster30,Adjuster31,Adjuster32,Adjuster33,Adjuster34,Adjuster35,Adjuster36,Adjuster37,Adjuster38,Adjuster39,Adjuster40,Adjuster41,HdPort,All,Jdskin,Jdskin2,Jdskin3,Jdskin4,Jdskin5,Jdskin6,Euro,Euro2,Euro3,Euro4,Blackball1,Blackball2,Blackball3,Blackball4,Worldball1,Worldball2,Worldball3,Worldball4,Ababall1,Cam1,Cam2,Cam3,Cam4,Cam5,Cam6,Cam7,Cam8,Cam9,Cam10,Shot,Commentator,Speed1,Speed2,Speed3,Speed4,Vertical1,Vertical2,Vertical3,Vertical4,Anklebreaker1,Anklebreaker2,Anklebreaker3,Anklebreaker4,Anklebreaker5,Anklebreaker6,Anklebreaker7,Anklebreaker8,Dribble,Dribble2,Dribble3,Dribble4,Sweat,Sweat2,Sweat3,Sweat4,Sweat5,Sweat6,Sweat7,Sweat8,Sweat9,Sweat10,Sweat11,Player1,Player2,Player3,Player4,Player5,Player6,Player7,Player8,Player9,Player10,Player11,Player12,Player13,Player14,Player15,Player16,Player17,Player18,Player19,Player20,Player21,Player22,Player23,Player24,Player25,Player26,Player27,Player28,Player29,Player30,Player31,Player32,Player33,Player34,Player35,Player36,Player37,Player38,Player39,Player40,Player41,Player42,Player43,Player44,Player45,Player46,Player47,Player48,Player49,Player50,Player51,Player52,Player53,Player54,Player55,Player56,Player57,Player58,Player59,Player60,Player61,Player62,Player63,Player64,Player65,Player66,Player67,Player68,Player69,Player70,Player71,Player72,Player73,Player74,Player75,Player76,Player77,Player78,Player79,Player80,Player81,Player82,Player83,Player84,Player85,Player86,Player87,Player88,Player89,Player90,Player91,Player92,Player93,Player94,Player95,Player96,Player97,Player98,Player99,Player100,Player101,Player102,Player103,Player104,Player105,Player106,Player107,Player108,Player109,Player110,Player111,Player112,Player113,Player114,Player115,Player116,Player117,Player118,Player119,Player120,Player121,Player122,Player123,Player124,Player125,Player126,Player127,Player128,Player129,Player130,Player131,Player132,Player133,Player134,Player135,Player136,Player137,Player138,Player139,Player140,Player141,Player142,Player143,Player144,Player145,Player146,Player147,Player148,Player149,Player150,Player151,Player152,Player153,Player154,Player155,Player156,Player157,Player158,Player159,Player160,Player161,Player162,Player163,Player164,Player165,Player166,Player167,Player168,Player169,Player170,Player171,Player172,Player173,Player174,Player175,Player176,Player177,Player178,Player179,Player180,Player181,Player182,Player183,Player184,Player185,Player186,Player187,Player188,Player189,Player190,Player191,Player192,Player193,Player194,Player195,Player196,Player197,Player198,Player199,Player200,Player201,Player202,Player203,Player204,Player205,Player206,Player207,Player208,Player209,Player210,Player211,Player212,Player213,Player214,Player215,Player216,Player217,Player218,Player219,Player220,Player221,Player222,Player223,Player224,Player225,Player226,Player227,Player228,Player229,Player230,Player231,Player232,Player233,Player234,Player235,Player236,Player237,Player238,Player239,Player240,Player241,Player242,Player243,Player244,Player245,Player246,Player247,Player248,Player249,Player250,Player251,Player252,Player253,Player254,Player255,Player256;
    
} hexPatches;

bool hd4,skin1,skin2,skin3,skin4,skin5,skin6,skin7,portrait,portrait2,portrait3,portrait4,portrait5,portrait6,portrait7,hds,feature56,feature57,feature58,feature59,wings1,wings2,wings3,wings4,wings5,wings6,wings7,coins,crwd,crwd2,crwd3,crwd4,crwd5,ingam,feature27,feature28,feature29,feature30,feature31,feature32,layup,fastdunk,feature52,feature21,feature1,feature2,feature3,feature4,feature5,feature6,feature7,feature8,feature9,feature10,feature11,feature12,feature13,feature14,feature15,hdpor,all,hdsk,euro,black,world,aba,cam1,cam2,cam3,cam4,cam5,cam6,cam7,cam8,cam9,cam10,shot,com,speed,speed2,speed3,speed4,vert,vert2,vert3,vert4,anklebreak,dribble,dribble2,dribble3,dribble4,sweat,player;
         std::string originalFaceID;
         std::string originalFaceID1;
         std::string originalFaceID2;
		 std::string ace;
		 std::string ace2;
		 std::string ace3;
		 std::string ace4;
		 std::string ace5;
		 std::string ace6;
		 std::string ace7;
		 std::string ace8;
		 std::string ace9;
		 std::string ace10;
		 std::string ace11;
		 std::string ace12;
		 std::string ace13;
		 std::string ace14;
		 std::string ace15;
		 std::string ace16;
		 std::string stats1;
		 std::string stats2;
		 std::string stats3;
		 std::string stats4;
		 std::string stats5;
		 std::string stats6;
		 std::string stats7;
		 std::string stats8;
		 std::string stats9;
		 std::string stats10;
		 std::string stats11;
		 std::string stats12;
		 std::string stats13;
		 std::string stats14;
		 std::string stats15;
		 std::string stats16;
		 std::string stats17;
		 std::string stats18;
		 std::string stats19;
		 std::string stats20;
		 std::string stats21;
		 std::string stats22;
		 std::string stats23;
		 std::string stats24;
		 std::string attribute;
		 std::string attribute2;
		 std::string attribute3;
		 std::string attribute4;
		 std::string attribute5;
		 std::string attribute6;
		 std::string attribute7;
		 std::string attribute8;
		 std::string attribute9;
		 std::string attribute10;
		 std::string attribute11;
		 std::string attribute12;
		 std::string attribute13;
		 std::string attribute14;
		 std::string attribute15;
		 std::string attribute16;
		 std::string attribute17;
		 std::string attribute18;
		 std::string attribute19;
		 std::string attribute20;
		 std::string attribute21;
		 std::string attribute22;
		 std::string attribute23;
		 std::string attribute24;
		 std::string attribute25;
		 std::string attribute26;
		 std::string attribute27;
		 std::string attribute28;
		 std::string attribute29;
		 std::string attribute30;
		 std::string attribute31;
		 std::string attribute32;
		 std::string attribute33;
		 std::string attribute34;
		 std::string attribute35;
		 std::string attribute36;
		 std::string attribute37;
		 std::string attribute38;
		 std::string attribute39;
		 std::string attribute40;
		 std::string attribute41;
		 std::string tendencies;
		 std::string tendencies2;
		 std::string tendencies3;
		 std::string tendencies4;
		 std::string tendencies5;
		 std::string tendencies6;
		 std::string tendencies7;
		 std::string tendencies8;
		 std::string tendencies9;
		 std::string tendencies10;
		 std::string tendencies11;
		 std::string tendencies12;
		 std::string tendencies13;
		 std::string tendencies14;
		 std::string tendencies15;
		 std::string tendencies16;
		 std::string tendencies17;
		 std::string tendencies18;
		 std::string tendencies19;
		 std::string tendencies20;
		 std::string tendencies21;
		 std::string tendencies22;
		 std::string tendencies23;
		 std::string tendencies24;
		 std::string tendencies25;
		 std::string tendencies26;
		 std::string tendencies27;
		 std::string tendencies28;
		 std::string tendencies29;
		 std::string tendencies30;
		 std::string tendencies31;
		 std::string tendencies32;
		 std::string tendencies33;
		 std::string tendencies34;
		 std::string tendencies35;
		 std::string tendencies36;
		 std::string tendencies37;
		 std::string tendencies38;
		 std::string tendencies39;
		 std::string tendencies40;
		 std::string tendencies41;
		 std::string tendencies42;
		 std::string tendencies43;
		 std::string tendencies44;
		 std::string tendencies45;
		 std::string tendencies46;
		 std::string tendencies47;
		 std::string tendencies48;
		 std::string tendencies49;
		 std::string tendencies50;
		 std::string tendencies51;
		 std::string tendencies52;
		 std::string tendencies53;
		 std::string tendencies54;
		 std::string tendencies55;
		 std::string tendencies56;
		 std::string tendencies57;
		 std::string tendencies58;
		 std::string tendencies59;
		 
     
          
std::string ReadMemoryAsHex(uintptr_t address, size_t size) {
    uint8_t buffer[size];
    memcpy(buffer, (void *)address, size);
    std::stringstream ss;
    for (size_t i = 0; i < size; i++) {
        ss << std::hex << std::setw(2) << std::setfill('0') << (int)buffer[i];
    }
    return ss.str();
}

/*
typedef void (*OriginalFuncType)(int, int, int, int, int);
OriginalFuncType OriginalFunc;
void Hooked_CreateDate(int arg1, int month, int arg2, int arg3, int arg4) {
     arg1 += 5; 
 //  arg2 += 5;
  month += 3;
// arg3 += 1;
 // arg4 += 1;
    OriginalFunc(arg1, month, arg2, arg3, arg4);
}

*/
typedef void (*AI_SetAllMascotVisibility_t)(bool speed);
AI_SetAllMascotVisibility_t originalAI_SetAllMascotVisibility;
// Hooked version of the function
void hookedAI_SetAllMascotVisibility(bool speed) {
     if(speed){
    speed = true;  
    }
    originalAI_SetAllMascotVisibility(speed);
}




/*
typedef void (*OriginalSetCourtID)(int courtID);
OriginalSetCourtID originalSetCourtID;

// Hooked function
void HookedSetCourtID(int courtID) {
    LOGD("Hooked: Blacktop_SetCourtID called with courtID: %d", courtID);

   if(court){ 
}
    originalSetCourtID(courtID);
}


*/



// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__)
 
//hook((void *)getAbsoluteAddress(OBFUSCATE("libnba2k20_clean_opt.so"), string2Offset(OBFUSCATE("0x0173ba5c"))), (void *)&HookedSetCourtID, (void **)&originalSetCourtID);
hexPatches.Hdacs = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2035020,"00 00 00 00"); 
 hexPatches.Hdacs2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x203503c,"00 00 00 00");

hexPatches.Green1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104824,"00 00 c0 40"); 
 hexPatches.Green2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104828,"00 00 c0 40");
 hexPatches.Green3 =MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104944,"00 00 c0 40"); 
 hexPatches.Green4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104948,"00 00 c0 40");
 
 hexPatches.Colors1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104824,"00 00 20 41"); 
 hexPatches.Colors2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104828,"00 00 20 41");
 hexPatches.Colors3 =MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104944,"00 00 20 41"); 
 hexPatches.Colors4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104948,"00 00 20 41");
 
 hexPatches.Skin1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104824,"00 00 50 41"); 
 hexPatches.Skin2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104828,"00 00 50 41");
 hexPatches.Skin3 =MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104944,"00 00 50 41"); 
 hexPatches.Skin4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104948,"00 00 50 41");
 
 hexPatches.Haircolor1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20e523e,"f8 2a"); 
 hexPatches.Haircolor2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20e5240,"f8 2a");
 hexPatches.Haircolor3 =MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20e5242,"f8 2a"); 
 hexPatches.Haircolor4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20e5244,"f8 2a");
 

hexPatches.Coins1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2B20320,"C0 BD F0 FF");
  hexPatches.Coins2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2B20324,"C0 BD F0 FF");
  hexPatches.Coins3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2B20328,"C0 BD F0 FF");
  hexPatches.Coins4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2B2032C,"C0 BD F0 FF");
  
  hexPatches.Wings = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 E0 40");
  hexPatches.Wings2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 00 41");
  hexPatches.Wings3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 10 41");
  hexPatches.Wings4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 20 41");
  hexPatches.Wings5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 30 41");
  hexPatches.Wings6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 40 41");
  hexPatches.Wings7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20DB184,"00 00 50 41");
  


hexPatches.Cloths2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f917c0,"52 49 9d 39");
 
 hexPatches.Cloths3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f917c0,"c0 17 49 96 73");
 
 hexPatches.Cloths4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f917c0,"00 00 00 41");
 
 hexPatches.Cloths5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f917c0,"29 5c 8f 3d");
     
 hexPatches.Color1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20d4110,"00 00 80 bf");
 
 hexPatches.Color2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20d4114,"00 00 80 3f");
 
 hexPatches.Color3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20d4118,"00 00 80 3f");
 
 hexPatches.Neon1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20d4110,"80 96 18 4b");
 
 hexPatches.Neon2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20d4114,"00 00 7a 44");
 
 hexPatches.Neon3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20d4118,"80 96 18 4b");
 
    hexPatches.Fastdunk1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d0,"00 00 c0 3f");
    hexPatches.Fastdunk2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d4,"00 00 00 40");
    hexPatches.Fastdunk3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d8,"00 00 00 40");
    hexPatches.Fastdunk4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151dc,"00 00 00 40");
    hexPatches.Fastdunk5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e0,"00 00 00 40");
    hexPatches.Fastdunk6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e4,"00 00 00 40");
    hexPatches.Fastdunk7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e8,"00 00 00 40"); 
    
    hexPatches.Fastlayup1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d0,"00 00 c0 3f");
    hexPatches.Fastlayup2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d4,"00 00 00 40");
    hexPatches.Fastlayup3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d8,"00 00 00 40");
    hexPatches.Fastlayup4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151dc,"00 00 00 40");
    hexPatches.Fastlayup5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e0,"00 00 00 40");
    hexPatches.Fastlayup6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e4,"00 00 00 40");
    hexPatches.Fastlayup7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e8,"00 00 00 40"); 
    

hexPatches.Hangtime1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d0,"9a 99 19 3f");
    hexPatches.Hangtime2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d4,"9a 99 19 3f");
    hexPatches.Hangtime3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151d8,"9a 99 19 3f");
    hexPatches.Hangtime4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151dc,"9a 99 19 3f");
    hexPatches.Hangtime5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e0,"9a 99 19 3f");
    hexPatches.Hangtime6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e4,"9a 99 19 3f");
    hexPatches.Hangtime7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20151e8,"9a 99 19 3f"); 
    

 hexPatches.Black1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"0");
 hexPatches.Black2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160380,"00 00 be 42");
 hexPatches.Black3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160384,"00 00 48 c2");
 hexPatches.Black4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160388,"00 00 b4 c2");
 hexPatches.Black5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216038c,"00 00 a0 c2");
 hexPatches.Black6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160390,"00 00 a0 42");
 hexPatches.Black7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 a0 c1");
 hexPatches.Black8 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160398,"00 00 b4 42");
 hexPatches.Black9 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216039c,"00 00 20 c1");
 hexPatches.Black10 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21603a0,"00 00 20 c1");
 hexPatches.Black11 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21603a4,"00 00 20 41");
 
 hexPatches.Adjuster1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160384,"00 00 10 41");

hexPatches.Adjuster2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 80 40");
hexPatches.Adjuster3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 00 40");
hexPatches.Adjuster4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"0");

hexPatches.Adjuster5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160384,"00 00 20 41"); 

hexPatches.Adjuster6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 80 bf");
hexPatches.Adjuster7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 00 40");
hexPatches.Adjuster8 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"0");

hexPatches.Adjuster9 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 10 41");
hexPatches.Adjuster10 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 00 c0");
hexPatches.Adjuster11 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"0");

hexPatches.Adjuster12 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 40 c0");
hexPatches.Adjuster13 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"33 33 83 40");
hexPatches.Adjuster14 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"66 66 86 40");

hexPatches.Adjuster15 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 40 c0");
hexPatches.Adjuster16 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"33 33 83 40");
hexPatches.Adjuster17 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 80 3f");

hexPatches.Adjuster18 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 80 bf");
hexPatches.Adjuster19 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 00 40");
hexPatches.Adjuster20 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 00 40");

hexPatches.Adjuster21 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 e0 40");
hexPatches.Adjuster22 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 80 bf");
hexPatches.Adjuster23 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 80 bf");

hexPatches.Adjuster24 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 00 40");
hexPatches.Adjuster25 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"9a 99 a9 c0");
hexPatches.Adjuster26 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"66 66 66 3f");

hexPatches.Adjuster27 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 20 41");
hexPatches.Adjuster28 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 88 41");
hexPatches.Adjuster29 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"0"); 

hexPatches.Adjuster30 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 e0 40");
hexPatches.Adjuster31 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 20 41");
hexPatches.Adjuster32 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"0");

hexPatches.Adjuster33 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 20 40");
hexPatches.Adjuster34 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 80 bf");
hexPatches.Adjuster35 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 40 40");

hexPatches.Adjuster36 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 a0 40");
hexPatches.Adjuster37 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 80 40");
hexPatches.Adjuster38 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 80 bf");

hexPatches.Adjuster39 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f99f30,"00 00 70 41");
hexPatches.Adjuster40 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x216037c,"00 00 80 bf");
hexPatches.Adjuster41 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"00 00 80 bf");

      hexPatches.Euro = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae900,"6500750072006F00");
      hexPatches.Euro2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae908,"620061006C006C00");
      hexPatches.Euro3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae910,"2E00690066006600");
      hexPatches.Euro4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae918,"0000650061006D00");
      
	     hexPatches.Blackball1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae900,"62006C0061006300");
   hexPatches.Blackball2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae908,"6B 00 62 00 61 00 6C 00");
   hexPatches.Blackball3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae910,"6C 00 2E 00 69 00 66 00");
   hexPatches.Blackball4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae918,"66 00 00 00 74 00 65 00");

   hexPatches.Worldball1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae900,"77006F0072006C00");
   hexPatches.Worldball2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae908,"6400620061006C00");
   hexPatches.Worldball3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae910,"6C002E0069006600");
   hexPatches.Worldball4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1fae918,"6600000074006500");
 
   hexPatches.Ababall1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1FAE900,"61 00 62 00 61 00 62 00 61 00 6C 00 6C 00 2E 00 69 00 66 00 66 00");
   
  hexPatches.Cam1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"39 8E 63 3D");
  hexPatches.Cam2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"76 98 3a 3d");
  hexPatches.Cam3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"B4 A2 11 3D");
  hexPatches.Cam4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"e3 59 d1 3c");
  hexPatches.Cam5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"bb 7e dc 3c");
  hexPatches.Cam6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"6D 7A 6E 3C");
  hexPatches.Cam7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"1F 18 5E 3C");
  hexPatches.Cam8 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"D2 B5 4D 3C");
  hexPatches.Cam9 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"84 53 3D 3C");
  hexPatches.Cam10 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f8b9dc,"36 F1 2C 3C");
  
   //other in game
   hexPatches.Shot = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x201361c,"28 6E 6B 4E");
   hexPatches.Commentator = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x202a000,"00 00 00 00");
  
   
  hexPatches.All = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2160394,"66 66 c6 3f");
 
  hexPatches.HdPort = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 20 41");
   
   
   hexPatches.Jdskin = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104a38,"00 00 2F C4");
  hexPatches.Jdskin2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104948,"9A 99 39 40");
  hexPatches.Jdskin3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104950,"9A 99 39 40");
  hexPatches.Jdskin4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 a0 40");
  hexPatches.Jdskin5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21049d0,"00 00 a0 40");
  hexPatches.Jdskin6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104a10,"00 00 40 40");
   
    
         hexPatches.Player1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629e0,"0000A040");
hexPatches.Player2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629e4,"0000A040");
hexPatches.Player3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629e8,"0000A040");
hexPatches.Player4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629ec,"0000A040");
hexPatches.Player5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629f0,"0000A040");
hexPatches.Player6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629f4,"0000A040");
hexPatches.Player7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629f8,"0000A040");
hexPatches.Player8 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x21629fc,"0000A040");
hexPatches.Player9 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a00,"0000A040");
hexPatches.Player10 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a04,"0000A040");
hexPatches.Player11 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a08,"0000A040");
hexPatches.Player12 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a0c,"0000A040");
hexPatches.Player13 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a10,"0000A040");
hexPatches.Player14 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a14,"0000A040");
hexPatches.Player15 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a18,"0000A040");
hexPatches.Player16 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a1c,"0000A040");
hexPatches.Player17 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a20,"0000A040");
hexPatches.Player18 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a24,"0000A040");
hexPatches.Player19 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a28,"0000A040");
hexPatches.Player20 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a2c,"0000A040");
hexPatches.Player21 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a30,"0000A040");
hexPatches.Player22 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a34,"0000A040");
hexPatches.Player23 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a38,"0000A040");
hexPatches.Player24 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a3c,"0000A040");
hexPatches.Player25 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a40,"0000A040");
hexPatches.Player26 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a44,"0000A040");
hexPatches.Player27 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a48,"0000A040");
hexPatches.Player28 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a4c,"0000A040");
hexPatches.Player29 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a50,"0000A040");
hexPatches.Player30 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a54,"0000A040");
hexPatches.Player31 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a58,"0000A040");
hexPatches.Player32 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a5c,"0000A040");
hexPatches.Player33 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a60,"0000A040");
hexPatches.Player34 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a64,"0000A040");
hexPatches.Player35 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a68,"0000A040");
hexPatches.Player36 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a6c,"0000A040");
hexPatches.Player37 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a70,"0000A040");
hexPatches.Player38 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a74,"0000A040");
hexPatches.Player39 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a78,"0000A040");
hexPatches.Player40 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a7c,"0000A040");
hexPatches.Player41 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a80,"0000A040");
hexPatches.Player42 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a84,"0000A040");
hexPatches.Player43 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a88,"0000A040");
hexPatches.Player44 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a8c,"0000A040");
hexPatches.Player45 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a90,"0000A040");
hexPatches.Player46 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a94,"0000A040");
hexPatches.Player47 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a98,"0000A040");
hexPatches.Player48 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162a9c,"0000A040");
hexPatches.Player49 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162aa0,"0000A040");
hexPatches.Player50 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162aa4,"0000A040");
hexPatches.Player51 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162aa8,"0000A040");
hexPatches.Player52 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162aac,"0000A040");
hexPatches.Player53 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ab0,"0000A040");
hexPatches.Player54 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ab4,"0000A040");
hexPatches.Player55 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ab8,"0000A040");
hexPatches.Player56 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162abc,"0000A040");
hexPatches.Player57 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ac0,"0000A040");
hexPatches.Player58 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ac4,"0000A040");
hexPatches.Player59 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ac8,"0000A040");
hexPatches.Player60 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162acc,"0000A040");
hexPatches.Player61 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ad0,"0000A040");
hexPatches.Player62 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ad4,"0000A040");
hexPatches.Player63 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ad8,"0000A040");
hexPatches.Player64 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162adc,"0000A040");
hexPatches.Player65 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ae0,"0000A040");
hexPatches.Player66 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ae4,"0000A040");
hexPatches.Player67 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ae8,"0000A040");
hexPatches.Player68 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162aec,"0000A040");
hexPatches.Player69 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162af0,"0000A040");
hexPatches.Player70 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162af4,"0000A040");
hexPatches.Player71 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162af8,"0000A040");
hexPatches.Player72 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162afc,"0000A040");
hexPatches.Player73 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b00,"0000A040");
hexPatches.Player74 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b04,"0000A040");
hexPatches.Player75 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b08,"0000A040");
hexPatches.Player76 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b0c,"0000A040");
hexPatches.Player77 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b10,"0000A040");
hexPatches.Player78 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b14,"0000A040");
hexPatches.Player79 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b18,"0000A040");
hexPatches.Player80 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b1c,"0000A040");
hexPatches.Player81 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b20,"0000A040");
hexPatches.Player82 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b24,"0000A040");
hexPatches.Player83 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b28,"0000A040");
hexPatches.Player84 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b2c,"0000A040");
hexPatches.Player85 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b30,"0000A040");
hexPatches.Player86 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b34,"0000A040");
hexPatches.Player87 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b38,"0000A040");
hexPatches.Player88 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b3c,"0000A040");
hexPatches.Player89 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b40,"0000A040");
hexPatches.Player90 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b44,"0000A040");
hexPatches.Player91 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b48,"0000A040");
hexPatches.Player92 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b4c,"0000A040");
hexPatches.Player93= MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b50,"0000A040");
hexPatches.Player94 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b54,"0000A040");
hexPatches.Player95 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b58,"0000A040");
hexPatches.Player96 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b5c,"0000A040");
hexPatches.Player97 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b60,"0000A040");
hexPatches.Player98 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b64,"0000A040");
hexPatches.Player99 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b68,"0000A040");
hexPatches.Player100 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b6c,"0000A040");
hexPatches.Player101 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b70,"0000A040");
hexPatches.Player102 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b74,"0000A040");
hexPatches.Player103 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b78,"0000A040");
hexPatches.Player104 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b7c,"0000A040");
hexPatches.Player105 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b80,"0000A040");
hexPatches.Player106 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b84,"0000A040");
hexPatches.Player107 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b88,"0000A040");
hexPatches.Player108 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b8c,"0000A040");
hexPatches.Player109 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b90,"0000A040");
hexPatches.Player110 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b94,"0000A040");
hexPatches.Player111 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b98,"0000A040");
hexPatches.Player112 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162b9c,"0000A040");
hexPatches.Player113 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ba0,"0000A040");
hexPatches.Player114 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ba4,"0000A040");
hexPatches.Player115 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ba8,"0000A040");
hexPatches.Player116 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bac,"0000A040");
hexPatches.Player117 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bb0,"0000A040");
hexPatches.Player118 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bb4,"0000A040");
hexPatches.Player119 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bb8,"0000A040");
hexPatches.Player120 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bbc,"0000A040");
hexPatches.Player121 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bc0,"0000A040");
hexPatches.Player122 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bc4,"0000A040");
hexPatches.Player123 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bc8,"0000A040");
hexPatches.Player124 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bcc,"0000A040");
hexPatches.Player125 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bd0,"0000A040");
hexPatches.Player126 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bd4,"0000A040");
hexPatches.Player127 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bd8,"0000A040");
hexPatches.Player128 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bdc,"0000A040");
hexPatches.Player129 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162be0,"0000A040");
hexPatches.Player130 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162be4,"0000A040");
hexPatches.Player131 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162be8,"0000A040");
hexPatches.Player132 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bec,"0000A040");
hexPatches.Player133 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bf0,"0000A040");
hexPatches.Player134 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bf4,"0000A040");
hexPatches.Player135 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bf8,"0000A040");
hexPatches.Player136 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162bfc,"0000A040");
hexPatches.Player137 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c00,"0000A040");
hexPatches.Player138 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c04,"0000A040");
hexPatches.Player139 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c08,"0000A040");
hexPatches.Player140 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c0c,"0000A040");
hexPatches.Player141 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c10,"0000A040");
hexPatches.Player142 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c14,"0000A040");
hexPatches.Player143 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c18,"0000A040");
hexPatches.Player144 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c1c,"0000A040");
hexPatches.Player145 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c20,"0000A040");
hexPatches.Player146 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c24,"0000A040");
hexPatches.Player147 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c28,"0000A040");
hexPatches.Player148 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c2c,"0000A040");
hexPatches.Player149 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c30,"0000A040");
hexPatches.Player150 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c34,"0000A040");
hexPatches.Player151 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c38,"0000A040");
hexPatches.Player152 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c3c,"0000A040");
hexPatches.Player153 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c40,"0000A040");
hexPatches.Player154 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c44,"0000A040");
hexPatches.Player155 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c48,"0000A040");
hexPatches.Player156 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c4c,"0000A040");
hexPatches.Player157 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c50,"0000A040");
hexPatches.Player158 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c54,"0000A040");
hexPatches.Player159 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c58,"0000A040");
hexPatches.Player160 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c5c,"0000A040");
hexPatches.Player161 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c60,"0000A040");
hexPatches.Player162 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c64,"0000A040");
hexPatches.Player163 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c68,"0000A040");
hexPatches.Player164 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c6c,"0000A040");
hexPatches.Player165 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c70,"0000A040");
hexPatches.Player166 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c74,"0000A040");
hexPatches.Player167 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c78,"0000A040");
hexPatches.Player168 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c7c,"0000A040");
hexPatches.Player169 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c80,"0000A040");
hexPatches.Player170 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c84,"0000A040");
hexPatches.Player171 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c88,"0000A040");
hexPatches.Player172 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c8c,"0000A040");
hexPatches.Player173 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c90,"0000A040");
hexPatches.Player174 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c94,"0000A040");
hexPatches.Player175 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c98,"0000A040");
hexPatches.Player176 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162c9c,"0000A040");
hexPatches.Player177 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ca0,"0000A040");
hexPatches.Player178 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ca4,"0000A040");
hexPatches.Player179 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ca8,"0000A040");
hexPatches.Player180 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cac,"0000A040");
hexPatches.Player181 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cb0,"0000A040");
hexPatches.Player182 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cb4,"0000A040");
hexPatches.Player183 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cb8,"0000A040");
hexPatches.Player184 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cbc,"0000A040");
hexPatches.Player185 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cc0,"0000A040");
hexPatches.Player186 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cc4,"0000A040");
hexPatches.Player187 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cc8,"0000A040");
hexPatches.Player188 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ccc,"0000A040");
hexPatches.Player189 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cd0,"0000A040");
hexPatches.Player190 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cd4,"0000A040");
hexPatches.Player191 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cd8,"0000A040");
hexPatches.Player192 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cdc,"0000A040");
hexPatches.Player193 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ce0,"0000A040");
hexPatches.Player194 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ce4,"0000A040");
hexPatches.Player195 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ce8,"0000A040");
hexPatches.Player196 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cec,"0000A040");
hexPatches.Player197 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cf0,"0000A040");
hexPatches.Player198 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cf4,"0000A040");
hexPatches.Player199 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cf8,"0000A040");
hexPatches.Player200 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162cfc,"0000A040");
hexPatches.Player201 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d00,"0000A040");
hexPatches.Player202 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d04,"0000A040");
hexPatches.Player203 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d08,"0000A040");
hexPatches.Player204 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d0c,"0000A040");
hexPatches.Player205 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d10,"0000A040");
hexPatches.Player206 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d14,"0000A040");
hexPatches.Player207 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d18,"0000A040");
hexPatches.Player208 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d1c,"0000A040");
hexPatches.Player209 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d20,"0000A040");
hexPatches.Player210 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d24,"0000A040");
hexPatches.Player211 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d28,"0000A040");
hexPatches.Player212 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d2c,"0000A040");
hexPatches.Player213 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d30,"0000A040");
hexPatches.Player214 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d34,"0000A040");
hexPatches.Player215 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d38,"0000A040");
hexPatches.Player216 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d3c,"0000A040");
hexPatches.Player217 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d40,"0000A040");
hexPatches.Player218 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d44,"0000A040");
hexPatches.Player219 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d48,"0000A040");
hexPatches.Player220 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d4c,"0000A040");
hexPatches.Player221 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d50,"0000A040");
hexPatches.Player222 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d54,"0000A040");
hexPatches.Player223 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d58,"0000A040");
hexPatches.Player224 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d5c,"0000A040");
hexPatches.Player225 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d60,"0000A040");
hexPatches.Player226 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d64,"0000A040");
hexPatches.Player227 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d68,"0000A040");
hexPatches.Player228 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d6c,"0000A040");
hexPatches.Player229 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d70,"0000A040");
hexPatches.Player230 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d74,"0000A040");
hexPatches.Player231 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d78,"0000A040");
hexPatches.Player232 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d7c,"0000A040");
hexPatches.Player233 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d80,"0000A040");
hexPatches.Player234 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d84,"0000A040");
hexPatches.Player235 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d88,"0000A040");
hexPatches.Player236 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d8c,"0000A040");
hexPatches.Player237 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d90,"0000A040");
hexPatches.Player238 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d94,"0000A040");
hexPatches.Player239 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d98,"0000A040");
hexPatches.Player240 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162d9c,"0000A040");
hexPatches.Player241 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162da0,"0000A040");
hexPatches.Player242 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162da4,"0000A040");
hexPatches.Player243 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162da8,"0000A040");
hexPatches.Player244 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dac,"0000A040");
hexPatches.Player245 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162db0,"0000A040");
hexPatches.Player246 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162db4,"0000A040");
hexPatches.Player247 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162db8,"0000A040");
hexPatches.Player248 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dbc,"0000A040");
hexPatches.Player249 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dc0,"0000A040");
hexPatches.Player250 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dc4,"0000A040");
hexPatches.Player251 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dc8,"0000A040");
hexPatches.Player252 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dcc,"0000A040");
hexPatches.Player253 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dd0,"0000A040");
hexPatches.Player254 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dd4,"0000A040");
hexPatches.Player255 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162dd8,"0000A040");
hexPatches.Player256 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2162ddc,"0000A040");

   hexPatches.Speed1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20168b4,"00 00 00 40");
   hexPatches.Speed2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20168b4,"00 00 10 41");
   hexPatches.Speed3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20168b4,"00 00 A0 40");
   hexPatches.Speed4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20168b4,"00 00 20 41");
   
   hexPatches.Vertical1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2005f18,"00 00 99 43");
   hexPatches.Vertical2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2005f18,"00 00 A0 43");
   hexPatches.Vertical3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2005f18,"00 80 A7 43");
   hexPatches.Vertical4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2005f18,"00 80 AC 43");
   
   hexPatches.Anklebreaker1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fd4,"28 6E 6B 4E");
   hexPatches.Anklebreaker2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fd8,"28 6E 6B 4E");
   hexPatches.Anklebreaker3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fdc,"28 6E 6B 4E");
   hexPatches.Anklebreaker4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fe0,"28 6E 6B 4E");
   hexPatches.Anklebreaker5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fe4,"28 6E 6B 4E");
   hexPatches.Anklebreaker6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fe8,"28 6E 6B 4E");
   hexPatches.Anklebreaker7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016fe1,"28 6E 6B 4E");
   hexPatches.Anklebreaker8 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016ff0,"28 6E 6B 4E");
   
   
  hexPatches.Dribble = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016810,"B8 1E 85 3F");
  hexPatches.Dribble2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016810,"00 00 00 40");  
  hexPatches.Dribble3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016810,"00 00 40 40");
  hexPatches.Dribble4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2016810,"00 00 80 40");
  
  hexPatches.Sweat = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361b6,"10 27");
 hexPatches.Sweat2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361b8,"10 27");
 hexPatches.Sweat3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361ba,"10 27");
 hexPatches.Sweat4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361bc,"10 27");
 hexPatches.Sweat5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361be,"10 27");
 hexPatches.Sweat6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361c0,"10 27");
 hexPatches.Sweat7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361c2,"10 27");
 hexPatches.Sweat8 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361c4,"10 27");
 hexPatches.Sweat9 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361c6,"10 27");
 hexPatches.Sweat10 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361c8,"10 27");
 hexPatches.Sweat11 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x20361ca,"10 27");
 
hexPatches.Hdingame = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x1f917cc,"0a d7 a3 3b");
 
hexPatches.Skins1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 A0 40");
  hexPatches.Skins2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 C0 40");
  hexPatches.Skins3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 E0 40");
  hexPatches.Skins4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 00 41");
  hexPatches.Skins5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 10 41");
  hexPatches.Skins6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 20 41");
  hexPatches.Skins7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104990,"00 00 30 41");
  
  hexPatches.Portrait1 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 A0 40");
  hexPatches.Portrait2 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 C0 41");
  hexPatches.Portrait3 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 E0 40");
  hexPatches.Portrait4 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 00 41");
  hexPatches.Portrait5 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 10 41");
  hexPatches.Portrait6 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 20 41");
  hexPatches.Portrait7 = MemoryPatch::createWithHex("libnba2k20_clean_opt.so",0x2104870,"00 00 30 41");
 // ScanAndEditString(targetString, replacementString);

hook((void *)getAbsoluteAddress(OBFUSCATE("libnba2k20_clean_opt.so"), string2Offset(OBFUSCATE("0x0146a118"))), (void *)&hookedAI_SetAllMascotVisibility, (void **)&originalAI_SetAllMascotVisibility);
//hook((void *)getAbsoluteAddress(OBFUSCATE("libnba2k20_clean_opt.so"), string2Offset(OBFUSCATE("0x0173ba5c"))), (void *)&HookedSetCourtID, (void **)&originalSetCourtID);
//hook((void *)getAbsoluteAddress(OBFUSCATE("libnba2k20_clean_opt.so"), string2Offset(OBFUSCATE("0x0103fcac"))), (void *)&Hooked_CreateDate, (void **)&OriginalFunc);
//HOOK("0x0103fcac", "Hooked_CreateDate", "OriginalFuncType");
      

#else //To compile this code for armv7 lib only.

    // Hook
    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
    /*if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;
        *p = 0;
    }*/

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("201_PagerController_TEAM SELECT_76ers,BUCKS,BULLS,CAVALIERS,CELTICS,CLIPPERS,GRIZZLIES,HAWKS,HEAT,HORNET,JAZZ,KINGS,KNICKS,LAKERS,MAGIC,MAVERICKS,NETS,NUGGETS,PACERS,PELICANS,PISTONS,RAPTORS,ROCKETS,SPURS,SUNS,THUNDER,TIMBERWOLVES,BLAZERS,WARRIORS,WIZARDS,FREE AGENTS"),	 
			OBFUSCATE("1007_InputValue_TEAM ID"),
			OBFUSCATE("1008_Toggle_TRADE PLAYERS"),
			OBFUSCATE("1009_Toggle_HISTORIC PLAYERS"),
			OBFUSCATE("Category_VC HACK"),
			OBFUSCATE("80_Toggle_UNLI VC"),
			OBFUSCATE("81_InputValue_UNLI VC"),
			OBFUSCATE("Category_CHANGE BALLS"),
			OBFUSCATE("400_Toggle_EURO BALL"),			
            OBFUSCATE("401_Toggle_BLACK BALL"),
			OBFUSCATE("402_Toggle_WORLD BALL"),		
		    OBFUSCATE("403_Toggle_ABA BALL"),
			OBFUSCATE("Category_DRONE VIEW"),
			OBFUSCATE("410_CheckBox_DRONE VIEW X1"),
			OBFUSCATE("411_CheckBox_DRONE VIEW X2"),
			OBFUSCATE("412_CheckBox_DRONE VIEW X3"),
			OBFUSCATE("413_CheckBox_DRONE VIEW X4"),
			OBFUSCATE("414_CheckBox_DRONE VIEW X5"),
			OBFUSCATE("415_CheckBox_DRONE VIEW X6"),
			OBFUSCATE("416_CheckBox_DRONE VIEW X7"),
			OBFUSCATE("417_CheckBox_DRONE VIEW X8"),
			OBFUSCATE("418_CheckBox_DRONE VIEW X9"),
			OBFUSCATE("419_CheckBox_DRONE VIEW X10"),
			OBFUSCATE("Category_FLOOR COLOR RGB"),
            OBFUSCATE("405_InputValue_R"),			
            OBFUSCATE("406_InputValue_G"),
			OBFUSCATE("407_InputValue_B"),
			OBFUSCATE("507_SeekBar_Color Adjuster R_1_500"),		
            OBFUSCATE("506_SeekBar_Color Adjuster G_1_500"),		     
            OBFUSCATE("507_SeekBar_Color Adjuster B_1_500"),		     
			OBFUSCATE("Category_OTHER INGAME MODS"),
			OBFUSCATE("11_Toggle_HALFCOURT SHOT"),
			OBFUSCATE("12_Toggle_HYPER COMMENTARY"),
			OBFUSCATE("600_Toggle_RETRO SHORTS"),
			OBFUSCATE("30_Toggle_DARKCROWD"),
			OBFUSCATE("31_Toggle_HD CROWD"),
			OBFUSCATE("1002_Toggle_HD PLAYER"),
			OBFUSCATE("1003_Toggle_PAWIS"),
			OBFUSCATE("7030_Toggle_PAWIS IN GAME"),
			OBFUSCATE("1004_Toggle_HD SKIN"),
			OBFUSCATE("1005_Toggle_HD PORTRAIT"),
			OBFUSCATE("1006_Toggle_HD IN GAME"),
			OBFUSCATE("1076_Toggle_HD ACCESSORIES"),
			OBFUSCATE("1016_Toggle_REALISTIC HD SKIN IN GAME"),
			OBFUSCATE("1017_Toggle_HD SKIN+IN GAME"),
			OBFUSCATE("Category_Player Skin/Hair Color"),
		    OBFUSCATE("55_CheckBox_Color Skin1"),		
		    OBFUSCATE("56_CheckBox_Color Skin2"),			
		    OBFUSCATE("57_CheckBox_Color Skin3"),		
		    OBFUSCATE("58_CheckBox_Hair Color"),
			OBFUSCATE("Category_ENHANCE WINGSPAN"),
			OBFUSCATE("8057_Toggle_WINGSPAN1"),
			OBFUSCATE("8058_Toggle_WINGSPAN2"),		
		    OBFUSCATE("59_Toggle_WINGSPAN3"),
			OBFUSCATE("60_Toggle_WINGSPAN4"),
			OBFUSCATE("61_Toggle_WINGSPAN5"),
			OBFUSCATE("70_Toggle_WINGSPAN6"),
			OBFUSCATE("71_Toggle_WINGSPAN7"),
			OBFUSCATE("Category_FANS CLOTHES"),
			OBFUSCATE("1078_Toggle_CLOTHES1"),		
		    OBFUSCATE("1079_Toggle_CLOTHES2"),		
		    OBFUSCATE("1080_Toggle_CLOTHES3"),	
		    OBFUSCATE("1081_Toggle_CLOTHES4"),
		    OBFUSCATE("1082_Toggle_CLOTHES5"),
			//OBFUSCATE("-99_Buttons4_GET ROS"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList2(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
		    //OBFUSCATE("Category_SIXERS"), 
            OBFUSCATE("8000_PagerController_SIXERS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_BUCKS"), 
            OBFUSCATE("8001_PagerController_BUCKS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_BULLS"), 
            OBFUSCATE("8002_PagerController_BULLS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_CAVS"), 
            OBFUSCATE("8003_PagerController_CAVALIERS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_CELTICS"), 
            OBFUSCATE("8004_PagerController_CELTICS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_CLIPPERS"), 
            OBFUSCATE("8005_PagerController_CLIPPERS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_GRIZZLIES"), 
            OBFUSCATE("8006_PagerController_GRIZZLIES_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_HAWKS"), 
            OBFUSCATE("8007_PagerController_HAWKS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_HEAT"), 
            OBFUSCATE("8008_PagerController_HEAT_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_HORNETS"), 
            OBFUSCATE("8009_PagerController_HORNETS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_JAZZ"), 
            OBFUSCATE("8010_PagerController_JAZZ_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_KINGS"), 
            OBFUSCATE("8011_PagerController_KINGS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_KNICKS"), 
            OBFUSCATE("8012_PagerController_KNICKS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_LAKERS"), 
            OBFUSCATE("8013_PagerController_LAKERS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_MAGIC"), 
            OBFUSCATE("8014_PagerController_MAGIC_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_MAVERICKS"), 
            OBFUSCATE("8015_PagerController_DALLAS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_NETS"), 
            OBFUSCATE("8016_PagerController_NETS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_NUGGETS"), 
            OBFUSCATE("8017_PagerController_NUGGETS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_PACERS"), 
            OBFUSCATE("8018_PagerController_PACERS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_PELICANS"), 
            OBFUSCATE("8019_PagerController_PELICANS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_PISTONS"), 
            OBFUSCATE("8020_PagerController_PISTONS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_RAPTORS"), 
            OBFUSCATE("8021_PagerController_RAPTORS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_ROCKETS"), 
            OBFUSCATE("8022_PagerController_ROCKETS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_SPURS"), 
            OBFUSCATE("8023_PagerController_SPURS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_SUNS"), 
            OBFUSCATE("8024_PagerController_SUNS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_THUNDER"), 
            OBFUSCATE("8025_PagerController_THUNDER_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_TIMBERWOLVE"), 
            OBFUSCATE("8026_PagerController_WOLVES_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_TIMBERWOLVES"), 
            OBFUSCATE("8027_PagerController_BLAZERS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_WARRIORS"), 
            OBFUSCATE("8028_PagerController_WARRIORS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
            //OBFUSCATE("Category_WIZZARDS"), 
            OBFUSCATE("8029_PagerController_WIZZARDS_DEFAULT,HD COURT,HD COURT AND DARK CROWD,HD COURT AND HD CROWD"),
			OBFUSCATE("Category_COLOR COURT ADJUSTER"), //Not counted
            OBFUSCATE("3043_Toggle_ADJUSTER1"),  	
			OBFUSCATE("3030_Toggle_ADJUSTER2"),
			OBFUSCATE("3031_Toggle_ADJUSTER3"),  
			OBFUSCATE("3032_Toggle_ADJUSTER4"),  
			OBFUSCATE("3033_Toggle_ADJUSTER5"),
			OBFUSCATE("3034_Toggle_ADJUSTER6"),  
			OBFUSCATE("3035_Toggle_ADJUSTER7"),
		    OBFUSCATE("3036_Toggle_ADJUSTER8"),
		    OBFUSCATE("3037_Toggle_ADJUSTER9"),  
			OBFUSCATE("3038_Toggle_ADJUSTER10"),  
			OBFUSCATE("3039_Toggle_ADJUSTER11"),  
			OBFUSCATE("3040_Toggle_ADJUSTER12"),  
			OBFUSCATE("3041_Toggle_ADJUSTER13"),  
			OBFUSCATE("3042_Toggle_ADJUSTER14"),  
			OBFUSCATE("3044_Toggle_ADJUSTER15"),  
			OBFUSCATE("3045_Toggle_BLACK COURT ALL TEAM"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList3(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
		    OBFUSCATE("Category_PLAYER HIGHRATES"),
			OBFUSCATE("1641_Toggle_STEAL"),
			OBFUSCATE("1639_Toggle_LONG SHOT [HOME]"),
			OBFUSCATE("1640_Toggle_LONG SHOT [AWAY]"),
            OBFUSCATE("17_Toggle_SPEED1"),
            OBFUSCATE("18_Toggle_SPEED2"),
			OBFUSCATE("19_Toggle_SPEED3"),
		    OBFUSCATE("20_Toggle_SPEED4"),
			
			OBFUSCATE("1389_Toggle_NO BLOCKING FOUL"),
			OBFUSCATE("1390_Toggle_NO REACHIN FOUL"),

			OBFUSCATE("21_Toggle_VERTICAL1"),
		    OBFUSCATE("22_Toggle_VERTICAL2"),
		    OBFUSCATE("23_Toggle_VERTICAL3"),
		    OBFUSCATE("24_Toggle_VERTICAL4"),
		
		    OBFUSCATE("35_Toggle_ANKLE BREAKER"),

		    OBFUSCATE("700_Toggle_FAST DUNK"),
			OBFUSCATE("701_Toggle_HANGTIME"),
			OBFUSCATE("702_Toggle_FAST LAYUP"),
			
			OBFUSCATE("26_Toggle_DEFAULT"),
			OBFUSCATE("27_Toggle_VETERAN"),
			OBFUSCATE("28_Toggle_EXPERT"),
			OBFUSCATE("29_Toggle_PROFFESIONAL"),
	};

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList4(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {	    
            OBFUSCATE("203_InputValue_FACE UP"),
			OBFUSCATE("260_InputValue_PORTRAIT"),
			OBFUSCATE("305_InputValue_BODY"),
			OBFUSCATE("306_InputValue_SKINTONE"),
			OBFUSCATE("309_InputValue_POSITION"),
			OBFUSCATE("310_InputValue_DOMINANT HAND"),
			OBFUSCATE("311_InputValue_DOMINANT DUNK HAND"),
			OBFUSCATE("Category_CONTRACT SALARY"),
			OBFUSCATE("2012_InputValue_YEAR"),
			OBFUSCATE("2013_InputValue_SALARY 1"),
			OBFUSCATE("2014_InputValue_SALARY 2"),
			OBFUSCATE("2015_InputValue_SALARY 3"),
			OBFUSCATE("2016_InputValue_SALARY 4"),
			OBFUSCATE("2017_InputValue_SALARY 5"),
			OBFUSCATE("2018_InputValue_SALARY 6"),
			OBFUSCATE("Category_DUNK PACKS"),
			OBFUSCATE("312_InputValue_DUNK PACK1"),
			OBFUSCATE("313_InputValue_DUNK PACK2"),
			OBFUSCATE("314_InputValue_DUNK PACK3"),
			OBFUSCATE("315_InputValue_DUNK PACK4"),
			OBFUSCATE("316_InputValue_DUNK PACK5"),
			OBFUSCATE("317_InputValue_DUNK PACK6"),
			OBFUSCATE("318_InputValue_DUNK PACK7"),
			OBFUSCATE("319_InputValue_DUNK PACK8"),
			OBFUSCATE("320_InputValue_DUNK PACK9"),
			OBFUSCATE("321_InputValue_DUNK PACK10"),
			OBFUSCATE("322_InputValue_DUNK PACK11"),
			OBFUSCATE("323_InputValue_DUNK PACK12"),
			OBFUSCATE("324_InputValue_DUNK PACK13"),
			OBFUSCATE("325_InputValue_DUNK PACK14"),
			OBFUSCATE("326_InputValue_DUNK PACK15"),		

            };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList5(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
		    OBFUSCATE("1750_InputValue_TEAM CHEMISTRY"),
		    OBFUSCATE("926_Spinner_PLAYER SPECIALITY:_NONE,FINISHER,CATCH&SHOOT,DEADEYE,SCREEN OUTLET,ANKLE BREAKER,ONE MAN FASTBREAK,DIMER,ALLEY-OOPER,BRICKWALL,LOCKDOWN DEFENDER,INTERCEPTOR,ACTIVE HANDS,ERASER,FLOOR GENERAL,BRUISER,TENACIOUS REBOUNDER,MICROWAVE,CLOSER,ON COURT COACH,ASSIST BONUS,DEFENSIVE AWARENESS BONUS,HIGHLIGHT FLIM,ACROBAT,SHOT CREATOR,CORNER SPECIALIST,POST PROFICIENCY,PICK&ROLL MAESTRO,POST PLAYMAKER,BREAK STARTER,FLASHY PASSER,HUSTLE POINTS,CHANGE COURT,PICK POCKET,PICK DODGER,CHASEDOWN ARTIST,DEFENSIVE ANCHOR,SCRAPPER,ANTI-FREEZER,HEAT RETENTION,GATORADE PERFORM PACK,LEBRON COAST TO COAST,OFFENSIVE AWARNESS BONUS,ATTRIBUTE PENALTY,POSTERIZER"), 
            OBFUSCATE("925_InputValue_PLAYER SPECIALTY"), 
            OBFUSCATE("200_CheckBox_99STATS"), //Not countedb
            OBFUSCATE("920_CheckBox_MAX ALL TENDENCIES+Gold Badges"), //Not countedb
            OBFUSCATE("921_CheckBox_DOUBLE REPLAY HIGHLIGHTS"), //Not countedb
			OBFUSCATE("922_EndGame_END GAME"),
            OBFUSCATE("970_InputValue_SHOT CLOCK"),
            OBFUSCATE("924_InputValue_SCORE COUNT"), 
			OBFUSCATE("971_InputValue_DRILL CLOCK"),
			OBFUSCATE("Category_BADGES"),
			OBFUSCATE("7070_InputValue_Calm down/take over the game/field manager"),
			OBFUSCATE("7071_InputValue_Defensive Core/Microwave/Calm/Corner Expert"),
			OBFUSCATE("7072_InputValue_Sagittarius/Infinite Range/Master Backward/Shooter Maker"),
			OBFUSCATE("7073_InputValue_Targeted Pitcher/Blocker/Wonderful Playbackiay Stunt Actor"),
			OBFUSCATE("7074_InputValue_Scrambling for points/Shield experts/Terminators/Backbody proficiency"),
			OBFUSCATE("7075_InputValue_Inside Attack Organizer/Cross Killer/King of Turns/Retreat Freeze"),
			OBFUSCATE("7076_InputValue_Behind the back dribbling expert/fancy pass player/fast break initiator/pick and roll tactical input.."),
			OBFUSCATE("7077_InputValue_Empty catcher/Ten cents/On court coach/Offensive rebounder king"),
			OBFUSCATE("7078_InputValue_Defensive Rebound King/Offensive Foul Maker! Lock Defender/Pick and Roll Dodger"),
			OBFUSCATE("7079_InputValue_Interceptor/Thief/Active Hand/Blocker"),
			OBFUSCATE("7080_InputValue_Chasing Master/Fighter/Iron Wall/Single player Fast Attack"),
			OBFUSCATE("7081_InputValue_Gatorade Moment"),
			OBFUSCATE("Collapse_ABILITIES"),
			OBFUSCATE("7082_CollapseAdd_Spinner_COPY ATTRIBUTES_NULL,COPY,APPLY"),
			OBFUSCATE("7083_CollapseAdd_Spinner_COPY TENDENCIES_NULL,COPY,APPLY"),
			OBFUSCATE("7084_CollapseAdd_Spinner_COPY STATS_NULL,COPY,APPLY"),
			};

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList6(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_ACCESSORIES"), //Not counted           
            OBFUSCATE("904_InputValue_HEADBAND"),
            OBFUSCATE("905_InputValue_WRIST LEFT"),
			OBFUSCATE("906_InputValue_UNDER TSHIRT"),
			OBFUSCATE("907_InputValue_WRIST RIGHT"),
			OBFUSCATE("908_InputValue_LEGGINGS LEFT"),
			OBFUSCATE("909_InputValue_KNEEPAD"),
			OBFUSCATE("910_InputValue_SOCKS"),
			OBFUSCATE("911_InputValue_COLOR UNDERTSHIRT & ARM BAND"),
			OBFUSCATE("912_InputValue_COLOR ARM"),
			OBFUSCATE("913_InputValue_COLOR WRIST LEFT"),
			OBFUSCATE("914_InputValue_COLOR WRIST RIGHT"),
			OBFUSCATE("915_InputValue_COLOR LEG LEFT"),
			OBFUSCATE("916_InputValue_COLOR KNEEPAD"),
			OBFUSCATE("917_InputValue_COLOR SOCKS"),
			OBFUSCATE("918_InputValue_LEGGINGS RIGHT"),
			OBFUSCATE("919_InputValue_SLEEVE"),
			OBFUSCATE("Category_COLOR ACCESSORIES"),
			OBFUSCATE("220_Toggle_COLOR 1"),
			OBFUSCATE("221_Toggle_COLOR 2"),
			OBFUSCATE("222_Toggle_COLOR 3"),
			OBFUSCATE("223_Toggle_NEON"),
			OBFUSCATE("224_Toggle_NEON2"),
			OBFUSCATE("225_Toggle_NEON3"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}
jobjectArray GetFeatureList7(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_HD COURT AND DARK CROWD"),
			OBFUSCATE("4000_CheckBox_SIXERS"),
            OBFUSCATE("4001_CheckBox_BUCKS"),
            OBFUSCATE("4002_CheckBox_BULLS"),
            OBFUSCATE("4003_CheckBox_CAVALIERS"),
            OBFUSCATE("4004_CheckBox_CELTICS"),
            OBFUSCATE("4005_CheckBox_CLIPPERS"),
            OBFUSCATE("4006_CheckBox_MEMPHIS"),
            OBFUSCATE("4007_CheckBox_HAWKS"),
            OBFUSCATE("4008_CheckBox_HEAT"),
            OBFUSCATE("4009_CheckBox_HORNETS"),
            OBFUSCATE("4010_CheckBox_JAZZ"),
            OBFUSCATE("4011_CheckBox_KINGS"),
            OBFUSCATE("4012_CheckBox_KNICKS"),
            OBFUSCATE("4013_CheckBox_LAKERS"),
            OBFUSCATE("4014_CheckBox_MAGIC"),
            OBFUSCATE("4015_CheckBox_MAVERICKS"),
            OBFUSCATE("4016_CheckBox_NETS"),
            OBFUSCATE("4017_CheckBox_NUGGETS"),
            OBFUSCATE("4018_CheckBox_PACERS"),
            OBFUSCATE("4019_CheckBox_PELICANS"),
            OBFUSCATE("4020_CheckBox_PISTONS"),
            OBFUSCATE("4021_CheckBox_RAPTORS"),
            OBFUSCATE("4022_CheckBox_ROCKETS"),
            OBFUSCATE("4023_CheckBox_SPURS"),
            OBFUSCATE("4024_CheckBox_SUNS"),
            OBFUSCATE("4025_CheckBox_THUNDER"),
            OBFUSCATE("4026_CheckBox_TIMBERWOLVES"),
            OBFUSCATE("4027_CheckBox_TRAIL BALZERS"),
            OBFUSCATE("4028_CheckBox_GOLDEN STATE"),
            OBFUSCATE("4029_CheckBox_WIZZARDS"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList8(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_HD COURT AND HD CROWD"),
			OBFUSCATE("5000_CheckBox_SIXERS"),
            OBFUSCATE("5001_CheckBox_BUCKS"),
            OBFUSCATE("5002_CheckBox_BULLS"),
            OBFUSCATE("5003_CheckBox_CAVALIERS"),
            OBFUSCATE("5004_CheckBox_CELTICS"),
            OBFUSCATE("5005_CheckBox_CLIPPERS"),
            OBFUSCATE("5006_CheckBox_MEMPHIS"),
            OBFUSCATE("5007_CheckBox_HAWKS"),
            OBFUSCATE("5008_CheckBox_HEAT"),
            OBFUSCATE("5009_CheckBox_HORNETS"),
            OBFUSCATE("5010_CheckBox_JAZZ"),
            OBFUSCATE("5011_CheckBox_KINGS"),
            OBFUSCATE("5012_CheckBox_KNICKS"),
            OBFUSCATE("5013_CheckBox_LAKERS"),
            OBFUSCATE("5014_CheckBox_MAGIC"),
            OBFUSCATE("5015_CheckBox_MAVERICKS"),
            OBFUSCATE("5016_CheckBox_NETS"),
            OBFUSCATE("5017_CheckBox_NUGGETS"),
            OBFUSCATE("5018_CheckBox_PACERS"),
            OBFUSCATE("5019_CheckBox_PELICANS"),
            OBFUSCATE("5020_CheckBox_PISTONS"),
            OBFUSCATE("5021_CheckBox_RAPTORS"),
            OBFUSCATE("5022_CheckBox_ROCKETS"),
            OBFUSCATE("5023_CheckBox_SPURS"),
            OBFUSCATE("5024_CheckBox_SUNS"),
            OBFUSCATE("5025_CheckBox_THUNDER"),
            OBFUSCATE("5026_CheckBox_TIMBERWOLVES"),
            OBFUSCATE("5027_CheckBox_TRAIL BALZERS"),
            OBFUSCATE("5028_CheckBox_GOLDEN STATE"),
            OBFUSCATE("5029_CheckBox_WIZZARDS"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList9(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_HD IN LOBBY"),
			  OBFUSCATE("7009_Toggle_HD SKIN1"),
			  OBFUSCATE("7010_Toggle_HD SKIN2"),
			  OBFUSCATE("32_Toggle_HD SKIN3"),
			  OBFUSCATE("33_Toggle_HD SKIN4"),
			  OBFUSCATE("34_Toggle_HD SKIN5"),
			  OBFUSCATE("7011_Toggle_HD SKIN6"),
			  OBFUSCATE("36_Toggle_HD SKIN7"),
			  OBFUSCATE("Category_HD PORTRAIT"),
			  OBFUSCATE("37_Toggle_HD PORTRAIT1"),
			  OBFUSCATE("38_Toggle_HD PORTRAIT2"),
			  OBFUSCATE("39_Toggle_HD PORTRAIT3"),
			  OBFUSCATE("40_Toggle_HD PORTRAIT4"),
			  OBFUSCATE("41_Toggle_HD PORTRAIT5"),
			  OBFUSCATE("42_Toggle_HD PORTRAIT6"),
			  OBFUSCATE("43_Toggle_HD PORTRAIT7"),
			//
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

    jobjectArray GetFeatureList10(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
		    OBFUSCATE("2071_Spinner_COPY INFO_NULL,BACKUP, RESTORE"), 
		//	OBFUSCATE("Collapse_COPY HEIGHT & WEIGHT"),
			OBFUSCATE("2010_Spinner_HEIGHT_NULL,BACKUP, RESTORE"), 
			OBFUSCATE("2011_Spinner_WEIGHT_NULL,BACKUP, RESTORE"), 
			//OBFUSCATE("Collapse_COPY NAME"),
			OBFUSCATE("2008_Spinner_FIRST NAME_NULL,BACKUP, RESTORE"), 
			OBFUSCATE("2009_Spinner_LAST NAME_NULL,BACKUP, RESTORE"), 
			//OBFUSCATE("Collapse_FACE"),               
            OBFUSCATE("2000_Spinner_BACKUP PLAYER_NULL,BACKUP, RESTORE"),          
            OBFUSCATE("2024_Spinner_COPY CF_NULL,BACKUP, RESTORE"),      
			OBFUSCATE("2025_Spinner_COPY PORTRAIT_NULL,BACKUP, RESTORE"),      
			//OBFUSCATE("Collapse_DUNK-PACKAGES-"),            
            OBFUSCATE("923_Spinner_COPY DUNK PACK_NULL,COPY,EQUIP DUNPACK"),
		    //OBFUSCATE("Collapse_RUNS THE STREET"),//Not counted
           OBFUSCATE("6024_Spinner_COPY RTS_Null, COPY, EQUIP"),
           OBFUSCATE("6025_Spinner_COPY PLAYERS ATTIRE IN ROSTER_Null, COPY, EQUIP"),
		   OBFUSCATE("822_Spinner_ACCESSORIES TYPE_Headband, Type -A-, Type -B-, Type -C-, RESET ACCESSORIES"), 
           //OBFUSCATE("Collapse_COPY ACCESSORIES"),//Not counted
           OBFUSCATE("929_Spinner_COPY ACCESSORIES_Null, COPY, EQUIP"),
			

    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}  

jobjectArray GetFeatureList11(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
			OBFUSCATE("-6_Button3_BACKUP"),
            OBFUSCATE("-100_Button2_RESTORE"),

    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}  

jobjectArray GetFeatureList12(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
			OBFUSCATE("3180_Buttons5_SIXERS"),

    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}  

jobjectArray GetFeatureList13(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
			
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}  

jobjectArray GetFeatureList14(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
			
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}  
void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;



switch (featNum) {
	case 1800:
	{
    if(boolean){
		patchBssOffset(playerattire, originalFaceID, true);
        patchBssOffset(clothes, originalFaceID1, true);
        patchBssOffset(playerID, originalFaceID2, true);
		patchBssOffset(rts, stats23, true);     
		patchBssOffset(rts2, stats24, true);
		}
		break;
		}
	case 1017:
    {  
    if(boolean){
       patchBssOffset(rls, "6600", true);//7
	   patchBssOffset(rls2, "3000", true);//7
	   patchBssOffset(rls3, "3300", true);//7
	   patchBssOffset(rls4, "3300", true);//7
	   patchBssOffset(rls5, "00002FC4", true);//7
	   patchBssOffset(rls6, "00000000", true);//7
	   patchBssOffset(rls7, "00000000", true);//7
	   patchBssOffset(rls8, "00000000", true);//7
	   patchBssOffset(rls9, "00000000", true);//7
	   patchBssOffset(rls10, "00000000", true);//7
	   patchBssOffset(rls11, "00000000", true);//7
	   patchBssOffset(rls12, "0000C03F", true);//7
	   patchBssOffset(rls13, "0000C03F", true);//7
	   patchBssOffset(rls14, "00000040", true);//7

	   }else{
       patchBssOffset(rls, "00000000", true);//7
	   patchBssOffset(rls2, "00000000", true);//7
	   patchBssOffset(rls3, "00000000", true);//7
	   patchBssOffset(rls4, "00000000", true);//7
	   patchBssOffset(rls5, "00C08F44", true);//7
	   patchBssOffset(rls6, "00000000", true);//7
	   patchBssOffset(rls7, "00000000", true);//7
	   patchBssOffset(rls8, "00000000", true);//7
	   patchBssOffset(rls9, "00000000", true);//7
	   patchBssOffset(rls10, "00000000", true);//7
	   patchBssOffset(rls11, "00000000", true);//7
	   patchBssOffset(rls12, "0000003F", true);//7
	   patchBssOffset(rls13, "0000003F", true);//7
	   patchBssOffset(rls14, "0000003F", true);//7
		   }
		   break;
		   }
		   
	case 1016:
    {  
    if(boolean){
       patchBssOffset(rl, "00000040", true);//7
	   patchBssOffset(rl2, "00000040", true);//7
	   patchBssOffset(rl3, "00000040", true);//7
	   patchBssOffset(rl4, "00000040", true);//7
	   patchBssOffset(rl5, "00000040", true);//7
	   patchBssOffset(rl6, "00000040", true);//7
	   

	   }else{
       patchBssOffset(rl, "00008040", true);//7
	   patchBssOffset(rl2, "00008040", true);//7
	   patchBssOffset(rl3, "00008040", true);//7
	   patchBssOffset(rl4, "00008040", true);//7
	   patchBssOffset(rl5, "00008040", true);//7
	   patchBssOffset(rl6, "00008040", true);//7
		   }
		   break;
		   }
		   
	case 1750: { 
	if (value) {
    std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(chemistry, reverseHex, true);
    }
    break;
 } 
 //same process lng sa Cb 
	case 1380:
    {  
    if(boolean){
       patchBssOffset(foul, "00000000", true);//7

	   }else{
       patchBssOffset(foul, "0000003F", true);//7
		   }
		   break;
		   }
		case 1390:
    {  
    if(boolean){
       patchBssOffset(foul2, "00000000", true);//7

	   }else{
       patchBssOffset(foul2, "0000003F", true);//7
		   }
		   break;
		   }   
	case 7030:
    {  
    if(boolean){
       patchBssOffset(swt, "00008040", true);//7
	   patchBssOffset(swt2, "00008040", true);//7
	   patchBssOffset(swt3, "00008040", true);//7
	   patchBssOffset(swt4, "00008040", true);//7
	   patchBssOffset(swt5, "00008040", true);//7
	   patchBssOffset(swt6, "00008040", true);//7

	   }else{
       patchBssOffset(swt, "9A99993E", true);//7
	   patchBssOffset(swt2, "9A99993E", true);//7
	   patchBssOffset(swt3, "9A99993E", true);//7
	   patchBssOffset(swt4, "9A99993E", true);//7
	   patchBssOffset(swt5, "9A99993E", true);//7
	   patchBssOffset(swt6, "9A99993E", true);//7
		   }
		   break;
		   }
	case 1641:
    {  
    if(boolean){
       patchBssOffset(nvs1, "0000C842", true);//7

	   }else{
       patchBssOffset(nvs1, "00000000", true);//7
		   }
		   break;
		   }
	case 1640:
    {  
    if(boolean){
       patchBssOffset(nv8, "0000C842", true);//7

	   }else{
       patchBssOffset(nv8, "00000000", true);//7
		   }
		   break;
		   }
		   
	case 1639:
    {  
    if(boolean){
       patchBssOffset(nv7, "0000C842", true);//7

	   }else{
       patchBssOffset(nv7, "00000000", true);//7
		   }
		   break;
		   }
	case 7084: {
       
            switch (value){
           case 0:
           stats1 = ReadMemoryAsHex(stat, 4);
           stats2 = ReadMemoryAsHex(stat2, 4);
           stats3 = ReadMemoryAsHex(stat3, 4);
           stats4 = ReadMemoryAsHex(stat4, 4);
           stats5 = ReadMemoryAsHex(stat5, 4);
           stats6 = ReadMemoryAsHex(stat6, 4);
           stats7 = ReadMemoryAsHex(stat7, 4);
           stats8 = ReadMemoryAsHex(stat8, 4);
           stats9 = ReadMemoryAsHex(stat9, 4);
           stats10 = ReadMemoryAsHex(stat10, 4);
           stats11 = ReadMemoryAsHex(stat11, 4);
           stats12 = ReadMemoryAsHex(stat12, 4);
           stats13 = ReadMemoryAsHex(stat13, 4);
           stats14 = ReadMemoryAsHex(stat14, 4);
           stats15 = ReadMemoryAsHex(stat15, 4);
           stats16 = ReadMemoryAsHex(stat16, 4);
           stats17 = ReadMemoryAsHex(stat17, 4);
           stats18 = ReadMemoryAsHex(stat18, 4);
           stats19 = ReadMemoryAsHex(stat19, 4);
           stats20 = ReadMemoryAsHex(stat20, 4);
           stats21 = ReadMemoryAsHex(stat21, 4);
           stats22 = ReadMemoryAsHex(stat22, 4);
           stats23 = ReadMemoryAsHex(stat23, 4);
           stats24 = ReadMemoryAsHex(stat24, 4);
           
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(fstatsoption1, originalFstatsID, true);
          case 1:
           stats1 = ReadMemoryAsHex(stat, 4);
           stats2 = ReadMemoryAsHex(stat2, 4);
           stats3 = ReadMemoryAsHex(stat3, 4);
           stats4 = ReadMemoryAsHex(stat4, 4);
           stats5 = ReadMemoryAsHex(stat5, 4);
           stats6 = ReadMemoryAsHex(stat6, 4);
           stats7 = ReadMemoryAsHex(stat7, 4);
           stats8 = ReadMemoryAsHex(stat8, 4);
           stats9 = ReadMemoryAsHex(stat9, 4);
           stats10 = ReadMemoryAsHex(stat10, 4);
           stats11 = ReadMemoryAsHex(stat11, 4);
           stats12 = ReadMemoryAsHex(stat12, 4);
           stats13 = ReadMemoryAsHex(stat13, 4);
           stats14 = ReadMemoryAsHex(stat14, 4);
           stats15 = ReadMemoryAsHex(stat15, 4);
           stats16 = ReadMemoryAsHex(stat16, 4);
           stats17 = ReadMemoryAsHex(stat17, 4);
           stats18 = ReadMemoryAsHex(stat18, 4);
           stats19 = ReadMemoryAsHex(stat19, 4);
           stats20 = ReadMemoryAsHex(stat20, 4);
           stats21 = ReadMemoryAsHex(stat21, 4);
           stats22 = ReadMemoryAsHex(stat22, 4);
           stats23 = ReadMemoryAsHex(stat23, 4);
           stats24 = ReadMemoryAsHex(stat24, 4);
           break;     
		   
           case 2:
             patchBssOffset(stat, stats1, true);
             patchBssOffset(stat2, stats2, true);      
             patchBssOffset(stat3, stats3, true);
             patchBssOffset(stat4, stats4, true);      
             patchBssOffset(stat5, stats5, true);
             patchBssOffset(stat6, stats6, true);      
             patchBssOffset(stat7, stats7, true);
             patchBssOffset(stat8, stats8, true);      
             patchBssOffset(stat9, stats9, true);
             patchBssOffset(stat10, stats10, true);      
             patchBssOffset(stat11, stats11, true);
             patchBssOffset(stat12, stats12, true);      
             patchBssOffset(stat17, stats13, true);
             patchBssOffset(stat14, stats14, true);      
             patchBssOffset(stat15, stats15, true);
             patchBssOffset(stat16, stats16, true);
             patchBssOffset(stat17, stats17, true);   
             patchBssOffset(stat18, stats18, true);         
             patchBssOffset(stat19, stats19, true);         
             patchBssOffset(stat20, stats20, true);         
             patchBssOffset(stat21, stats21, true);         
             patchBssOffset(stat22, stats22, true);         
             patchBssOffset(stat23, stats23, true);         
             patchBssOffset(stat24, stats24, true);         
        
           break;
              }
    break;
  }  
  
	case 7083: {
       
            switch (value){
           case 0:
           tendencies = ReadMemoryAsHex(ovr42, 4);
           tendencies2 = ReadMemoryAsHex(ovr43, 4);
           tendencies3 = ReadMemoryAsHex(ovr44, 4);
           tendencies4 = ReadMemoryAsHex(ovr45, 4);
           tendencies5 = ReadMemoryAsHex(ovr46, 4);
           tendencies6 = ReadMemoryAsHex(ovr47, 4);
           tendencies7 = ReadMemoryAsHex(ovr48, 4);
           tendencies8 = ReadMemoryAsHex(ovr49, 4);
           tendencies9 = ReadMemoryAsHex(ovr50, 4);
           tendencies10 = ReadMemoryAsHex(ovr51, 4);
           tendencies11 = ReadMemoryAsHex(ovr52, 4);
           tendencies12 = ReadMemoryAsHex(ovr53, 4);
           tendencies13 = ReadMemoryAsHex(ovr54, 4);
           tendencies14 = ReadMemoryAsHex(ovr55, 4);
           tendencies15 = ReadMemoryAsHex(ovr56, 4);
           tendencies16 = ReadMemoryAsHex(ovr57, 4);
           tendencies17 = ReadMemoryAsHex(ovr58, 4);
           tendencies18 = ReadMemoryAsHex(ovr59, 4);
           tendencies19 = ReadMemoryAsHex(ovr60, 4);
           tendencies20 = ReadMemoryAsHex(ovr61, 4);
           tendencies21 = ReadMemoryAsHex(ovr62, 4);
           tendencies22 = ReadMemoryAsHex(ovr63, 4);
           tendencies23 = ReadMemoryAsHex(ovr64, 4);
           tendencies24 = ReadMemoryAsHex(ovr65, 4);
           tendencies25 = ReadMemoryAsHex(ovr66, 4);
           tendencies26 = ReadMemoryAsHex(ovr67, 4);
           tendencies27 = ReadMemoryAsHex(ovr68, 4);
           tendencies28 = ReadMemoryAsHex(ovr69, 4);
           tendencies29 = ReadMemoryAsHex(ovr70, 4);
           tendencies30 = ReadMemoryAsHex(ovr71, 4);
           tendencies31 = ReadMemoryAsHex(ovr72, 4);
           tendencies32 = ReadMemoryAsHex(ovr73, 4);
           tendencies33 = ReadMemoryAsHex(ovr74, 4);
           tendencies34 = ReadMemoryAsHex(ovr75, 4);
           tendencies35 = ReadMemoryAsHex(ovr76, 4);
           tendencies36 = ReadMemoryAsHex(ovr77, 4);
           tendencies37 = ReadMemoryAsHex(ovr78, 4);
           tendencies38 = ReadMemoryAsHex(ovr79, 4);
           tendencies39 = ReadMemoryAsHex(ovr80, 4);
           tendencies40 = ReadMemoryAsHex(ovr81, 4);
           tendencies41 = ReadMemoryAsHex(ovr82, 4);
           tendencies42 = ReadMemoryAsHex(ovr83, 4);
           tendencies43 = ReadMemoryAsHex(ovr84, 4);
           tendencies44 = ReadMemoryAsHex(ovr85, 4);
           tendencies45 = ReadMemoryAsHex(ovr86, 4);
           tendencies46 = ReadMemoryAsHex(ovr87, 4);
           tendencies47 = ReadMemoryAsHex(ovr88, 4);
           tendencies48 = ReadMemoryAsHex(ovr89, 4);
           tendencies49 = ReadMemoryAsHex(ovr90, 4);
           tendencies50 = ReadMemoryAsHex(ovr91, 4);
           tendencies51 = ReadMemoryAsHex(ovr92, 4);
           tendencies52 = ReadMemoryAsHex(ovr93, 4);
           tendencies53 = ReadMemoryAsHex(ovr94, 4);
           tendencies54 = ReadMemoryAsHex(ovr95, 4);
           tendencies55 = ReadMemoryAsHex(ovr96, 4);
           tendencies56 = ReadMemoryAsHex(ovr97, 4);
           tendencies57 = ReadMemoryAsHex(ovr98, 4);
           tendencies58 = ReadMemoryAsHex(ovr99, 4);
           tendencies59 = ReadMemoryAsHex(ovr100, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(ftendenciesoption1, originalFtendenciesID, true);
          case 1:
              tendencies = ReadMemoryAsHex(ovr42, 4);
           tendencies2 = ReadMemoryAsHex(ovr43, 4);
           tendencies3 = ReadMemoryAsHex(ovr44, 4);
           tendencies4 = ReadMemoryAsHex(ovr45, 4);
           tendencies5 = ReadMemoryAsHex(ovr46, 4);
           tendencies6 = ReadMemoryAsHex(ovr47, 4);
           tendencies7 = ReadMemoryAsHex(ovr48, 4);
           tendencies8 = ReadMemoryAsHex(ovr49, 4);
           tendencies9 = ReadMemoryAsHex(ovr50, 4);
           tendencies10 = ReadMemoryAsHex(ovr51, 4);
           tendencies11 = ReadMemoryAsHex(ovr52, 4);
           tendencies12 = ReadMemoryAsHex(ovr53, 4);
           tendencies13 = ReadMemoryAsHex(ovr54, 4);
           tendencies14 = ReadMemoryAsHex(ovr55, 4);
           tendencies15 = ReadMemoryAsHex(ovr56, 4);
           tendencies16 = ReadMemoryAsHex(ovr57, 4);
           tendencies17 = ReadMemoryAsHex(ovr58, 4);
           tendencies18 = ReadMemoryAsHex(ovr59, 4);
           tendencies19 = ReadMemoryAsHex(ovr60, 4);
           tendencies20 = ReadMemoryAsHex(ovr61, 4);
           tendencies21 = ReadMemoryAsHex(ovr62, 4);
           tendencies22 = ReadMemoryAsHex(ovr63, 4);
           tendencies23 = ReadMemoryAsHex(ovr64, 4);
           tendencies24 = ReadMemoryAsHex(ovr65, 4);
           tendencies25 = ReadMemoryAsHex(ovr66, 4);
           tendencies26 = ReadMemoryAsHex(ovr67, 4);
           tendencies27 = ReadMemoryAsHex(ovr68, 4);
           tendencies28 = ReadMemoryAsHex(ovr69, 4);
           tendencies29 = ReadMemoryAsHex(ovr70, 4);
           tendencies30 = ReadMemoryAsHex(ovr71, 4);
           tendencies31 = ReadMemoryAsHex(ovr72, 4);
           tendencies32 = ReadMemoryAsHex(ovr73, 4);
           tendencies33 = ReadMemoryAsHex(ovr74, 4);
           tendencies34 = ReadMemoryAsHex(ovr75, 4);
           tendencies35 = ReadMemoryAsHex(ovr76, 4);
           tendencies36 = ReadMemoryAsHex(ovr77, 4);
           tendencies37 = ReadMemoryAsHex(ovr78, 4);
           tendencies38 = ReadMemoryAsHex(ovr79, 4);
           tendencies39 = ReadMemoryAsHex(ovr80, 4);
           tendencies40 = ReadMemoryAsHex(ovr81, 4);
           tendencies41 = ReadMemoryAsHex(ovr82, 4);
           tendencies42 = ReadMemoryAsHex(ovr83, 4);
           tendencies43 = ReadMemoryAsHex(ovr84, 4);
           tendencies44 = ReadMemoryAsHex(ovr85, 4);
           tendencies45 = ReadMemoryAsHex(ovr86, 4);
           tendencies46 = ReadMemoryAsHex(ovr87, 4);
           tendencies47 = ReadMemoryAsHex(ovr88, 4);
           tendencies48 = ReadMemoryAsHex(ovr89, 4);
           tendencies49 = ReadMemoryAsHex(ovr90, 4);
           tendencies50 = ReadMemoryAsHex(ovr91, 4);
           tendencies51 = ReadMemoryAsHex(ovr92, 4);
           tendencies52 = ReadMemoryAsHex(ovr93, 4);
           tendencies53 = ReadMemoryAsHex(ovr94, 4);
           tendencies54 = ReadMemoryAsHex(ovr95, 4);
           tendencies55 = ReadMemoryAsHex(ovr96, 4);
           tendencies56 = ReadMemoryAsHex(ovr97, 4);
           tendencies57 = ReadMemoryAsHex(ovr98, 4);
           tendencies58 = ReadMemoryAsHex(ovr99, 4);
           tendencies59 = ReadMemoryAsHex(ovr100, 4);
           break;          
           case 2:
             patchBssOffset(ovr42, tendencies, true);
             patchBssOffset(ovr43, tendencies2, true);      
             patchBssOffset(ovr44, tendencies3, true);
             patchBssOffset(ovr45, tendencies4, true);      
             patchBssOffset(ovr46, tendencies5, true);
             patchBssOffset(ovr47, tendencies6, true);      
             patchBssOffset(ovr48, tendencies7, true);
             patchBssOffset(ovr49, tendencies8, true);      
             patchBssOffset(ovr50, tendencies9, true);
             patchBssOffset(ovr51, tendencies10, true);      
             patchBssOffset(ovr52, tendencies11, true);
             patchBssOffset(ovr53, tendencies12, true);      
             patchBssOffset(ovr54, tendencies13, true);
             patchBssOffset(ovr55, tendencies14, true);      
             patchBssOffset(ovr56, tendencies15, true);
             patchBssOffset(ovr57, tendencies16, true);
             patchBssOffset(ovr58, tendencies17, true);   
             patchBssOffset(ovr59, tendencies18, true);         
             patchBssOffset(ovr60, tendencies19, true);         
             patchBssOffset(ovr61, tendencies20, true);         
             patchBssOffset(ovr62, tendencies21, true);         
             patchBssOffset(ovr63, tendencies22, true);         
             patchBssOffset(ovr64, tendencies23, true);         
             patchBssOffset(ovr65, tendencies24, true);         
             patchBssOffset(ovr66, tendencies25, true);         
             patchBssOffset(ovr67, tendencies26, true);         
             patchBssOffset(ovr68, tendencies27, true);         
             patchBssOffset(ovr69, tendencies28, true);         
             patchBssOffset(ovr70, tendencies29, true);         
             patchBssOffset(ovr71, tendencies30, true);         
             patchBssOffset(ovr72, tendencies31, true);         
             patchBssOffset(ovr73, tendencies32, true);         
             patchBssOffset(ovr74, tendencies33, true);         
             patchBssOffset(ovr75, tendencies34, true);         
             patchBssOffset(ovr76, tendencies35, true);         
             patchBssOffset(ovr77, tendencies36, true);         
             patchBssOffset(ovr78, tendencies37, true);         
             patchBssOffset(ovr79, tendencies38, true);         
             patchBssOffset(ovr80, tendencies39, true);         
             patchBssOffset(ovr81, tendencies40, true);         
             patchBssOffset(ovr82, tendencies41, true);     
             patchBssOffset(ovr83, tendencies42, true); 
             patchBssOffset(ovr84, tendencies43, true);      
             patchBssOffset(ovr85, tendencies44, true);        
             patchBssOffset(ovr86, tendencies45, true);            
             patchBssOffset(ovr87, tendencies46, true);                 
             patchBssOffset(ovr88, tendencies47, true);                      
             patchBssOffset(ovr89, tendencies48, true);                          
             patchBssOffset(ovr90, tendencies49, true);                                
             patchBssOffset(ovr91, tendencies50, true);                                     
             patchBssOffset(ovr92, tendencies51, true);                                        
             patchBssOffset(ovr93, tendencies52, true);                                               
             patchBssOffset(ovr94, tendencies53, true);                                                 
             patchBssOffset(ovr95, tendencies54, true);                                                    
             patchBssOffset(ovr96, tendencies55, true);                                                       
             patchBssOffset(ovr97, tendencies56, true);                                                            
             patchBssOffset(ovr98, tendencies57, true);                                                               
             patchBssOffset(ovr99, tendencies58, true);                                                                     
             patchBssOffset(ovr100, tendencies59, true);                                                                             
           break;
              }
    break;
  }  
  
	case 7082: {
       
            switch (value){
           case 0:
           attribute = ReadMemoryAsHex(ovr1, 4);
           attribute2 = ReadMemoryAsHex(ovr2, 4);
           attribute3 = ReadMemoryAsHex(ovr3, 4);
           attribute4 = ReadMemoryAsHex(ovr4, 4);
           attribute5 = ReadMemoryAsHex(ovr5, 4);
           attribute6 = ReadMemoryAsHex(ovr6, 4);
           attribute7 = ReadMemoryAsHex(ovr7, 4);
           attribute8 = ReadMemoryAsHex(ovr8, 4);
           attribute9 = ReadMemoryAsHex(ovr9, 4);
           attribute10 = ReadMemoryAsHex(ovr10, 4);
           attribute11 = ReadMemoryAsHex(ovr11, 4);
           attribute12 = ReadMemoryAsHex(ovr12, 4);
           attribute13 = ReadMemoryAsHex(ovr13, 4);
           attribute14 = ReadMemoryAsHex(ovr14, 4);
           attribute15 = ReadMemoryAsHex(ovr15, 4);
           attribute16 = ReadMemoryAsHex(ovr16, 4);
           attribute17 = ReadMemoryAsHex(ovr17, 4);
           attribute18 = ReadMemoryAsHex(ovr18, 4);
           attribute19 = ReadMemoryAsHex(ovr19, 4);
           attribute20 = ReadMemoryAsHex(ovr20, 4);
           attribute21 = ReadMemoryAsHex(ovr21, 4);
           attribute22 = ReadMemoryAsHex(ovr22, 4);
           attribute23 = ReadMemoryAsHex(ovr23, 4);
           attribute24 = ReadMemoryAsHex(ovr24, 4);
           attribute25 = ReadMemoryAsHex(ovr25, 4);
           attribute26 = ReadMemoryAsHex(ovr26, 4);
           attribute27 = ReadMemoryAsHex(ovr27, 4);
           attribute28 = ReadMemoryAsHex(ovr28, 4);
           attribute29 = ReadMemoryAsHex(ovr29, 4);
           attribute30 = ReadMemoryAsHex(ovr30, 4);
           attribute31 = ReadMemoryAsHex(ovr31, 4);
           attribute32 = ReadMemoryAsHex(ovr32, 4);
           attribute33 = ReadMemoryAsHex(ovr33, 4);
           attribute34 = ReadMemoryAsHex(ovr34, 4);
           attribute35 = ReadMemoryAsHex(ovr35, 4);
           attribute36 = ReadMemoryAsHex(ovr36, 4);
           attribute37 = ReadMemoryAsHex(ovr37, 4);
           attribute38 = ReadMemoryAsHex(ovr38, 4);
           attribute39 = ReadMemoryAsHex(ovr39, 4);
           attribute40 = ReadMemoryAsHex(ovr40, 4);
           attribute41 = ReadMemoryAsHex(ovr41, 4);
           
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(fattributeoption1, originalFattributeID, true);
          case 1:
              attribute = ReadMemoryAsHex(ovr1, 4);
           attribute2 = ReadMemoryAsHex(ovr2, 4);
           attribute3 = ReadMemoryAsHex(ovr3, 4);
           attribute4 = ReadMemoryAsHex(ovr4, 4);
           attribute5 = ReadMemoryAsHex(ovr5, 4);
           attribute6 = ReadMemoryAsHex(ovr6, 4);
           attribute7 = ReadMemoryAsHex(ovr7, 4);
           attribute8 = ReadMemoryAsHex(ovr8, 4);
           attribute9 = ReadMemoryAsHex(ovr9, 4);
           attribute10 = ReadMemoryAsHex(ovr10, 4);
           attribute11 = ReadMemoryAsHex(ovr11, 4);
           attribute12 = ReadMemoryAsHex(ovr12, 4);
           attribute13 = ReadMemoryAsHex(ovr13, 4);
           attribute14 = ReadMemoryAsHex(ovr14, 4);
           attribute15 = ReadMemoryAsHex(ovr15, 4);
           attribute16 = ReadMemoryAsHex(ovr16, 4);
           attribute17 = ReadMemoryAsHex(ovr17, 4);
           attribute18 = ReadMemoryAsHex(ovr18, 4);
           attribute19 = ReadMemoryAsHex(ovr19, 4);
           attribute20 = ReadMemoryAsHex(ovr20, 4);
           attribute21 = ReadMemoryAsHex(ovr21, 4);
           attribute22 = ReadMemoryAsHex(ovr22, 4);
           attribute23 = ReadMemoryAsHex(ovr23, 4);
           attribute24 = ReadMemoryAsHex(ovr24, 4);
           attribute25 = ReadMemoryAsHex(ovr25, 4);
           attribute26 = ReadMemoryAsHex(ovr26, 4);
           attribute27 = ReadMemoryAsHex(ovr27, 4);
           attribute28 = ReadMemoryAsHex(ovr28, 4);
           attribute29 = ReadMemoryAsHex(ovr29, 4);
           attribute30 = ReadMemoryAsHex(ovr30, 4);
           attribute31 = ReadMemoryAsHex(ovr31, 4);
           attribute32 = ReadMemoryAsHex(ovr32, 4);
           attribute33 = ReadMemoryAsHex(ovr33, 4);
           attribute34 = ReadMemoryAsHex(ovr34, 4);
           attribute35 = ReadMemoryAsHex(ovr35, 4);
           attribute36 = ReadMemoryAsHex(ovr36, 4);
           attribute37 = ReadMemoryAsHex(ovr37, 4);
           attribute38 = ReadMemoryAsHex(ovr38, 4);
           attribute39 = ReadMemoryAsHex(ovr39, 4);
           attribute40 = ReadMemoryAsHex(ovr40, 4);
           attribute41 = ReadMemoryAsHex(ovr41, 4);
           break;          
           case 2:
             patchBssOffset(ovr1, attribute, true);
             patchBssOffset(ovr2, attribute2, true);      
             patchBssOffset(ovr3, attribute3, true);
             patchBssOffset(ovr4, attribute4, true);      
             patchBssOffset(ovr5, attribute5, true);
             patchBssOffset(ovr6, attribute6, true);      
             patchBssOffset(ovr7, attribute7, true);
             patchBssOffset(ovr8, attribute8, true);      
             patchBssOffset(ovr9, attribute9, true);
             patchBssOffset(ovr10, attribute10, true);      
             patchBssOffset(ovr11, attribute11, true);
             patchBssOffset(ovr12, attribute12, true);      
             patchBssOffset(ovr17, attribute13, true);
             patchBssOffset(ovr14, attribute14, true);      
             patchBssOffset(ovr15, attribute15, true);
             patchBssOffset(ovr16, attribute16, true);
             patchBssOffset(ovr17, attribute17, true);   
             patchBssOffset(ovr18, attribute18, true);         
             patchBssOffset(ovr19, attribute19, true);         
             patchBssOffset(ovr20, attribute20, true);         
             patchBssOffset(ovr21, attribute21, true);         
             patchBssOffset(ovr22, attribute22, true);         
             patchBssOffset(ovr23, attribute23, true);         
             patchBssOffset(ovr24, attribute24, true);         
             patchBssOffset(ovr25, attribute25, true);         
             patchBssOffset(ovr26, attribute26, true);         
             patchBssOffset(ovr27, attribute27, true);         
             patchBssOffset(ovr28, attribute28, true);         
             patchBssOffset(ovr29, attribute29, true);         
             patchBssOffset(ovr30, attribute30, true);         
             patchBssOffset(ovr31, attribute31, true);         
             patchBssOffset(ovr32, attribute32, true);         
             patchBssOffset(ovr33, attribute33, true);         
             patchBssOffset(ovr34, attribute34, true);         
             patchBssOffset(ovr35, attribute35, true);         
             patchBssOffset(ovr36, attribute36, true);         
             patchBssOffset(ovr37, attribute37, true);         
             patchBssOffset(ovr38, attribute38, true);         
             patchBssOffset(ovr39, attribute39, true);         
             patchBssOffset(ovr40, attribute40, true);         
             patchBssOffset(ovr41, attribute41, true);         
           break;
              }
    break;
  }  
	case 7070: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad, reverseHex, true);
          }  
    break;
  }
  
  case 7071: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad2, reverseHex, true);
          }  
    break;
  }
  
  case 7072: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad3, reverseHex, true);
          }  
    break;
  }
  
  case 7073: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad4, reverseHex, true);
          }  
    break;
  }
  
  case 7074: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad5, reverseHex, true);
          }  
    break;
  }
  
  case 7075: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad6, reverseHex, true);
          }  
    break;
  }
  
  case 7076: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad7, reverseHex, true);
          }  
    break;
  }
  
  case 7077: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad8, reverseHex, true);
          }  
    break;
  }
  
  case 7078: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad9, reverseHex, true);
          }  
    break;
  }
  
  case 7079: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad10, reverseHex, true);
          }  
    break;
  }
  
  case 7080: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad11, reverseHex, true);
          }  
    break;
  }
  
  case 7081: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(bad12, reverseHex, true);
          }  
    break;
  }
  
  case 8000: { 
         if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right
        patchBssOffset(sixers, "CDCC8C3F", true);//1
        patchBssOffset(sixers2, "6666A63F", true);//2
        patchBssOffset(sixers3, "CDCC4C40", true);
        patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
             }else if(value == 2){//back
        patchBssOffset(sixers, "00003041", true);//1
        patchBssOffset(sixers2, "00005041", true);//2
        patchBssOffset(sixers3, "00000042", true);
        patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
        patchBssOffset(crowd5, "CDCCCC3D", true);//5
          patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);     
              }else if(value == 3){
        patchBssOffset(sixers, "9A99993E", true);//1
       patchBssOffset(sixers2, "CDCCCC3E", true);//2
       patchBssOffset(sixers3, "0000803F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);     
                        
           }
    break;
}      
              
      case 8001:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(bucks, "0000803F", true);//1
       patchBssOffset(bucks2, "9A99993F", true);//2
       patchBssOffset(bucks3, "0000C03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
       patchBssOffset(bucks, "00002041", true);//1
       patchBssOffset(bucks2, "00004041", true);//2
       patchBssOffset(bucks3, "00007041", true);
        patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
       }else if(value == 3){
       patchBssOffset(bucks, "9A99993E", true);//1
       patchBssOffset(bucks2, "CDCCCC3E", true);//2
       patchBssOffset(bucks3, "713D0A3F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
                       
       }
       break;
 }; 
         case 8002:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(bulls, "CDCC8C3F", true);//1
       patchBssOffset(bulls2, "CDCC8C3F", true);//2
       patchBssOffset(bulls3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
       patchBssOffset(bulls, "00004041", true);//1
       patchBssOffset(bulls2, "00004041", true);//2
       patchBssOffset(bulls3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
   }else if(value == 3){
       patchBssOffset(bulls, "CDCCCC3E", true);//1
       patchBssOffset(bulls2, "CDCCCC3E", true);//2
       patchBssOffset(bulls3, "CDCC4C3F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
                        
       }
       break;
 }; 
         case 8003:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(cavs, "00000040", true);//1
       patchBssOffset(cavs2, "00000040", true);//2
       patchBssOffset(cavs3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
         }else if(value == 2){
       patchBssOffset(cavs, "00000041", true);//1
       patchBssOffset(cavs2, "00000041", true);//2
       patchBssOffset(cavs3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
    }else if(value == 3){
       patchBssOffset(cavs, "CDCCCC3E", true);//1
       patchBssOffset(cavs2, "CDCCCC3E", true);//2
       patchBssOffset(cavs3, "3333333F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00002040", true);//4
       patchBssOffset(crowds5, "00002040", true);//5
       patchBssOffset(crowd6, "00002040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
             
       }
       break;
 }; 
         case 8004:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(celtics, "0000003F", true);//1
       patchBssOffset(celtics, "0000003F", true);//2
       patchBssOffset(celtics3, "00002040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
	   patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);	
       patchBssOffset(celtics, floatToReverseHex(12), true);//1
       patchBssOffset(celtics, floatToReverseHex(12), true);//2
       patchBssOffset(celtics3, floatToReverseHex(20), true);      
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
      }else if(value == 3){
       patchBssOffset(celtics, "CDCCCC3E", true);//1
       patchBssOffset(celtics, "CDCCCC3E", true);//2
       patchBssOffset(celtics3, "CDCC4C3F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00002040", true);//4
       patchBssOffset(crowds5, "00002040", true);//5
       patchBssOffset(crowd6, "00002040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8005:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(clippers, "6666E63F", true);//1
       patchBssOffset(clippers2, "6666E63F", true);//2
       patchBssOffset(clippers3, "00002040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
       patchBssOffset(clippers, "00009041", true);//1
       patchBssOffset(clippers2, "00009041", true);//2
       patchBssOffset(clippers3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
       }else if(value == 3){
       patchBssOffset(clippers, "3333333F", true);//1
       patchBssOffset(clippers2, "3333333F", true);//2
       patchBssOffset(clippers3, "0000803F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8006:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(memphpis, "CDCCCC3E", true);//1
       patchBssOffset(memphis2, "3333333F", true);//2
       patchBssOffset(memphis3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
         }else if(value == 2){
       patchBssOffset(memphpis, "00008040", true);//1
       patchBssOffset(memphis2, "0000E040", true);//2
       patchBssOffset(memphis3, "0000A841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
      }else if(value == 3){
       patchBssOffset(memphpis, "CDCC4C3E", true);//1
       patchBssOffset(memphis2, "3333B33E", true);//2
       patchBssOffset(memphis3, "0000803F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8007:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(hawks, "0000803F", true);//1
       patchBssOffset(hawks2, "CDCC8C3F", true);//2
       patchBssOffset(hawks3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(hawks, "00002041", true);//1
       patchBssOffset(hawks2, "00003041", true);//2
       patchBssOffset(hawks3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT); 
       }else if(value == 3){
       patchBssOffset(hawks, "CDCCCC3E", true);//1
       patchBssOffset(hawks2, "6666E63E", true);//2
       patchBssOffset(hawks3, "CDCC4C3F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8008:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(heat, "6666A63F", true);//1
       patchBssOffset(heat2, "0000C03F", true);//2
       patchBssOffset(heat3, "CDCC0C40", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
      }else if(value == 2){
       patchBssOffset(heat, "00005041", true);//1
       patchBssOffset(heat2, "00007041", true);//2
       patchBssOffset(heat3, "0000B041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT); 
    }else if(value == 3){
       patchBssOffset(heat, "0000003F", true);//1
       patchBssOffset(heat2, "9A99193F", true);//2
       patchBssOffset(heat3, "0000803F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
        case 8009:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(hornets, "0000803F", true);//1
       patchBssOffset(hornets2, "3333B33F", true);//2
       patchBssOffset(hornets3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
      }else if(value == 2){
       patchBssOffset(hornets, "00002041", true);//1
       patchBssOffset(hornets2, "00006041", true);//2
       patchBssOffset(hornets3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);  
       }else if(value == 3){
       patchBssOffset(hornets, "CDCCCC3E", true);//1
       patchBssOffset(hornets2, "0000003F", true);//2
       patchBssOffset(hornets3, "3333333F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
 
         case 8010:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(jazz, "0000803F", true);//1
       patchBssOffset(jazz2, "9A99993F", true);//2
       patchBssOffset(jazz3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
      }else if(value == 2){
       patchBssOffset(jazz, "00002041", true);//1
       patchBssOffset(jazz2, "00004041", true);//2
       patchBssOffset(jazz3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);  
      }else if(value == 3){
       patchBssOffset(jazz, "3333B33E", true);//1
       patchBssOffset(jazz2, "3D0AD73E", true);//2
       patchBssOffset(jazz3, "9A99193F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8011:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(kings, "0000803F", true);//1
       patchBssOffset(kings2, "9A99993F", true);//2
       patchBssOffset(kings3, "00004040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(kings, "00002041", true);//1
       patchBssOffset(kings2, "00004041", true);//2
       patchBssOffset(kings3, "0000F041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT); 
      }else if(value == 3){
       patchBssOffset(kings, "9A99993E", true);//1
       patchBssOffset(kings2, "6666E63E", true);//2
       patchBssOffset(kings3, "0000C03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8012:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(knicks, "6666663F", true);//1
       patchBssOffset(knicks2, "CDCC8C3F", true);//2
       patchBssOffset(knicks3, "00002040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(knicks, "00001041", true);//1
       patchBssOffset(knicks2, "00003041", true);//2
       patchBssOffset(knicks3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
       }else if(value == 3){
       patchBssOffset(knicks, "CDCCCC3E", true);//1
       patchBssOffset(knicks2, "0000003F", true);//2
       patchBssOffset(knicks3, "0000A03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8013:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(lakers, "3333733F", true);//1
       patchBssOffset(lakers2, "0000803F", true);//2
       patchBssOffset(lakers3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
      }else if(value == 2){
       patchBssOffset(lakers, "00001041", true);//1
       patchBssOffset(lakers2, "00002041", true);//2
       patchBssOffset(lakers3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT); 
       }else if(value == 3){
       patchBssOffset(lakers, "A470BD3E", true);//1
       patchBssOffset(lakers2, "CDCCCC3E", true);//2
       patchBssOffset(lakers3, "6666663F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8014:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(magic, "6666663F", true);//1
       patchBssOffset(magic2, "0000803F", true);//2
       patchBssOffset(magic3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(magic, "00001041", true);//1
       patchBssOffset(magic2, "00002041", true);//2
       patchBssOffset(magic3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(magic, "A470BD3E", true);//1
       patchBssOffset(magic2, "CDCCCC3E", true);//2
       patchBssOffset(magic3, "6666663F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8015:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(mavs, "CDCC4C3F", true);//1
       patchBssOffset(mavs2, "9A99993F", true);//2
       patchBssOffset(mavs3, "00008040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
       patchBssOffset(nets, "00007041", true);//1
       patchBssOffset(nets2, "0000A041", true);//2
       patchBssOffset(nets3, "00002042", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(mavs, "3333B33E", true);//1
       patchBssOffset(mavs2, "0000003F", true);//2
       patchBssOffset(mavs3, "0000A03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8016:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(nets, "0000C03F", true);//1
       patchBssOffset(nets2, "00000040", true);//2
       patchBssOffset(nets3, "00008040", true);
      patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
       patchBssOffset(nets, "00007041", true);//1
       patchBssOffset(nets2, "0000A041", true);//2
       patchBssOffset(nets3, "00002042", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
       }else if(value == 3){
       patchBssOffset(nets, "0000403F", true);//1
       patchBssOffset(nets2, "0000803F", true);//2
       patchBssOffset(nets3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8017:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(den, "0000803F", true);//1
       patchBssOffset(den2, "6666A63F", true);//2
       patchBssOffset(den3, "00002040", true);
      patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(den, "00002041", true);//1
       patchBssOffset(den2, "00005041", true);//2
       patchBssOffset(den3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(den, "0000003F", true);//1
       patchBssOffset(den2, "9A99193F", true);//2
       patchBssOffset(den3, "0000A03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
      
       }
       break;
 }; 
         case 8018:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(ind, "0000803F", true);//1
       patchBssOffset(ind2, "6666A63F", true);//2
       patchBssOffset(ind3, "00002040", true);
	   patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(ind, "00002041", true);//1
       patchBssOffset(ind2, "00005041", true);//2
       patchBssOffset(ind3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
      }else if(value == 3){
       patchBssOffset(ind, "0000003", true);//1
       patchBssOffset(ind2, "9A99193F", true);//2
       patchBssOffset(ind3, "0000A03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
      
	   }
       break;
 }; 
         case 8019:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(nop, "0000803F", true);//1
       patchBssOffset(nop2, "CDCC8C3F", true);//2
       patchBssOffset(nop3, "CDCC0C40", true);
	   patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
        }else if(value == 2){
       patchBssOffset(nop, "00002041", true);//1
       patchBssOffset(nop2, "00003041", true);//2
       patchBssOffset(nop3, "0000B041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
       }else if(value == 3){
       patchBssOffset(nop, "0000003F", true);//1
       patchBssOffset(nop2, "CDCC0C3F", true);//2
       patchBssOffset(nop3, "CDCC8C3F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
	   }
       break;
 }; 
         case 8020:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(det, "CDCC8C3F", true);//1
       patchBssOffset(det2, "9A99993F", true);//2
       patchBssOffset(det3, "00002040", true);
      patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(det, "00003041", true);//1
       patchBssOffset(det2, "00004041", true);//2
       patchBssOffset(det3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(det, "6666E63E", true);//1
       patchBssOffset(det2, "6666E63E", true);//2
       patchBssOffset(det3, "6666663F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
	   }
       break;
 }; 
         case 8021:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(tor, "CDCC4C3F", true);//1
       patchBssOffset(tor2, "0000803F", true);//2
       patchBssOffset(tor3, "CDCC0C40", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(tor, "00000041", true);//1
       patchBssOffset(tor2, "00002041", true);//2
       patchBssOffset(tor3, "0000B041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(tor, "3333B33E", true);//1
       patchBssOffset(tor2, "CDCCCC3E", true);//2
       patchBssOffset(tor3, "6666663F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8022:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(hou, "CDCC8C3F", true);//1
       patchBssOffset(hou2, "6666A63F", true);//2
       patchBssOffset(hou3, "00002040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 2){
       patchBssOffset(hou, "00003041", true);//1
       patchBssOffset(hou2, "00005041", true);//2
       patchBssOffset(hou3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
      }else if(value == 3){
       patchBssOffset(hou, "3333333F", true);//1
       patchBssOffset(hou2, "CDCC4C3F", true);//2
       patchBssOffset(hou3, "0000A03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8023:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(sa, "CDCC4C3F", true);//1
       patchBssOffset(sa2, "9A99993F", true);//2
       patchBssOffset(sa3, "00002040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(sa, "00000041", true);//1
       patchBssOffset(sa2, "00004041", true);//2
       patchBssOffset(sa3, "0000C841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(sa, "3333B33E", true);//1
       patchBssOffset(sa2, "6666E63E", true);//2
       patchBssOffset(sa3, "0000803F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8024:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(suns, "CDCC8C3F", true);//1
       patchBssOffset(suns2, "6666A63F", true);//2
       patchBssOffset(suns3, "33331340", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(suns, "00003041", true);//1
       patchBssOffset(suns2, "00005041", true);//2
       patchBssOffset(suns3, "0000B841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(suns, "3333B33E", true);//1
       patchBssOffset(suns2, "6666E63E", true);//2
       patchBssOffset(suns3, "9A99593F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8025:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(okc, "0000803F", true);//1
       patchBssOffset(okc2, "CDCC8C3F", true);//2
       patchBssOffset(okc3, "00000040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(okc, "00002041", true);//1
       patchBssOffset(okc2, "00003041", true);//2
       patchBssOffset(okc3, "0000A041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(okc, "0000803E", true);//1
       patchBssOffset(okc2, "3333B33E", true);//2
       patchBssOffset(okc3, "3333333F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
         case 8026:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(wolves, "0000803F", true);//1
       patchBssOffset(wolves2, "6666A63F", true);//2
       patchBssOffset(wolves3, "00004040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(wolves, "00002041", true);//1
       patchBssOffset(wolves2, "00005041", true);//2
       patchBssOffset(wolves3, "0000F041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	  }else if(value == 3){
       patchBssOffset(wolves, "CDCCCC3E", true);//1
       patchBssOffset(wolves2, "CDCC0C3F", true);//2
       patchBssOffset(wolves3, "0000A03F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8027:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(blazers, "CDCC8C3F", true);//1
       patchBssOffset(blazers2, "9A99993F", true);//2
       patchBssOffset(blazers3, "9A99D93F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(blazers, "00003041", true);//1
       patchBssOffset(blazers2, "00004041", true);//2
       patchBssOffset(blazers3, "00008841", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	  }else if(value == 3){
       patchBssOffset(blazers, "A470BD3E", true);//1
       patchBssOffset(blazers2, "A470BD3E", true);//2
       patchBssOffset(blazers3, "0000003F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8028:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(gs, "6666A63F", true);//1
       patchBssOffset(gs2, "3333B33F", true);//2
       patchBssOffset(gs3, "00004040", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);
       }else if(value == 2){
       patchBssOffset(gs, "00005041", true);//1
       patchBssOffset(gs2, "00006041", true);//2
       patchBssOffset(gs3, "0000F041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	  }else if(value == 3){
       patchBssOffset(gs, "CDCC0C3F", true);//1
       patchBssOffset(gs2, "9A99193F", true);//2
       patchBssOffset(gs3, "9A99D93F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
        
       }
       break;
 }; 
         case 8029:
    {  
       if (value == 0){  
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<DEFAULT>"),ToastLength::LENGTH_SHORT);
      }else if (value == 1){//right//right  
       patchBssOffset(was, "9A99993F", true);//1
       patchBssOffset(was2, "9A99993F", true);//2
       patchBssOffset(was3, "CDCC0C40", true);
      patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT>"),ToastLength::LENGTH_SHORT);     
       }else if(value == 2){
       patchBssOffset(was, "00004041", true);//1
       patchBssOffset(was2, "00004041", true);//2
       patchBssOffset(was3, "0000B041", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
         patchBssOffset(crowd6, "CDCCCC3D", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND DARK CROWD>"),ToastLength::LENGTH_SHORT);
	   }else if(value == 3){
       patchBssOffset(was, "CDCC0C3F", true);//1
       patchBssOffset(was2, "CDCC0C3F", true);//2
       patchBssOffset(was3, "0000803F", true);
       patchBssOffset(celtics4, floatToReverseHex(2.4), true);
       patchBssOffset(celtics5, floatToReverseHex(0.0647571981), true);
       patchBssOffset(celtics6, floatToReverseHex(-0.46023356915), true);
       patchBssOffset(crowd4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
       Mytoast(env,obj,OBFUSCATE("<HD COURT AND HD CROWD>"),ToastLength::LENGTH_SHORT);
       
       }
       break;
 }; 
	            case 4000:
    {  
    if(boolean){
       patchBssOffset(sixers, "00003041", true);//1
       patchBssOffset(sixers2, "00005041", true);//2
       patchBssOffset(sixers3, "00000042", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
      case 4001:
    {  
    if(boolean){
       patchBssOffset(bucks, "00002041", true);//1
       patchBssOffset(bucks2, "00004041", true);//2
       patchBssOffset(bucks3, "00007041", true);
        patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4002:
    {  
    if(boolean){
       patchBssOffset(bulls, "00004041", true);//1
       patchBssOffset(bulls2, "00004041", true);//2
       patchBssOffset(bulls3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                 
           }
    break;
}
         case 4003:
    {  
    if(boolean){
       patchBssOffset(cavs, "00000041", true);//1
       patchBssOffset(cavs2, "00000041", true);//2
       patchBssOffset(cavs3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                              
           }
    break;
}
         case 4004:
    {  
    if(boolean){
       patchBssOffset(celtics, "00000041", true);//1
       patchBssOffset(celtics, "00000041", true);//2
       patchBssOffset(celtics3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4005:
    {  
    if(boolean){
       patchBssOffset(clippers, "00009041", true);//1
       patchBssOffset(clippers2, "00009041", true);//2
       patchBssOffset(clippers3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4006:
    {  
    if(boolean){
       patchBssOffset(memphpis, "00008040", true);//1
       patchBssOffset(memphis2, "0000E040", true);//2
       patchBssOffset(memphis3, "0000A841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4007:
    {  
    if(boolean){
       patchBssOffset(hawks, "00002041", true);//1
       patchBssOffset(hawks2, "00003041", true);//2
       patchBssOffset(hawks3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4008:
    {  
    if(boolean){
       patchBssOffset(heat, "00005041", true);//1
       patchBssOffset(heat2, "00007041", true);//2
       patchBssOffset(heat3, "0000B041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
        case 4009:
    {  
    if(boolean){
       patchBssOffset(hornets, "00002041", true);//1
       patchBssOffset(hornets2, "00006041", true);//2
       patchBssOffset(hornets3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
 
         case 4010:
    {  
    if(boolean){
       patchBssOffset(jazz, "00002041", true);//1
       patchBssOffset(jazz2, "00004041", true);//2
       patchBssOffset(jazz3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4011:
    {  
    if(boolean){
       patchBssOffset(kings, "00002041", true);//1
       patchBssOffset(kings2, "00004041", true);//2
       patchBssOffset(kings3, "0000F041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4012:
    {  
    if(boolean){
       patchBssOffset(knicks, "00001041", true);//1
       patchBssOffset(knicks2, "00003041", true);//2
       patchBssOffset(knicks3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4013:
    {  
    if(boolean){
       patchBssOffset(lakers, "00001041", true);//1
       patchBssOffset(lakers2, "00002041", true);//2
       patchBssOffset(lakers3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4014:
    {  
    if(boolean){
       patchBssOffset(magic, "00001041", true);//1
       patchBssOffset(magic2, "00002041", true);//2
       patchBssOffset(magic3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4015:
    {  
    if(boolean){
       patchBssOffset(mavs, "00000041", true);//1
       patchBssOffset(mavs2, "00004041", true);//2
       patchBssOffset(mavs3, "00002042", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4016:
    {  
    if(boolean){
       patchBssOffset(nets, "00007041", true);//1
       patchBssOffset(nets2, "0000A041", true);//2
       patchBssOffset(nets3, "00002042", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4017:
    {  
    if(boolean){
       patchBssOffset(den, "00002041", true);//1
       patchBssOffset(den2, "00005041", true);//2
       patchBssOffset(den3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
               
   }
    break;
}
         case 4018:
    {  
    if(boolean){
       patchBssOffset(ind, "00002041", true);//1
       patchBssOffset(ind2, "00005041", true);//2
       patchBssOffset(ind3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                       

   }
    break;
}
         case 4019:
    {  
    if(boolean){
       patchBssOffset(nop, "00002041", true);//1
       patchBssOffset(nop2, "00003041", true);//2
       patchBssOffset(nop3, "0000B041", true);
         patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                       
           }
    break;
}
         case 4020:
    {  
    if(boolean){
       patchBssOffset(det, "00003041", true);//1
       patchBssOffset(det2, "00004041", true);//2
       patchBssOffset(det3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                         
           }
    break;
}
         case 4021:
    {  
    if(boolean){
       patchBssOffset(tor, "00000041", true);//1
       patchBssOffset(tor2, "00002041", true);//2
       patchBssOffset(tor3, "0000B041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4022:
    {  
    if(boolean){
       patchBssOffset(hou, "00003041", true);//1
       patchBssOffset(hou2, "00005041", true);//2
       patchBssOffset(hou3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4023:
    {  
    if(boolean){
       patchBssOffset(sa, "00000041", true);//1
       patchBssOffset(sa2, "00004041", true);//2
       patchBssOffset(sa3, "0000C841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4024:
    {  
    if(boolean){
       patchBssOffset(suns, "00003041", true);//1
       patchBssOffset(suns2, "00005041", true);//2
       patchBssOffset(suns3, "0000B841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4025:
    {  
    if(boolean){
       patchBssOffset(okc, "00002041", true);//1
       patchBssOffset(okc2, "00003041", true);//2
       patchBssOffset(okc3, "0000A041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4026:
    {  
    if(boolean){
       patchBssOffset(wolves, "00002041", true);//1
       patchBssOffset(wolves2, "00005041", true);//2
       patchBssOffset(wolves3, "0000F041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                               
           }
    break;
}
         case 4027:
    {  
    if(boolean){
       patchBssOffset(blazers, "00003041", true);//1
       patchBssOffset(blazers2, "00004041", true);//2
       patchBssOffset(blazers3, "00008841", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4028:
    {  
    if(boolean){
       patchBssOffset(gs, "00005041", true);//1
       patchBssOffset(gs2, "00006041", true);//2
       patchBssOffset(gs3, "0000F041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}
         case 4029:
    {  
    if(boolean){
       patchBssOffset(was, "00004041", true);//1
       patchBssOffset(was2, "00004041", true);//2
       patchBssOffset(was3, "0000B041", true);
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
                                
           }
    break;
}

//hd crowd
case 5000:
    {  
    if(boolean){
       patchBssOffset(sixers, "9A99993E", true);//1
       patchBssOffset(sixers2, "CDCCCC3E", true);//2
       patchBssOffset(sixers3, "0000803F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
      case 5001:
    {  
    if(boolean){
       patchBssOffset(bucks, "9A99993E", true);//1
       patchBssOffset(bucks2, "CDCCCC3E", true);//2
       patchBssOffset(bucks3, "713D0A3F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                       
           }
    break;
}
         case 5002:
    {  
    if(boolean){
       patchBssOffset(bulls, "CDCCCC3E", true);//1
       patchBssOffset(bulls2, "CDCCCC3E", true);//2
       patchBssOffset(bulls3, "CDCC4C3F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5003:
    {  
    if(boolean){
       patchBssOffset(cavs, "CDCCCC3E", true);//1
       patchBssOffset(cavs2, "CDCCCC3E", true);//2
       patchBssOffset(cavs3, "3333333F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5004:
    {  
    if(boolean){
       patchBssOffset(celtics, "CDCCCC3E", true);//1
       patchBssOffset(celtics, "CDCCCC3", true);//2
       patchBssOffset(celtics3, "CDCC4C3F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5005:
    {  
    if(boolean){
       patchBssOffset(clippers, "3333333F", true);//1
       patchBssOffset(clippers2, "3333333F", true);//2
       patchBssOffset(clippers3, "0000803F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5006:
    {  
    if(boolean){
       patchBssOffset(memphpis, "CDCC4C3E", true);//1
       patchBssOffset(memphis2, "3333B33E", true);//2
       patchBssOffset(memphis3, "0000803F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5007:
    {  
    if(boolean){
       patchBssOffset(hawks, "CDCCCC3E", true);//1
       patchBssOffset(hawks2, "6666E63E", true);//2
       patchBssOffset(hawks3, "CDCC4C3F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5008:
    {  
    if(boolean){
       patchBssOffset(heat, "0000003F", true);//1
       patchBssOffset(heat2, "9A99193F", true);//2
       patchBssOffset(heat3, "0000803F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
        case 5009:
    {  
    if(boolean){
       patchBssOffset(hornets, "CDCCCC3E", true);//1
       patchBssOffset(hornets2, "0000003F", true);//2
       patchBssOffset(hornets3, "3333333F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                       
           }
    break;
}
 
         case 5010:
    {  
    if(boolean){
       patchBssOffset(jazz, "3333B33E", true);//1
       patchBssOffset(jazz2, "3D0AD73E", true);//2
       patchBssOffset(jazz3, "9A99193F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5011:
    {  
    if(boolean){
       patchBssOffset(kings, "9A99993E", true);//1
       patchBssOffset(kings2, "6666E63E", true);//2
       patchBssOffset(kings3, "0000C03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5012:
    {  
    if(boolean){
       patchBssOffset(knicks, "CDCCCC3E", true);//1
       patchBssOffset(knicks2, "0000003F", true);//2
       patchBssOffset(knicks3, "0000A03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5013:
    {  
    if(boolean){
       patchBssOffset(lakers, "A470BD3E", true);//1
       patchBssOffset(lakers2, "CDCCCC3E", true);//2
       patchBssOffset(lakers3, "6666663F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5014:
    {  
    if(boolean){
       patchBssOffset(magic, "A470BD3E", true);//1
       patchBssOffset(magic2, "CDCCCC3E", true);//2
       patchBssOffset(magic3, "6666663F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5015:
    {  
    if(boolean){
       patchBssOffset(mavs, "3333B33E", true);//1
       patchBssOffset(mavs2, "0000003F", true);//2
       patchBssOffset(mavs3, "0000A03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5016:
    {  
    if(boolean){
       patchBssOffset(nets, "0000403F", true);//1
       patchBssOffset(nets2, "0000803F", true);//2
       patchBssOffset(nets3, "00000040", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5017:
    {  
    if(boolean){
       patchBssOffset(den, "0000003F", true);//1
       patchBssOffset(den2, "9A99193F", true);//2
       patchBssOffset(den3, "0000A03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
               
   }
    break;
}
         case 5018:
    {  
    if(boolean){
       patchBssOffset(ind, "0000003", true);//1
       patchBssOffset(ind2, "9A99193F", true);//2
       patchBssOffset(ind3, "0000A03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
               
   }
    break;
}
         case 5019:
    {  
    if(boolean){
       patchBssOffset(nop, "0000003F", true);//1
       patchBssOffset(nop2, "CDCC0C3F", true);//2
       patchBssOffset(nop3, "CDCC8C3F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                 
           }
    break;
}
         case 5020:
    {  
    if(boolean){
       patchBssOffset(det, "6666E63E", true);//1
       patchBssOffset(det2, "6666E63E", true);//2
       patchBssOffset(det3, "6666663F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                 
           }
    break;
}
         case 5021:
    {  
    if(boolean){
       patchBssOffset(tor, "3333B33E", true);//1
       patchBssOffset(tor2, "CDCCCC3E", true);//2
       patchBssOffset(tor3, "6666663F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                       
           }
    break;
}
         case 5022:
    {  
    if(boolean){
       patchBssOffset(hou, "3333333F", true);//1
       patchBssOffset(hou2, "CDCC4C3F", true);//2
       patchBssOffset(hou3, "0000A03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                       
           }
    break;
}
         case 5023:
    {  
    if(boolean){
       patchBssOffset(sa, "3333B33E", true);//1
       patchBssOffset(sa2, "6666E63E", true);//2
       patchBssOffset(sa3, "0000803F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                       
           }
    break;
}
         case 5024:
    {  
    if(boolean){
       patchBssOffset(suns, "3333B33E", true);//1
       patchBssOffset(suns2, "6666E63E", true);//2
       patchBssOffset(suns3, "9A99593F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5025:
    {  
    if(boolean){
       patchBssOffset(okc, "0000803E", true);//1
       patchBssOffset(okc2, "3333B33E", true);//2
       patchBssOffset(okc3, "3333333F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5026:
    {  
    if(boolean){
       patchBssOffset(wolves, "CDCCCC3E", true);//1
       patchBssOffset(wolves2, "CDCC0C3F", true);//2
       patchBssOffset(wolves3, "0000A03F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                       
           }
    break;
}
         case 5027:
    {  
    if(boolean){
       patchBssOffset(blazers, "A470BD3E", true);//1
       patchBssOffset(blazers2, "A470BD3E", true);//2
       patchBssOffset(blazers3, "0000003F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}
         case 5028:
    {  
    if(boolean){
       patchBssOffset(gs, "CDCC0C3F", true);//1
       patchBssOffset(gs2, "9A99193F", true);//2
       patchBssOffset(gs3, "9A99D93F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
               
           }
    break;
}
         case 5029:
    {  
    if(boolean){
       patchBssOffset(was, "CDCC0C3F", true);//1
       patchBssOffset(was2, "CDCC0C3F", true);//2
       patchBssOffset(was3, "0000803F", true);
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowd6, "00004040", true);//6
                        
           }
    break;
}

case 7009:
            skin1 = boolean;
            if (skin1) {
                hexPatches.Skins1.Modify();
            } else {
                hexPatches.Skins1.Restore();
            }
            break;
			
			case 7010:
            skin2 = boolean;
            if (skin2) {
                hexPatches.Skins2.Modify();
            } else {
                hexPatches.Skins2.Restore();
            }
            break;
			
			case 32:
            skin3 = boolean;
            if (skin3) {
                hexPatches.Skins3.Modify();
            } else {
                hexPatches.Skins3.Restore();
            }
            break;
			
			case 33:
            skin4 = boolean;
            if (skin4) {
                hexPatches.Skins4.Modify();
            } else {
                hexPatches.Skins4.Restore();
            }
            break;
			
			case 34:
            skin5 = boolean;
            if (skin5) {
                hexPatches.Skins5.Modify();
            } else {
                hexPatches.Skins5.Restore();
            }
            break;
			
			case 7011:
            skin5 = boolean;
            if (skin5) {
                hexPatches.Skins6.Modify();
            } else {
                hexPatches.Skins6.Restore();
            }
            break;
			
			case 36:
            skin7 = boolean;
            if (skin7) {
                hexPatches.Skins7.Modify();
            } else {
                hexPatches.Skins7.Restore();
            }
            break;
			
			case 37:
            portrait = boolean;
            if (portrait) {
                hexPatches.Portrait1.Modify();
            } else {
                hexPatches.Portrait1.Restore();
            }
            break;
			
			case 38:
            portrait2 = boolean;
            if (portrait2) {
                hexPatches.Portrait2.Modify();
            } else {
                hexPatches.Portrait2.Restore();
            }
            break;
			
			case 39:
            portrait3 = boolean;
            if (portrait3) {
                hexPatches.Portrait3.Modify();
            } else {
                hexPatches.Portrait3.Restore();
            }
            break;
			
			case 40:
            portrait4 = boolean;
            if (portrait4) {
                hexPatches.Portrait4.Modify();
            } else {
                hexPatches.Portrait4.Restore();
            }
            break;
			
			case 41:
            portrait5 = boolean;
            if (portrait5) {
                hexPatches.Portrait5.Modify();
            } else {
                hexPatches.Portrait5.Restore();
            }
            break;
			
			case 42:
            portrait6 = boolean;
            if (portrait6) {
                hexPatches.Portrait6.Modify();
            } else {
                hexPatches.Portrait6.Restore();
            }
            break;
			
			case 43:
            portrait7 = boolean;
            if (portrait7) {
                hexPatches.Portrait7.Modify();
            } else {
                hexPatches.Portrait7.Restore();
            }
            break;
	
	case 1076:
            hds = boolean;
            if (hds) {
                hexPatches.Hdacs.Modify();
				hexPatches.Hdacs2.Modify();
            } else {
                hexPatches.Hdacs.Restore();
				hexPatches.Hdacs2.Restore();
            }
            break;
	case 55:
            feature56 = boolean;
            if (feature56) {
                hexPatches.Green1.Modify();
                hexPatches.Green2.Modify();
                hexPatches.Green3.Modify();
                hexPatches.Green4.Modify();
            } else {
                hexPatches.Green1.Restore();
                hexPatches.Green2.Restore();
                hexPatches.Green3.Restore();
                hexPatches.Green4.Restore();                            
            }
            break;  
            
            case 56:
            feature57 = boolean;
            if (feature57) {
                hexPatches.Colors1.Modify();
                hexPatches.Colors2.Modify();
                hexPatches.Colors3.Modify();
                hexPatches.Colors4.Modify();
            } else {
                hexPatches.Colors1.Restore();
                hexPatches.Colors2.Restore();
                hexPatches.Colors3.Restore();
                hexPatches.Colors4.Restore();                            
            }
            break;  
            
            case 57:
            feature58 = boolean;
            if (feature58) {
                hexPatches.Skin1.Modify();
                hexPatches.Skin2.Modify();
                hexPatches.Skin3.Modify();
                hexPatches.Skin4.Modify();
            } else {
                hexPatches.Skin1.Restore();
                hexPatches.Skin2.Restore();
                hexPatches.Skin3.Restore();
                hexPatches.Skin4.Restore();            
            }
            break;  
            
            case 58:
            feature59 = boolean;
            if (feature59) {
                hexPatches.Haircolor1.Modify();
                hexPatches.Haircolor2.Modify();
                hexPatches.Haircolor3.Modify();
                hexPatches.Haircolor4.Modify();
            } else {
                hexPatches.Haircolor1.Restore();
                hexPatches.Haircolor2.Restore();
                hexPatches.Haircolor3.Restore();
                hexPatches.Haircolor4.Restore();            
            }
            break;  
	case 80:
            coins = boolean;
            if (coins) {
                hexPatches.Coins1.Modify();
				hexPatches.Coins2.Modify();
				hexPatches.Coins3.Modify();
				hexPatches.Coins4.Modify();
            } else {
                hexPatches.Coins1.Restore();
				hexPatches.Coins2.Restore();
				hexPatches.Coins3.Restore();
				hexPatches.Coins4.Restore();
            }
            break;
	case 8057:
             wings1 = boolean;
            if (wings1) {
                hexPatches.Wings.Modify();
            } else {
                hexPatches.Wings.Restore();
            }
            break;
			
			case 8058:
            wings2 = boolean;
            if (wings2) {
                hexPatches.Wings2.Modify();
            } else {
                hexPatches.Wings2.Restore();
            }
            break;
			
			case 59:
            wings3 = boolean;
            if (wings3) {
                hexPatches.Wings3.Modify();
            } else {
                hexPatches.Wings3.Restore();
            }
            break;
			
			case 60:
            wings4 = boolean;
            if (wings4) {
                hexPatches.Wings5.Modify();
            } else {
                hexPatches.Wings5.Restore();
            }
            break;
			
			case 61:
            wings5 = boolean;
            if (wings5) {
                hexPatches.Wings5.Modify();
            } else {
                hexPatches.Wings5.Restore();
            }
            break;
			
			case 70:
            wings6 = boolean;
            if (wings6) {
                hexPatches.Wings6.Modify();
            } else {
                hexPatches.Wings6.Restore();
            }
            break;
			
			case 71:
            wings7 = boolean;
            if (wings7) {
                hexPatches.Wings7.Modify();
            } else {
                hexPatches.Wings7.Restore();
            }
            break;
			
	case 1078:
            crwd = boolean;
            if (crwd) {
                hexPatches.Cloths1.Modify();
            } else {
                hexPatches.Cloths1.Restore();
            }
            break;   
            
            case 1079:
            crwd2 = boolean;
            if (crwd2) {
                hexPatches.Cloths2.Modify();
            } else {
                hexPatches.Cloths2.Restore();
            }
            break;   
            
            case 1080:
            crwd3 = boolean;
            if (crwd3) {
                hexPatches.Cloths3.Modify();
            } else {
                hexPatches.Cloths3.Restore();
            }
            break;    
                            
            case 1081:
            crwd4 = boolean;
            if (crwd4) {
                hexPatches.Cloths4.Modify();
            } else {
                hexPatches.Cloths4.Restore();
            }
            break;    
              
            case 1082:
            crwd5 = boolean;
            if (crwd5) {
                hexPatches.Cloths5.Modify();
            } else {
                hexPatches.Cloths5.Restore();
            }
            break;   
            
		case 1006:
            ingam = boolean;
            if (ingam) {
                hexPatches.Hdingame.Modify();
            } else {
                hexPatches.Hdingame.Restore();
            }
            break; 
		   case 220:
            feature27 = boolean;
            if (feature27) {
                hexPatches.Color1.Modify();
            } else {
                hexPatches.Color1.Restore();
            }
            break; 
            
            case 221:
            feature28 = boolean;
            if (feature28) {
                hexPatches.Color2.Modify();
            } else {
                hexPatches.Color2.Restore();
            }
            break; 
            
            case 222:
            feature29 = boolean;
            if (feature29) {
                hexPatches.Color3.Modify();
            } else {
                hexPatches.Color3.Restore();
            }
            break;
            
            case 223:
            feature30 = boolean;
            if (feature30) {
                hexPatches.Neon1.Modify();
            } else {
                hexPatches.Neon1.Restore();
            }
            break;
            
            case 224:
            feature31 = boolean;
            if (feature31) {
                hexPatches.Neon2.Modify();
            } else {
                hexPatches.Neon2.Restore();
            }
            break;
            
            case 225:
            feature32 = boolean;
            if (feature32) {
                hexPatches.Neon3.Modify();
            } else {
                hexPatches.Neon3.Restore();
            }
            break;
			
    case 700:
            fastdunk = boolean;
            if (fastdunk) {
                hexPatches.Fastdunk1.Modify();
				hexPatches.Fastdunk2.Modify();
				hexPatches.Fastdunk3.Modify();
				hexPatches.Fastdunk4.Modify();
				hexPatches.Fastdunk5.Modify();
				hexPatches.Fastdunk6.Modify();
				hexPatches.Fastdunk7.Modify();
            } else {
                hexPatches.Fastdunk1.Restore();
				hexPatches.Fastdunk2.Restore();
				hexPatches.Fastdunk3.Restore();
				hexPatches.Fastdunk4.Restore();		
				hexPatches.Fastdunk5.Restore();
				hexPatches.Fastdunk6.Restore();
				hexPatches.Fastdunk7.Restore();			
            }
            break; 
            
            case 702:
            layup = boolean;
            if (layup) {
                hexPatches.Fastlayup1.Modify();
				hexPatches.Fastlayup2.Modify();
				hexPatches.Fastlayup3.Modify();
				hexPatches.Fastlayup4.Modify();
				hexPatches.Fastlayup5.Modify();
				hexPatches.Fastlayup6.Modify();
				hexPatches.Fastlayup7.Modify();
            } else {
                hexPatches.Fastlayup1.Restore();
				hexPatches.Fastlayup2.Restore();
				hexPatches.Fastlayup3.Restore();
				hexPatches.Fastlayup4.Restore();		
				hexPatches.Fastlayup5.Restore();
				hexPatches.Fastlayup6.Restore();
				hexPatches.Fastlayup7.Restore();			
            }
            break; 
		case 701:
            feature52 = boolean;
            if (feature52) {
                hexPatches.Hangtime1.Modify();
				hexPatches.Hangtime2.Modify();
				hexPatches.Hangtime3.Modify();
				hexPatches.Hangtime4.Modify();
				hexPatches.Hangtime5.Modify();
				hexPatches.Hangtime6.Modify();
				hexPatches.Hangtime7.Modify();
            } else {
                hexPatches.Hangtime1.Restore();
				hexPatches.Hangtime2.Restore();
				hexPatches.Hangtime3.Restore();
				hexPatches.Hangtime4.Restore();		
				hexPatches.Hangtime5.Restore();
				hexPatches.Hangtime6.Restore();
				hexPatches.Hangtime7.Restore();			
            }
            break;
			
		case 3045:
            feature21 = boolean;
            if (feature21) {
                hexPatches.Black1.Modify();
				hexPatches.Black2.Modify();
				hexPatches.Black3.Modify();
				hexPatches.Black4.Modify();
				hexPatches.Black5.Modify();
				hexPatches.Black6.Modify();
				hexPatches.Black7.Modify();
				hexPatches.Black8.Modify();
				hexPatches.Black9.Modify();
				hexPatches.Black10.Modify();
				hexPatches.Black11.Modify();
            } else {
                hexPatches.Black1.Restore();
				hexPatches.Black2.Restore();
				hexPatches.Black3.Restore();
				hexPatches.Black4.Restore();
				hexPatches.Black5.Restore();
				hexPatches.Black6.Restore();
				hexPatches.Black7.Restore();
				hexPatches.Black8.Restore();
				hexPatches.Black9.Restore();
				hexPatches.Black10.Restore();
				hexPatches.Black11.Restore();
            }
            break; 
		case 3043:
            feature1 = boolean;
            if (feature1) {
                hexPatches.Adjuster1.Modify();
            } else {
                hexPatches.Adjuster1.Restore();
            }
            break;
            
            case 3030:
            feature2 = boolean;
            if (feature2) {
                hexPatches.Adjuster2.Modify();
				hexPatches.Adjuster3.Modify();
				hexPatches.Adjuster4.Modify();				
            } else {
                hexPatches.Adjuster2.Restore();
				hexPatches.Adjuster3.Restore();
				hexPatches.Adjuster4.Restore();
            }
            break; 
            
            case 3031:
            feature3 = boolean;
            if (feature3) {
                hexPatches.Adjuster5.Modify();
            } else {
                hexPatches.Adjuster5.Restore();
            }
            break;
            
            case 3032:
            feature4 = boolean;
            if (feature4) {
                hexPatches.Adjuster6.Modify();
				hexPatches.Adjuster7.Modify();
				hexPatches.Adjuster8.Modify();				
            } else {
                hexPatches.Adjuster6.Restore();
				hexPatches.Adjuster7.Restore();
				hexPatches.Adjuster8.Restore();
            }
            break; 
            
            case 3033:
            feature5 = boolean;
            if (feature5) {
                hexPatches.Adjuster9.Modify();
				hexPatches.Adjuster10.Modify();
				hexPatches.Adjuster11.Modify();				
            } else {
                hexPatches.Adjuster9.Restore();
				hexPatches.Adjuster10.Restore();
				hexPatches.Adjuster11.Restore();
            }
            break; 
            
            case 3034:
            feature6 = boolean;
            if (feature6) {
                hexPatches.Adjuster12.Modify();
				hexPatches.Adjuster13.Modify();
				hexPatches.Adjuster14.Modify();				
            } else {
                hexPatches.Adjuster12.Restore();
				hexPatches.Adjuster13.Restore();
				hexPatches.Adjuster41.Restore();
            }
            break; 
            
            case 3035:
            feature7 = boolean;
            if (feature7) {
                hexPatches.Adjuster15.Modify();
				hexPatches.Adjuster16.Modify();
				hexPatches.Adjuster17.Modify();				
            } else {
                hexPatches.Adjuster15.Restore();
				hexPatches.Adjuster16.Restore();
				hexPatches.Adjuster17.Restore();
            }
            break; 
            
            case 3036:
            feature8 = boolean;
            if (feature8) {
                hexPatches.Adjuster18.Modify();
				hexPatches.Adjuster19.Modify();
				hexPatches.Adjuster20.Modify();				
            } else {
                hexPatches.Adjuster18.Restore();
				hexPatches.Adjuster19.Restore();
				hexPatches.Adjuster20.Restore();
            }
            break; 
            
            case 3037:
            feature9 = boolean;
            if (feature9) {
                hexPatches.Adjuster21.Modify();
				hexPatches.Adjuster22.Modify();
				hexPatches.Adjuster23.Modify();				
            } else {
                hexPatches.Adjuster21.Restore();
				hexPatches.Adjuster22.Restore();
				hexPatches.Adjuster23.Restore();
            }
            break; 
            
            case 3038:
            feature10 = boolean;
            if (feature10) {
                hexPatches.Adjuster24.Modify();
				hexPatches.Adjuster25.Modify();
				hexPatches.Adjuster26.Modify();				
            } else {
                hexPatches.Adjuster24.Restore();
				hexPatches.Adjuster25.Restore();
				hexPatches.Adjuster26.Restore();
            }
            break; 
            
            case 3039:
            feature11 = boolean;
            if (feature11) {
                hexPatches.Adjuster27.Modify();
				hexPatches.Adjuster28.Modify();
				hexPatches.Adjuster29.Modify();				
            } else {
                hexPatches.Adjuster27.Restore();
				hexPatches.Adjuster28.Restore();
				hexPatches.Adjuster29.Restore();
            }
            break; 
            
            case 3040:
            feature12 = boolean;
            if (feature12) {
                hexPatches.Adjuster30.Modify();
				hexPatches.Adjuster31.Modify();
				hexPatches.Adjuster31.Modify();				
            } else {
                hexPatches.Adjuster30.Restore();
				hexPatches.Adjuster31.Restore();
				hexPatches.Adjuster32.Restore();
            }
            break; 
            
            case 3041:
            feature13 = boolean;
            if (feature13) {
                hexPatches.Adjuster33.Modify();
				hexPatches.Adjuster34.Modify();
				hexPatches.Adjuster35.Modify();				
            } else {
                hexPatches.Adjuster33.Restore();
				hexPatches.Adjuster34.Restore();
				hexPatches.Adjuster35.Restore();
            }
            break; 
            
            case 3042:
            feature14 = boolean;
            if (feature14) {
                hexPatches.Adjuster36.Modify();
				hexPatches.Adjuster37.Modify();
				hexPatches.Adjuster38.Modify();				
            } else {
                hexPatches.Adjuster36.Restore();
				hexPatches.Adjuster37.Restore();
				hexPatches.Adjuster38.Restore();
            }
            break; 
            
            case 3044:
            feature15 = boolean;
            if (feature15) {
                hexPatches.Adjuster39.Modify();
				hexPatches.Adjuster40.Modify();
				hexPatches.Adjuster41.Modify();				
            } else {
                hexPatches.Adjuster39.Restore();
				hexPatches.Adjuster40.Restore();
				hexPatches.Adjuster41.Restore();
            }
            break; 
			
		case 1005:
            hdpor = boolean;
            if (hdpor) {
                hexPatches.HdPort.Modify();
            } else {
                hexPatches.HdPort.Restore();
            }
            break;
			
		case 1004:
            hdsk = boolean;
            if (hdsk) {
                hexPatches.Jdskin.Modify();
				hexPatches.Jdskin2.Modify();
				hexPatches.Jdskin3.Modify();
				hexPatches.Jdskin4.Modify();
				hexPatches.Jdskin5.Modify();
				hexPatches.Jdskin6.Modify();
            } else {
                hexPatches.Jdskin.Restore();
				hexPatches.Jdskin2.Restore();
				hexPatches.Jdskin3.Restore();
				hexPatches.Jdskin4.Restore();
				hexPatches.Jdskin5.Restore();
				hexPatches.Jdskin6.Restore();
            }
            break;
			
		case 1003:
             sweat = boolean;
            if (sweat) {
                hexPatches.Sweat.Modify();
                hexPatches.Sweat2.Modify();
                hexPatches.Sweat3.Modify();
                hexPatches.Sweat4.Modify();
                hexPatches.Sweat5.Modify();
                hexPatches.Sweat6.Modify();
                hexPatches.Sweat7.Modify();
                hexPatches.Sweat8.Modify();
                hexPatches.Sweat9.Modify();
                hexPatches.Sweat10.Modify();
                hexPatches.Sweat11.Modify();
            } else {
                hexPatches.Sweat.Restore();
                hexPatches.Sweat2.Restore();
                hexPatches.Sweat3.Restore();
                hexPatches.Sweat4.Restore();
                hexPatches.Sweat5.Restore();
                hexPatches.Sweat6.Restore();
                hexPatches.Sweat7.Restore();
                hexPatches.Sweat8.Restore();
                hexPatches.Sweat9.Restore();
                hexPatches.Sweat10.Restore();
                hexPatches.Sweat11.Restore();
            }
            break;
		
		case 1002:
            player = boolean;
            if (player) {            
                hexPatches.Player1.Modify();
                hexPatches.Player2.Modify();
                hexPatches.Player3.Modify();
                hexPatches.Player4.Modify();
                hexPatches.Player5.Modify();
                hexPatches.Player6.Modify();
                hexPatches.Player7.Modify();
                hexPatches.Player8.Modify();
                hexPatches.Player9.Modify();
                hexPatches.Player10.Modify();
                hexPatches.Player11.Modify();
                hexPatches.Player12.Modify();
                hexPatches.Player13.Modify();
                hexPatches.Player14.Modify();
                hexPatches.Player15.Modify();
                hexPatches.Player16.Modify();
                hexPatches.Player17.Modify();
                hexPatches.Player18.Modify();
                hexPatches.Player19.Modify();
                hexPatches.Player20.Modify();
                hexPatches.Player21.Modify();
                hexPatches.Player22.Modify();
                hexPatches.Player23.Modify();
                hexPatches.Player24.Modify();
                hexPatches.Player25.Modify();
                hexPatches.Player26.Modify();
                hexPatches.Player27.Modify();
                hexPatches.Player28.Modify();
                hexPatches.Player29.Modify();
                hexPatches.Player30.Modify();
                hexPatches.Player31.Modify();
                hexPatches.Player32.Modify();
                hexPatches.Player33.Modify();
                hexPatches.Player34.Modify();
                hexPatches.Player35.Modify();
                hexPatches.Player36.Modify();
                hexPatches.Player37.Modify();
                hexPatches.Player38.Modify();
                hexPatches.Player39.Modify();
                hexPatches.Player40.Modify();
                hexPatches.Player41.Modify();
                hexPatches.Player42.Modify();
                hexPatches.Player43.Modify();
                hexPatches.Player44.Modify();
                hexPatches.Player45.Modify();
                hexPatches.Player46.Modify();
                hexPatches.Player47.Modify();
                hexPatches.Player48.Modify();
                hexPatches.Player49.Modify();
                hexPatches.Player50.Modify();
                hexPatches.Player50.Modify();
                hexPatches.Player51.Modify();
                hexPatches.Player52.Modify();
                hexPatches.Player53.Modify();
                hexPatches.Player54.Modify();
                hexPatches.Player55.Modify();
                hexPatches.Player56.Modify();
                hexPatches.Player57.Modify();
                hexPatches.Player58.Modify();
                hexPatches.Player59.Modify();
                hexPatches.Player60.Modify();
                hexPatches.Player61.Modify();
                hexPatches.Player62.Modify();
                hexPatches.Player63.Modify();
                hexPatches.Player64.Modify();
                hexPatches.Player65.Modify();
                hexPatches.Player66.Modify();
                hexPatches.Player67.Modify();
                hexPatches.Player68.Modify();
                hexPatches.Player69.Modify();
                hexPatches.Player70.Modify();
                hexPatches.Player71.Modify();
                hexPatches.Player72.Modify();
                hexPatches.Player73.Modify();
                hexPatches.Player74.Modify();
                hexPatches.Player75.Modify();
                hexPatches.Player76.Modify();
                hexPatches.Player77.Modify();
                hexPatches.Player78.Modify();
                hexPatches.Player79.Modify();
                hexPatches.Player80.Modify();
                hexPatches.Player81.Modify();
                hexPatches.Player82.Modify();
                hexPatches.Player83.Modify();
                hexPatches.Player84.Modify();
                hexPatches.Player85.Modify();
                hexPatches.Player86.Modify();
                hexPatches.Player87.Modify();
                hexPatches.Player88.Modify();
                hexPatches.Player89.Modify();
                hexPatches.Player90.Modify();
                hexPatches.Player91.Modify();
                hexPatches.Player92.Modify();
                hexPatches.Player93.Modify();
                hexPatches.Player94.Modify();
                hexPatches.Player95.Modify();
                hexPatches.Player96.Modify();
                hexPatches.Player97.Modify();
                hexPatches.Player98.Modify();
                hexPatches.Player99.Modify();
                hexPatches.Player100.Modify();
                hexPatches.Player101.Modify();
                hexPatches.Player102.Modify();
                hexPatches.Player103.Modify();
                hexPatches.Player104.Modify();
                hexPatches.Player105.Modify();
                hexPatches.Player106.Modify();
                hexPatches.Player107.Modify();
                hexPatches.Player108.Modify();
                hexPatches.Player109.Modify();
                hexPatches.Player110.Modify();
                hexPatches.Player111.Modify();
                hexPatches.Player112.Modify();
                hexPatches.Player113.Modify();
                hexPatches.Player114.Modify();
                hexPatches.Player115.Modify();
                hexPatches.Player116.Modify();
                hexPatches.Player117.Modify();
                hexPatches.Player118.Modify();
                hexPatches.Player119.Modify();
                hexPatches.Player120.Modify();
                hexPatches.Player121.Modify();
                hexPatches.Player122.Modify();
                hexPatches.Player123.Modify();
                hexPatches.Player124.Modify();
                hexPatches.Player125.Modify();
                hexPatches.Player126.Modify();
                hexPatches.Player127.Modify();
                hexPatches.Player128.Modify();
                hexPatches.Player129.Modify();
                hexPatches.Player130.Modify();
                hexPatches.Player131.Modify();
                hexPatches.Player132.Modify();
                hexPatches.Player133.Modify();
                hexPatches.Player134.Modify();
                hexPatches.Player135.Modify();
                hexPatches.Player136.Modify();
                hexPatches.Player137.Modify();
                hexPatches.Player138.Modify();
                hexPatches.Player139.Modify();
                hexPatches.Player140.Modify();
                hexPatches.Player141.Modify();
                hexPatches.Player142.Modify();
                hexPatches.Player143.Modify();
                hexPatches.Player144.Modify();
                hexPatches.Player145.Modify();
                hexPatches.Player146.Modify();
                hexPatches.Player147.Modify();
                hexPatches.Player148.Modify();
                hexPatches.Player149.Modify();
                hexPatches.Player150.Modify();
                hexPatches.Player151.Modify();
                hexPatches.Player152.Modify();
                hexPatches.Player153.Modify();
                hexPatches.Player154.Modify();
                hexPatches.Player155.Modify();
                hexPatches.Player156.Modify();
                hexPatches.Player157.Modify();
                hexPatches.Player158.Modify();
                hexPatches.Player159.Modify();
                hexPatches.Player160.Modify();
                hexPatches.Player161.Modify();
                hexPatches.Player162.Modify();
                hexPatches.Player163.Modify();
                hexPatches.Player164.Modify();
                hexPatches.Player165.Modify();
                hexPatches.Player166.Modify();
                hexPatches.Player167.Modify();
                hexPatches.Player168.Modify();
                hexPatches.Player169.Modify();
                hexPatches.Player170.Modify();
                hexPatches.Player171.Modify();
                hexPatches.Player172.Modify();
                hexPatches.Player173.Modify();
                hexPatches.Player174.Modify();
                hexPatches.Player175.Modify();
                hexPatches.Player176.Modify();
                hexPatches.Player177.Modify();
                hexPatches.Player178.Modify();
                hexPatches.Player179.Modify();
                hexPatches.Player180.Modify();
                hexPatches.Player181.Modify();
                hexPatches.Player182.Modify();  
                hexPatches.Player183.Modify();
                hexPatches.Player184.Modify();
                hexPatches.Player185.Modify();
                hexPatches.Player186.Modify();
                hexPatches.Player187.Modify();
                hexPatches.Player188.Modify();
                hexPatches.Player189.Modify();
                hexPatches.Player190.Modify();
                hexPatches.Player191.Modify();
                hexPatches.Player192.Modify();
                hexPatches.Player193.Modify();
                hexPatches.Player194.Modify();
                hexPatches.Player195.Modify();
                hexPatches.Player196.Modify();
                hexPatches.Player197.Modify();
                hexPatches.Player198.Modify();
                hexPatches.Player199.Modify();
                hexPatches.Player200.Modify();
                hexPatches.Player201.Modify();
                hexPatches.Player202.Modify();
                hexPatches.Player204.Modify();
                hexPatches.Player205.Modify();
                hexPatches.Player206.Modify();
                hexPatches.Player207.Modify();
                hexPatches.Player208.Modify();
                hexPatches.Player209.Modify();
                hexPatches.Player210.Modify();
                hexPatches.Player211.Modify();
                hexPatches.Player212.Modify();
                hexPatches.Player213.Modify();
                hexPatches.Player214.Modify();
                hexPatches.Player215.Modify();
                hexPatches.Player216.Modify();
                hexPatches.Player217.Modify();
                hexPatches.Player218.Modify();
                hexPatches.Player219.Modify();
                hexPatches.Player220.Modify();
                hexPatches.Player221.Modify();
                hexPatches.Player222.Modify();
                hexPatches.Player223.Modify();
                hexPatches.Player224.Modify();
                hexPatches.Player225.Modify();
                hexPatches.Player226.Modify();
                hexPatches.Player228.Modify();
                hexPatches.Player229.Modify();
                hexPatches.Player230.Modify();
                hexPatches.Player231.Modify();
                hexPatches.Player232.Modify();
                hexPatches.Player233.Modify();
                hexPatches.Player234.Modify();
                hexPatches.Player235.Modify();
                hexPatches.Player236.Modify();
                hexPatches.Player237.Modify();
                hexPatches.Player238.Modify();
                hexPatches.Player239.Modify();
                hexPatches.Player240.Modify();
                hexPatches.Player241.Modify();
                hexPatches.Player242.Modify();
                hexPatches.Player243.Modify();
                hexPatches.Player244.Modify();
                hexPatches.Player245.Modify();
                hexPatches.Player246.Modify();
                hexPatches.Player247.Modify();
                hexPatches.Player248.Modify();
                hexPatches.Player249.Modify();
                hexPatches.Player250.Modify();
                hexPatches.Player251.Modify();
                hexPatches.Player252.Modify();
                hexPatches.Player253.Modify();
                hexPatches.Player254.Modify();
                hexPatches.Player255.Modify();
                hexPatches.Player256.Modify();
            } else {
           hexPatches.Player1.Restore();
           hexPatches.Player2.Restore();
           hexPatches.Player3.Restore();
           hexPatches.Player4.Restore();
           hexPatches.Player5.Restore();
           hexPatches.Player6.Restore();
           hexPatches.Player7.Restore();
           hexPatches.Player8.Restore();
           hexPatches.Player9.Restore();
           hexPatches.Player10.Restore();
           hexPatches.Player11.Restore();
           hexPatches.Player12.Restore();
           hexPatches.Player13.Restore();
           hexPatches.Player14.Restore();
           hexPatches.Player15.Restore();
           hexPatches.Player16.Restore();
           hexPatches.Player17.Restore();
           hexPatches.Player18.Restore();
           hexPatches.Player19.Restore();
           hexPatches.Player20.Restore();
           hexPatches.Player21.Restore();
           hexPatches.Player22.Restore();
           hexPatches.Player23.Restore();
           hexPatches.Player24.Restore();
           hexPatches.Player25.Restore();
           hexPatches.Player26.Restore();
           hexPatches.Player27.Restore();
           hexPatches.Player28.Restore();
           hexPatches.Player29.Restore();
           hexPatches.Player30.Restore();
           hexPatches.Player31.Restore();
           hexPatches.Player32.Restore();
           hexPatches.Player33.Restore();
           hexPatches.Player34.Restore();
           hexPatches.Player35.Restore();
           hexPatches.Player36.Restore();
           hexPatches.Player37.Restore();
           hexPatches.Player38.Restore();
           hexPatches.Player39.Restore();
           hexPatches.Player40.Restore();
           hexPatches.Player41.Restore();
           hexPatches.Player42.Restore();
           hexPatches.Player43.Restore();
           hexPatches.Player44.Restore();
           hexPatches.Player45.Restore();
           hexPatches.Player46.Restore();
           hexPatches.Player47.Restore();
           hexPatches.Player48.Restore();
           hexPatches.Player49.Restore();
           hexPatches.Player50.Restore();
           hexPatches.Player51.Restore();
           hexPatches.Player52.Restore();
           hexPatches.Player53.Restore();
           hexPatches.Player54.Restore();
           hexPatches.Player55.Restore();
           hexPatches.Player56.Restore();
           hexPatches.Player57.Restore();
           hexPatches.Player58.Restore();
           hexPatches.Player59.Restore();
           hexPatches.Player60.Restore();
           hexPatches.Player61.Restore();
           hexPatches.Player62.Restore();
           hexPatches.Player63.Restore();
           hexPatches.Player64.Restore();
           hexPatches.Player65.Restore();
           hexPatches.Player66.Restore();
           hexPatches.Player67.Restore();
           hexPatches.Player68.Restore();
           hexPatches.Player69.Restore();
           hexPatches.Player70.Restore();
           hexPatches.Player71.Restore();
           hexPatches.Player72.Restore();
           hexPatches.Player73.Restore();
           hexPatches.Player74.Restore();
           hexPatches.Player75.Restore();
           hexPatches.Player76.Restore();
           hexPatches.Player77.Restore();
           hexPatches.Player78.Restore();
           hexPatches.Player79.Restore();
           hexPatches.Player80.Restore();
           hexPatches.Player81.Restore();
           hexPatches.Player82.Restore();
           hexPatches.Player83.Restore();
           hexPatches.Player84.Restore();
           hexPatches.Player85.Restore();
           hexPatches.Player86.Restore();
           hexPatches.Player87.Restore();
           hexPatches.Player88.Restore();
           hexPatches.Player89.Restore();
           hexPatches.Player90.Restore();
           hexPatches.Player91.Restore();
           hexPatches.Player92.Restore();
           hexPatches.Player93.Restore();
           hexPatches.Player94.Restore();
           hexPatches.Player95.Restore();
           hexPatches.Player96.Restore();
           hexPatches.Player97.Restore();
           hexPatches.Player98.Restore();
           hexPatches.Player99.Restore();
           hexPatches.Player100.Restore();
           hexPatches.Player101.Restore();
           hexPatches.Player102.Restore();
           hexPatches.Player103.Restore();
           hexPatches.Player104.Restore();
           hexPatches.Player105.Restore();
           hexPatches.Player106.Restore();
           hexPatches.Player107.Restore();
           hexPatches.Player108.Restore();
           hexPatches.Player109.Restore();
           hexPatches.Player110.Restore();
           hexPatches.Player111.Restore();
           hexPatches.Player112.Restore();
           hexPatches.Player113.Restore();
           hexPatches.Player114.Restore();
           hexPatches.Player115.Restore();
           hexPatches.Player116.Restore();
           hexPatches.Player117.Restore();
           hexPatches.Player118.Restore();
           hexPatches.Player119.Restore();
           hexPatches.Player120.Restore();
           hexPatches.Player121.Restore();
           hexPatches.Player122.Restore();
           hexPatches.Player123.Restore();
           hexPatches.Player124.Restore();
           hexPatches.Player125.Restore();
           hexPatches.Player126.Restore();
           hexPatches.Player127.Restore();
           hexPatches.Player128.Restore();
           hexPatches.Player129.Restore();
           hexPatches.Player130.Restore();
           hexPatches.Player131.Restore();
           hexPatches.Player132.Restore();
           hexPatches.Player133.Restore();
           hexPatches.Player134.Restore(); 
           hexPatches.Player135.Restore();
           hexPatches.Player136.Restore();
           hexPatches.Player137.Restore();
           hexPatches.Player138.Restore();
           hexPatches.Player139.Restore();
           hexPatches.Player140.Restore();
           hexPatches.Player141.Restore();
           hexPatches.Player142.Restore();
           hexPatches.Player143.Restore();
           hexPatches.Player144.Restore();
           hexPatches.Player145.Restore();
           hexPatches.Player146.Restore();
           hexPatches.Player147.Restore();
           hexPatches.Player148.Restore();
           hexPatches.Player149.Restore();
           hexPatches.Player150.Restore();
           hexPatches.Player151.Restore();
           hexPatches.Player152.Restore();
           hexPatches.Player153.Restore();
           hexPatches.Player154.Restore();
           hexPatches.Player155.Restore();
           hexPatches.Player156.Restore();
           hexPatches.Player157.Restore();
           hexPatches.Player158.Restore();
           hexPatches.Player159.Restore();
           hexPatches.Player160.Restore();
           hexPatches.Player161.Restore();
           hexPatches.Player162.Restore();
           hexPatches.Player163.Restore();
           hexPatches.Player164.Restore();
           hexPatches.Player165.Restore();
           hexPatches.Player166.Restore();
           hexPatches.Player167.Restore();
           hexPatches.Player168.Restore();
           hexPatches.Player169.Restore();
           hexPatches.Player170.Restore();
           hexPatches.Player171.Restore();
           hexPatches.Player172.Restore();
           hexPatches.Player173.Restore();
           hexPatches.Player174.Restore();
           hexPatches.Player175.Restore();
           hexPatches.Player176.Restore();
           hexPatches.Player177.Restore();
           hexPatches.Player178.Restore();
           hexPatches.Player179.Restore();
           hexPatches.Player180.Restore();
           hexPatches.Player181.Restore();
           hexPatches.Player182.Restore();
           hexPatches.Player183.Restore();
           hexPatches.Player184.Restore();
           hexPatches.Player185.Restore();
           hexPatches.Player186.Restore();
           hexPatches.Player187.Restore();
           hexPatches.Player188.Restore();
           hexPatches.Player189.Restore();
           hexPatches.Player190.Restore();
           hexPatches.Player191.Restore();
           hexPatches.Player192.Restore();
           hexPatches.Player193.Restore();
           hexPatches.Player194.Restore();
           hexPatches.Player195.Restore();
           hexPatches.Player196.Restore();
           hexPatches.Player197.Restore();
           hexPatches.Player198.Restore();
           hexPatches.Player200.Restore();
           hexPatches.Player201.Restore();
           hexPatches.Player202.Restore();
           hexPatches.Player203.Restore();
           hexPatches.Player204.Restore();
           hexPatches.Player205.Restore();
           hexPatches.Player206.Restore();
           hexPatches.Player207.Restore();
           hexPatches.Player208.Restore();
           hexPatches.Player209.Restore();
           hexPatches.Player210.Restore();
           hexPatches.Player211.Restore();
           hexPatches.Player212.Restore();
           hexPatches.Player213.Restore();
           hexPatches.Player214.Restore();
           hexPatches.Player215.Restore();
           hexPatches.Player216.Restore();
           hexPatches.Player217.Restore();
           hexPatches.Player218.Restore();
           hexPatches.Player219.Restore();
           hexPatches.Player220.Restore();
           hexPatches.Player221.Restore();
           hexPatches.Player222.Restore();
           hexPatches.Player223.Restore();
           hexPatches.Player224.Restore();
           hexPatches.Player225.Restore();
           hexPatches.Player226.Restore();
           hexPatches.Player227.Restore();
           hexPatches.Player228.Restore();
           hexPatches.Player229.Restore();
           hexPatches.Player230.Restore();
           hexPatches.Player231.Restore();
           hexPatches.Player232.Restore();
           hexPatches.Player233.Restore();
           hexPatches.Player234.Restore();
           hexPatches.Player235.Restore();
           hexPatches.Player236.Restore();
           hexPatches.Player237.Restore();
           hexPatches.Player238.Restore();
           hexPatches.Player239.Restore();
           hexPatches.Player240.Restore();
           hexPatches.Player241.Restore();
           hexPatches.Player242.Restore();
           hexPatches.Player243.Restore();
           hexPatches.Player244.Restore();
           hexPatches.Player245.Restore();
           hexPatches.Player246.Restore();
           hexPatches.Player247.Restore();
           hexPatches.Player248.Restore();
           hexPatches.Player249.Restore();
           hexPatches.Player250.Restore();
           hexPatches.Player251.Restore();
           hexPatches.Player252.Restore();
           hexPatches.Player253.Restore();
           hexPatches.Player254.Restore();
           hexPatches.Player255.Restore();
           hexPatches.Player256.Restore();
            }
            break;
		
		case 401:
            black = boolean;
            if (black) {
                hexPatches.Blackball1.Modify();
				hexPatches.Blackball2.Modify();
				hexPatches.Blackball3.Modify();
				hexPatches.Blackball4.Modify();
            } else {
                hexPatches.Blackball1.Restore();
				hexPatches.Blackball2.Restore();
				hexPatches.Blackball3.Restore();
				hexPatches.Blackball4.Restore();
            }
            break;
			
		    case 402:
            world = boolean;
            if (world) {
                hexPatches.Worldball1.Modify();
				hexPatches.Worldball2.Modify();
				hexPatches.Worldball3.Modify();
				hexPatches.Worldball4.Modify();
            } else {
                hexPatches.Worldball1.Restore();
				hexPatches.Worldball2.Restore();
				hexPatches.Worldball3.Restore();
				hexPatches.Worldball4.Restore();
            }
            break;
			
		    case 403:
            aba = boolean;
            if (aba) {
                hexPatches.Ababall1.Modify();
            } else {
                hexPatches.Ababall1.Restore();
            }
            break;
            
            case 410:
             cam1 = boolean;
            if (cam1) {
                hexPatches.Cam1.Modify();
            } else {
                hexPatches.Cam1.Restore();
            }
            break;
            
            case 411:
            cam2 = boolean;
            if (cam2) {
                hexPatches.Cam2.Modify();
            } else {
                hexPatches.Cam2.Restore();
            }
            break;
            
            case 412:
            cam3 = boolean;
            if (cam3) {
                hexPatches.Cam3.Modify();
            } else {
                hexPatches.Cam3.Restore();
            }
            break;
            
            case 413:
            cam4 = boolean;
            if (cam4) {
                hexPatches.Cam4.Modify();
            } else {
                hexPatches.Cam4.Restore();
            }
            break;
            
            case 414:
            cam5 = boolean;
            if (cam5) {
                hexPatches.Cam5.Modify();
            } else {
                hexPatches.Cam5.Restore();
            }
            break;
            
            case 415:
            cam6 = boolean;
            if (cam6) {
                hexPatches.Cam6.Modify();
            } else {
                hexPatches.Cam6.Restore();
            }
            break;
            
            case 416:
            cam7 = boolean;
            if (cam7) {
                hexPatches.Cam7.Modify();
            } else {
                hexPatches.Cam7.Restore();
            }
            break;
            
            case 417:
            cam8 = boolean;
            if (cam8) {
                hexPatches.Cam8.Modify();
            } else {
                hexPatches.Cam8.Restore();
            }
            break;
            
            case 418:
            cam9 = boolean;
            if (cam9) {
                hexPatches.Cam9.Modify();
            } else {
                hexPatches.Cam9.Restore();
            }
            break;
            
            case 419:
            cam10 = boolean;
            if (cam10) {
                hexPatches.Cam10.Modify();
            } else {
                hexPatches.Cam10.Restore();
            }
            break;
			
			case 11:
            shot = boolean;
            if (shot) {
                hexPatches.Shot.Modify();
            } else {
                hexPatches.Shot.Restore();
            }
            break;
			
			case 12:
            com = boolean;
            if (com) {
                hexPatches.Commentator.Modify();
            } else {
                hexPatches.Commentator.Restore();
            }
            break;
			
		case 400:
            euro = boolean;
            if (euro) {
                hexPatches.Euro.Modify();
				hexPatches.Euro2.Modify();
				hexPatches.Euro3.Modify();
				hexPatches.Euro4.Modify();
            } else {
                hexPatches.Euro.Restore();
				hexPatches.Euro2.Restore();
				hexPatches.Euro3.Restore();
				hexPatches.Euro4.Restore();
            }
            break;
			
			case 17:
            speed = boolean;
            if (speed) {
                hexPatches.Speed1.Modify();
            } else {
                hexPatches.Speed1.Restore();
            }
            break;
			
			case 18:
            speed2 = boolean;
            if (speed2) {
                hexPatches.Speed2.Modify();
            } else {
                hexPatches.Speed2.Restore();
            }
            break;
			
			case 19:
            speed3 = boolean;
            if (speed3) {
                hexPatches.Speed3.Modify();
            } else {
                hexPatches.Speed3.Restore();
            }
            break;
			
			case 20:
            speed4 = boolean;
            if (speed4) {
                hexPatches.Speed4.Modify();
            } else {
                hexPatches.Speed4.Restore();
            }
            break;
			
			case 21:
            vert = boolean;
            if (vert) {
                hexPatches.Vertical1.Modify();
            } else {
                hexPatches.Vertical1.Restore();
            }
            break;
			
			case 22:
            vert2 = boolean;
            if (vert2) {
                hexPatches.Vertical2.Modify();
            } else {
                hexPatches.Vertical2.Restore();
            }
            break;
			
			case 23:
            vert3 = boolean;
            if (vert3) {
                hexPatches.Vertical3.Modify();
            } else {
                hexPatches.Vertical3.Restore();
            }
            break;
			
			case 24:
            vert4 = boolean;
            if (vert4) {
                hexPatches.Vertical4.Modify();
            } else {
                hexPatches.Vertical4.Restore();
            }
            break;
			
			case 540:
            all = boolean;
            if (all) {
                hexPatches.All.Modify();
            } else {
                hexPatches.All.Restore();
            }
            break;
			
			case 35:
            anklebreak = boolean;
            if (anklebreak) {
                hexPatches.Anklebreaker1.Modify();
				hexPatches.Anklebreaker2.Modify();
				hexPatches.Anklebreaker3.Modify();
				hexPatches.Anklebreaker4.Modify();
				hexPatches.Anklebreaker5.Modify();
				hexPatches.Anklebreaker6.Modify();
				hexPatches.Anklebreaker7.Modify();
				hexPatches.Anklebreaker8.Modify();
            } else {
                hexPatches.Anklebreaker1.Restore();
				hexPatches.Anklebreaker2.Restore();
				hexPatches.Anklebreaker3.Restore();
				hexPatches.Anklebreaker4.Restore();
				hexPatches.Anklebreaker5.Restore();
				hexPatches.Anklebreaker6.Restore();
				hexPatches.Anklebreaker7.Restore();
				hexPatches.Anklebreaker8.Restore();
            }
            break;
			
			case 26:
            dribble = boolean;
            if (dribble) {
                hexPatches.Dribble.Modify();
            } else {
                hexPatches.Dribble.Restore();
            }
            break;
			
			case 27:
            dribble2 = boolean;
            if (dribble2) {
                hexPatches.Dribble2.Modify();
            } else {
                hexPatches.Dribble2.Restore();
            }
            break;
			
			case 28:
            dribble3 = boolean;
            if (dribble3) {
                hexPatches.Dribble3.Modify();
            } else {
                hexPatches.Dribble3.Restore();
            }
            break;
			
			case 29:
            dribble4 = boolean;
            if (dribble4) {
                hexPatches.Dribble4.Modify();
            } else {
                hexPatches.Dribble4.Restore();
            }
            break;
			
			case 922: {
       if(boolean){
        patchBssOffset(mc1, "00000000", true);
		Mytoast(env,obj,OBFUSCATE("<QUARTER ENDED>"),ToastLength::LENGTH_SHORT);

  }
    break;
}
           case 970: {
       if(boolean){
		 std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(mc2, reverseHex, true);
   }
    break;
}

           case 924: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(mc3, reverseHex, true);
          }  
    break;
  }   
       case 971: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(mc4, reverseHex, true);
          }  
    break;
  }   
			
	case 505: {
     
       uintptr_t colorR = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0")); // Example offset       
      float mh = 1.0f;
      float mxh = 10.0f;

       if (value) {
        float scaledValue = mh / mxh + ((value / mxh) * (1.0f - mh / mxh)); 
        std::string reverseHex = floatToReverseHex(scaledValue); // E.g., "0000FAC3"
        patchBssOffset(colorR, reverseHex, true);
    }
    break;
  }    
   
      case 506: {
         uintptr_t colorG = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4")); // Example offset       
      float mh = 1.0f;
      float mxh = 10.0f;

       if (value) {
        float scaledValue = mh / mxh + ((value / mxh) * (1.0f - mh / mxh)); 
        std::string reverseHex = floatToReverseHex(scaledValue); // E.g., "0000FAC3"
        patchBssOffset(colorG, reverseHex, true);
    }
    break;
 }  
   
      case 507: {
          uintptr_t colorB = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8")); // Example offset       
      float mh = 1.0f;
      float mxh = 10.0f;

       if (value) {
        float scaledValue = mh / mxh + ((value / mxh) * (1.0f - mh / mxh)); 
        std::string reverseHex = floatToReverseHex(scaledValue); // E.g., "0000FAC3"

        // Apply the patch
        patchBssOffset(colorB, reverseHex, true);
    }
    break;
 } 
			
			case 3000:
    {  
    if(boolean){
       patchBssOffset(sixers, "CDCC8C3F", true);//1
       patchBssOffset(sixers2, "6666A63F", true);//2
       patchBssOffset(sixers3, "CDCC4C40", true);
       
       }
       break;
 };   
      case 3001:
    {  
    if(boolean){
       patchBssOffset(bucks, "0000803F", true);//1
       patchBssOffset(bucks2, "9A99993F", true);//2
       patchBssOffset(bucks3, "0000C03F", true);
 
       }
       break;
 }; 
         case 3002:
    {  
    if(boolean){
       patchBssOffset(bulls, "CDCC8C3F", true);//1
       patchBssOffset(bulls2, "CDCC8C3F", true);//2
       patchBssOffset(bulls3, "00000040", true);
   
       }
       break;
 }; 
         case 3003:
    {  
    if(boolean){
       patchBssOffset(cavs, "00000040", true);//1
       patchBssOffset(cavs2, "00000040", true);//2
       patchBssOffset(cavs3, "00000040", true);
    
       }
       break;
 }; 
         case 3004:
    {  
    if(boolean){
       patchBssOffset(celtics, "0000003F", true);//1
       patchBssOffset(celtics, "0000003F", true);//2
       patchBssOffset(celtics3, "00002040", true);
      
       }
       break;
 }; 
         case 3005:
    {  
    if(boolean){
       patchBssOffset(clippers, "6666E63F", true);//1
       patchBssOffset(clippers2, "6666E63F", true);//2
       patchBssOffset(clippers3, "00002040", true);
       
       }
       break;
 }; 
         case 3006:
    {  
    if(boolean){
       patchBssOffset(memphpis, "CDCCCC3E", true);//1
       patchBssOffset(memphis2, "3333333F", true);//2
       patchBssOffset(memphis3, "00000040", true);
      
       }
       break;
 }; 
         case 3007:
    {  
    if(boolean){
       patchBssOffset(hawks, "0000803F", true);//1
       patchBssOffset(hawks2, "CDCC8C3F", true);//2
       patchBssOffset(hawks3, "00000040", true);
       
       }
       break;
 }; 
         case 3008:
    {  
    if(boolean){
       patchBssOffset(heat, "6666A63F", true);//1
       patchBssOffset(heat2, "0000C03F", true);//2
       patchBssOffset(heat3, "CDCC0C40", true);
    
       }
       break;
 }; 
        case 3009:
    {  
    if(boolean){
       patchBssOffset(hornets, "0000803F", true);//1
       patchBssOffset(hornets2, "3333B33F", true);//2
       patchBssOffset(hornets3, "00000040", true);
       
       }
       break;
 }; 
 
         case 3010:
    {  
    if(boolean){
       patchBssOffset(jazz, "0000803F", true);//1
       patchBssOffset(jazz2, "9A99993F", true);//2
       patchBssOffset(jazz3, "00000040", true);
       
       }
       break;
 }; 
         case 3011:
    {  
    if(boolean){
       patchBssOffset(kings, "0000803F", true);//1
       patchBssOffset(kings2, "9A99993F", true);//2
       patchBssOffset(kings3, "00004040", true);
       
       }
       break;
 }; 
         case 3012:
    {  
    if(boolean){
       patchBssOffset(knicks, "6666663F", true);//1
       patchBssOffset(knicks2, "CDCC8C3F", true);//2
       patchBssOffset(knicks3, "00002040", true);
       
       }
       break;
 }; 
         case 3013:
    {  
    if(boolean){
       patchBssOffset(lakers, "3333733F", true);//1
       patchBssOffset(lakers2, "0000803F", true);//2
       patchBssOffset(lakers3, "00000040", true);
       
       }
       break;
 }; 
         case 3014:
    {  
    if(boolean){
       patchBssOffset(magic, "6666663F", true);//1
       patchBssOffset(magic2, "0000803F", true);//2
       patchBssOffset(magic3, "00000040", true);
       
       }
       break;
 }; 
         case 3015:
    {  
    if(boolean){
       patchBssOffset(mavs, "CDCC4C3F", true);//1
       patchBssOffset(mavs2, "9A99993F", true);//2
       patchBssOffset(mavs3, "00008040", true);
       
       }
       break;
 }; 
         case 3016:
    {  
    if(boolean){
       patchBssOffset(nets, "0000C03F", true);//1
       patchBssOffset(nets2, "00000040", true);//2
       patchBssOffset(nets3, "00008040", true);
      
       }
       break;
 }; 
         case 3017:
    {  
    if(boolean){
       patchBssOffset(den, "0000803F", true);//1
       patchBssOffset(den2, "6666A63F", true);//2
       patchBssOffset(den3, "00002040", true);
      
       }
       break;
 }; 
         case 3018:
    {  
    if(boolean){
       patchBssOffset(ind, "0000803F", true);//1
       patchBssOffset(ind2, "6666A63F", true);//2
       patchBssOffset(ind3, "00002040", true);
	   
       }
       break;
 }; 
         case 3019:
    {  
    if(boolean){
       patchBssOffset(nop, "0000803F", true);//1
       patchBssOffset(nop2, "CDCC8C3F", true);//2
       patchBssOffset(nop3, "CDCC0C40", true);
	   
       }
       break;
 }; 
         case 3020:
    {  
    if(boolean){
       patchBssOffset(det, "CDCC8C3F", true);//1
       patchBssOffset(det2, "9A99993F", true);//2
       patchBssOffset(det3, "00002040", true);
      
	   }
       break;
 }; 
         case 3021:
    {  
    if(boolean){
       patchBssOffset(tor, "CDCC4C3F", true);//1
       patchBssOffset(tor2, "0000803F", true);//2
       patchBssOffset(tor3, "CDCC0C40", true);
       
       }
       break;
 }; 
         case 3022:
    {  
    if(boolean){
       patchBssOffset(hou, "CDCC8C3F", true);//1
       patchBssOffset(hou2, "6666A63F", true);//2
       patchBssOffset(hou3, "00002040", true);
       
       }
       break;
 }; 
         case 3023:
    {  
    if(boolean){
       patchBssOffset(sa, "CDCC4C3F", true);//1
       patchBssOffset(sa2, "9A99993F", true);//2
       patchBssOffset(sa3, "00002040", true);
       
       }
       break;
 }; 
         case 3024:
    {  
    if(boolean){
       patchBssOffset(suns, "CDCC8C3F", true);//1
       patchBssOffset(suns2, "6666A63F", true);//2
       patchBssOffset(suns3, "33331340", true);
       
       }
       break;
 }; 
         case 3025:
    {  
    if(boolean){
       patchBssOffset(okc, "0000803F", true);//1
       patchBssOffset(okc2, "CDCC8C3F", true);//2
       patchBssOffset(okc3, "00000040", true);
       
       }
       break;
 }; 
         case 3026:
    {  
    if(boolean){
       patchBssOffset(wolves, "0000803F", true);//1
       patchBssOffset(wolves2, "6666A63F", true);//2
       patchBssOffset(wolves3, "00004040", true);
       
       }
       break;
 }; 
         case 3027:
    {  
    if(boolean){
       patchBssOffset(blazers, "CDCC8C3F", true);//1
       patchBssOffset(blazers2, "9A99993F", true);//2
       patchBssOffset(blazers3, "9A99D93F", true);
       
       }
       break;
 }; 
         case 3028:
    {  
    if(boolean){
       patchBssOffset(gs, "6666A63F", true);//1
       patchBssOffset(gs2, "3333B33F", true);//2
       patchBssOffset(gs3, "00004040", true);
       
       }
       break;
 }; 
         case 3029:
    {  
    if(boolean){
       patchBssOffset(was, "9A99993F", true);//1
       patchBssOffset(was2, "9A99993F", true);//2
       patchBssOffset(was3, "CDCC0C40", true);
      
       }
       break;
 };  
      case 306: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(skintone, reverseHex, true);
          }  
    break;
  }  
  case 309: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(position, reverseHex, true);
          }  
    break;
  } 
  case 926:{
				 
				 switch (value) {
					 
					 case 0:
						 patchBssOffset(speciality, DwordReverseHex(20), true);
						 break;
						 
						 case 1:
						 patchBssOffset(speciality, DwordReverseHex(50), true);
						 break;
						 
						 case 2:
						 patchBssOffset(speciality, DwordReverseHex(80), true);
						 break;
						 
						 case 3:
						 patchBssOffset(speciality, DwordReverseHex(115), true);
						 break;
						 
						 case 4:
						 patchBssOffset(speciality, DwordReverseHex(145), true);
						 break;
						 
						 case 5:
						 patchBssOffset(speciality, DwordReverseHex(180), true);
						 break;
						 
						 case 6:
						 patchBssOffset(speciality, DwordReverseHex(210), true);
						 break;
						 
						 case 7:
						 patchBssOffset(speciality, DwordReverseHex(240), true);
						 break;
						 
						 case 8:
						 patchBssOffset(speciality, DwordReverseHex(280), true);
						 break;
						 
						 case 9:
						 patchBssOffset(speciality, DwordReverseHex(305), true);
						 break;
						 
						 case 10:
						 patchBssOffset(speciality, DwordReverseHex(340), true);
						 break;
						 
						 case 11:
						 patchBssOffset(speciality, DwordReverseHex(370), true);
						 break;
						 
						 case 12:
						 patchBssOffset(speciality, DwordReverseHex(400), true);
						 break;
						 
						 case 13:
						 patchBssOffset(speciality, DwordReverseHex(440), true);
						 break;
						 
						 case 14:
						 patchBssOffset(speciality, DwordReverseHex(470), true);
						 break;
						 
						 case 15:
						 patchBssOffset(speciality, DwordReverseHex(500), true);
						 break;
						 
						 case 16:
						 patchBssOffset(speciality, DwordReverseHex(530), true);
						 break;
						 
						 case 17:
						 patchBssOffset(speciality, DwordReverseHex(560), true);
						 break;
						 
						 case 18:
						 patchBssOffset(speciality, DwordReverseHex(600), true);
						 break;
						 
						 case 19:
						 patchBssOffset(speciality, DwordReverseHex(630), true);
						 break;
						 
						 case 20:
						 patchBssOffset(speciality, DwordReverseHex(660), true);
						 break;
						 
						 case 21:
						 patchBssOffset(speciality, DwordReverseHex(690), true);
						 break;
						 
						 case 22:
						 patchBssOffset(speciality, DwordReverseHex(40), true);
						 break;
						 
						 case 23:
						 patchBssOffset(speciality, DwordReverseHex(65), true);
						 break;
						 
						 case 24:
						 patchBssOffset(speciality, DwordReverseHex(100), true);
						 break;
						 
						 case 25:
						 patchBssOffset(speciality, DwordReverseHex(130), true);
						 break;
						 
						 case 26:
						 patchBssOffset(speciality, DwordReverseHex(160), true);
						 break;
						 
						 case 27:
						 patchBssOffset(speciality, DwordReverseHex(195), true);
						 break;
						 
						 case 28:
						 patchBssOffset(speciality, DwordReverseHex(225), true);
						 break;
						 
						 case 29:
						 patchBssOffset(speciality, DwordReverseHex(260), true);
						 break;
						 
						 case 30:
						 patchBssOffset(speciality, DwordReverseHex(290), true);
						 break;
						 
						 case 31:
						 patchBssOffset(speciality, DwordReverseHex(320), true);
						 break;
						 
						 case 32:
						 patchBssOffset(speciality, DwordReverseHex(360), true);
						 break;
						 
						 case 33:
						 patchBssOffset(speciality, DwordReverseHex(390), true);
						 break;
						 
						 case 34:
						 patchBssOffset(speciality, DwordReverseHex(420), true);
						 break;
						 
						 case 35:
						 patchBssOffset(speciality, DwordReverseHex(450), true);
						 break;
						 
						 case 36:
						 patchBssOffset(speciality, DwordReverseHex(480), true);
						 break;
						 
						 case 37:
						 patchBssOffset(speciality, DwordReverseHex(520), true);
						 break;
						 
						 case 38:
						 patchBssOffset(speciality, DwordReverseHex(550), true);
						 break;
						 
						 case 39:
						 patchBssOffset(speciality, DwordReverseHex(580), true);
						 break;
						 
						 case 40:
						 patchBssOffset(speciality, DwordReverseHex(620), true);
						 break;
						 
						 case 41:
						 patchBssOffset(speciality, DwordReverseHex(640), true);
						 break;
						 
						 case 42:
						 patchBssOffset(speciality, DwordReverseHex(680), true);
						 break;
						 
						 case 43:
						 patchBssOffset(speciality, DwordReverseHex(710), true);
						 break;
						 
						 case 44:
						 patchBssOffset(speciality, DwordReverseHex(20), true);
						 break;
						 }
						 break;
						 }
		
  case 1009:
    {  
    if(boolean){
       patchBssOffset(opt1, DwordReverseHex(5), true);
       patchBssOffset(opt2, DwordReverseHex(2), true);//2
       patchBssOffset(historic, DwordReverseHex(244), true);
       }else{
       patchBssOffset(opt1, DwordReverseHex(2), true);//1
       patchBssOffset(opt2, DwordReverseHex(2), true);//2
       patchBssOffset(historic, DwordReverseHex(30), true);//3
       }
       break;
 }; 
        case 1008:
    {  
    if(boolean){
       patchBssOffset(option1, "05000000", true);//1
       patchBssOffset(option2, "03000000", true);//2
       patchBssOffset(hidden, "F4000000", true);
       }else{
       patchBssOffset(option1, "02000000", true);//1
       patchBssOffset(option2, "02000000", true);//2
       patchBssOffset(hidden, "1E000000", true);//3
       }
       break;
 }; 
 case 310: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(shoot, reverseHex, true);
          }  
    break;
  }   
  case 311: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunk, reverseHex, true);
          }  
    break;
  }   
			
		case 204: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce1, reverseHex, true);
          }  
    break;
  }   
      case 205: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce2, reverseHex, true);
          }  
    break;
  } case 206: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce3, reverseHex, true);
          }  
    break;
  } case 207: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce4, reverseHex, true);
          }  
    break;
  } case 208: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce5, reverseHex, true);
          }  
    break;
  } case 209: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce6, reverseHex, true);
          }  
    break;
  } case 210: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce7, reverseHex, true);
          }  
    break;
  }   
      case 211: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce8, reverseHex, true);
          }  
    break;
  } case 212: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce9, reverseHex, true);
          }  
    break;
  } case 213: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce10, reverseHex, true);
          }  
    break;
  } case 214: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce11, reverseHex, true);
          }  
    break;
  } case 215: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce12, reverseHex, true);
          }  
    break;
  } case 216: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce13, reverseHex, true);
          }  
    break;
  }   
      case 217: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce14, reverseHex, true);
          }  
    break;
  } case 218: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce15, reverseHex, true);
          }  
    break;
  } case 219: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(acce16, reverseHex, true);
          }  
    break;
} 
    case 50: {
    // Get the absolute address of the target
    uintptr_t stats99 = getAbsoluteAddress(targetLibName, string2Offset(patches[0].offset));
       if(boolean){
    // Apply all patches
autoPatch(targetLibName);
   }
    break;
} case 52: {
    if (boolean) {
     autoPatch(targetLibName);
        }
    break;
}   
		case 1007: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(team, reverseHex, true);
          }  
    break;
  }   
		case 203: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(faceid, reverseHex, true);
          }  
    break;
  }   
        case 260: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(faceoption1, reverseHex, true);
          }  
    break;
  }  
       case 305: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(faceoption2, reverseHex, true);
          }  
    break;
  }   
       case 405: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(r, reverseHex, true);
          }  
    break;
  }   
  case 406: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(g, reverseHex, true);
          }  
    break;
  }   
  case 407: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(b, reverseHex, true);
          }  
    break;
  } 
  case 825: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(speciality, reverseHex, true);
          }  
    break;
  } 
          case 312: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages, reverseHex, true);
          }  
    break;
  }   
    case 313: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages2, reverseHex, true);
          }  
    break;
  }   
    case 314: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages3, reverseHex, true);
          }  
    break;
  }   
    case 315: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages4, reverseHex, true);
          }  
    break;
  }   case 316: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages5, reverseHex, true);
          }  
    break;
  }   case 317: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages6, reverseHex, true);
          }  
    break;
  }   case 318: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages7, reverseHex, true);
          }  
    break;
  }   case 319: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages8, reverseHex, true);
          }  
    break;
  }   case 320: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages9, reverseHex, true);
          }  
    break;
  }   case 321: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages10, reverseHex, true);
          }  
    break;
  }   case 322: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages11, reverseHex, true);
          }  
    break;
  }   case 323: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages12, reverseHex, true);
          }  
    break;
  }   case 324: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages13, reverseHex, true);
          }  
    break;
  }   case 325: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages14, reverseHex, true);
          }  
    break;
  }   case 326: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(dunkpackages15, reverseHex, true);
          }  
    break;
  }   

        case 30:
    {  
    if(boolean){
       patchBssOffset(crowd1, "00002041", true);//1
       patchBssOffset(crowd2, "00002041", true);//2
       patchBssOffset(crowd3, "00002041", true);//3
       patchBssOffset(crowd4, "CDCCCC3D", true);//4
       patchBssOffset(crowd5, "CDCCCC3D", true);//5
       patchBssOffset(crowd6, "CDCCCC3D", true);//6
       }else{
       patchBssOffset(crowd1, "6666663F", true);//1
       patchBssOffset(crowd2, "6666663F", true);//2
       patchBssOffset(crowd3, "6666663F", true);//3
       patchBssOffset(crowd4, "0000803F", true);//4
       patchBssOffset(crowd5, "0000803F", true);//5
       patchBssOffset(crowd6, "0000803F", true);//6
       }
       break;
 }; 
 case 31:
    {  
    if(boolean){
       patchBssOffset(crowds1, "0000003F", true);//1
       patchBssOffset(crowds2, "0000003F", true);//2
       patchBssOffset(crowds3, "713D0A3F", true);//3
       patchBssOffset(crowds4, "00004040", true);//4
       patchBssOffset(crowds5, "00004040", true);//5
       patchBssOffset(crowds6, "00004040", true);//6
       }else{
       patchBssOffset(crowds1, "6666663F", true);//1
       patchBssOffset(crowds2, "6666663F", true);//2
       patchBssOffset(crowds3, "6666663F", true);//3
       patchBssOffset(crowds4, "0000803F", true);//4
       patchBssOffset(crowds5, "0000803F", true);//5
       patchBssOffset(crowds6, "0000803F", true);//6
       }
       break;
 }; 
		case 25:
        if (boolean = true) {
            PATCH("0x2016FEC", "28 6B 6E 4E");
        } else {
            patchOffset(targetLibName, string2Offset(OBFUSCATE("0x2016FEC")), "28 6B 6E 4E", false);
        }
        break;
    case 600:
    {  
    if(boolean){
       patchBssOffset(retro1, "63006C00", true);//1
       patchBssOffset(retro2, "6F007400", true);//2
       patchBssOffset(retro3, "68005F00", true);//3
       patchBssOffset(retro4, "72006500", true);//4
       patchBssOffset(retro5, "74007200", true);//5
       patchBssOffset(retro6, "6F005F00", true);//6
       patchBssOffset(retro7, "73006800", true);//7
       patchBssOffset(retro8, "6F007200", true);//8
       patchBssOffset(retro9, "74007300", true);//9
       patchBssOffset(retro10, "2E006900", true);
       patchBssOffset(retro11, "66006600", true);
       patchBssOffset(retro12, "00000000", true);
       patchBssOffset(retro13, "00000000", true);
       patchBssOffset(retro14, "00000000", true);
       patchBssOffset(retro15, "00000000", true); 
       patchBssOffset(retro16, "00000000", true);
       patchBssOffset(retro17, "00000000", true);
       patchBssOffset(retro18, "00000000", true);
       patchBssOffset(retro19, "00000000", true);
       patchBssOffset(retro20, "00000000", true);
       }else{
       patchBssOffset(retro1, "63006C00", true);//1
       patchBssOffset(retro2, "6F007400", true);//2
       patchBssOffset(retro3, "68005F00", true);//3
       patchBssOffset(retro4, "73006800", true);//4
       patchBssOffset(retro5, "6F007200", true);//5
       patchBssOffset(retro6, "74007300", true);//6
       patchBssOffset(retro7, "2E006900", true);//7
       patchBssOffset(retro8, "66006600", true);//8
       patchBssOffset(retro9, "00006300", true);//9
       patchBssOffset(retro10, "6C006F00", true);
       patchBssOffset(retro11, "74006800", true);
       patchBssOffset(retro12, "5F007200", true);
       patchBssOffset(retro13, "65007400", true);
       patchBssOffset(retro14, "72006F00", true);
       patchBssOffset(retro15, "5F007300", true); 
       patchBssOffset(retro16, "68006F00", true);
       patchBssOffset(retro17, "72007400", true);
       patchBssOffset(retro18, "73002E00", true);
       patchBssOffset(retro19, "69006600", true);
       patchBssOffset(retro20, "66000000", true);
       }
       break;
 }; 
    case 822: { 

       if (value == 0){//right
        patchBssOffset(headband, "40000000", true);  
        patchBssOffset(headband2, "0A000000", true);
        patchBssOffset(headband3, "88FFFFFF", true);
             }else if(value == 1){//back
             patchBssOffset(acce1, DwordReverseHex(65), true);
             patchBssOffset(acce2, DwordReverseHex(64), true);      
             patchBssOffset(acce3, DwordReverseHex(17), true);
             patchBssOffset(acce4, DwordReverseHex(0), true);      
             patchBssOffset(acce5, DwordReverseHex(0), true);
             patchBssOffset(acce6, DwordReverseHex(16), true);      
             patchBssOffset(acce7, DwordReverseHex(5), true);
             patchBssOffset(acce8, DwordReverseHex(-110), true);      
             patchBssOffset(acce9, DwordReverseHex(-25), true);
             patchBssOffset(acce10, DwordReverseHex(73), true);      
             patchBssOffset(acce11, DwordReverseHex(73), true);
             patchBssOffset(acce12, DwordReverseHex(34), true);      
             patchBssOffset(acce17, DwordReverseHex(-11), true);
             patchBssOffset(acce14, DwordReverseHex(73), true);      
             patchBssOffset(acce15, DwordReverseHex(0), true);
             patchBssOffset(acce16, DwordReverseHex(2), true);                          
             }else if(value == 2){//left
        patchBssOffset(acce1, DwordReverseHex(-128), true);
             patchBssOffset(acce2, DwordReverseHex(66), true);      
             patchBssOffset(acce3, DwordReverseHex(0), true);
             patchBssOffset(acce4, DwordReverseHex(66), true);      
             patchBssOffset(acce5, DwordReverseHex(15), true);
             patchBssOffset(acce6, DwordReverseHex(0), true);      
             patchBssOffset(acce7, DwordReverseHex(0), true);
             patchBssOffset(acce8, DwordReverseHex(-110), true);      
             patchBssOffset(acce9, DwordReverseHex(-76), true);
             patchBssOffset(acce10, DwordReverseHex(67), true);      
             patchBssOffset(acce11, DwordReverseHex(66), true);
             patchBssOffset(acce12, DwordReverseHex(-91), true);      
             patchBssOffset(acce17, DwordReverseHex(75), true);
             patchBssOffset(acce14, DwordReverseHex(0), true);      
             patchBssOffset(acce15, DwordReverseHex(15), true);
             patchBssOffset(acce16, DwordReverseHex(-11), true);      

             }else if(value == 3){//front
        patchBssOffset(acce1, DwordReverseHex(-94), true);
             patchBssOffset(acce2, DwordReverseHex(-128), true);      
             patchBssOffset(acce3, DwordReverseHex(30), true);
             patchBssOffset(acce4, DwordReverseHex(25), true);      
             patchBssOffset(acce5, DwordReverseHex(0), true);
             patchBssOffset(acce6, DwordReverseHex(0), true);      
             patchBssOffset(acce7, DwordReverseHex(18), true);
             patchBssOffset(acce8, DwordReverseHex(-92), true);      
             patchBssOffset(acce9, DwordReverseHex(-108), true);
             patchBssOffset(acce10, DwordReverseHex(73), true);      
             patchBssOffset(acce11, DwordReverseHex(73), true);
             patchBssOffset(acce12, DwordReverseHex(34), true);      
             patchBssOffset(acce17, DwordReverseHex(1), true);
             patchBssOffset(acce14, DwordReverseHex(73), true);      
             patchBssOffset(acce15, DwordReverseHex(0), true);
             patchBssOffset(acce16, DwordReverseHex(0), true);      

             }else if(value == 3){//front
        patchBssOffset(acce1, DwordReverseHex(9), true);
             patchBssOffset(acce2, DwordReverseHex(0), true);      
             patchBssOffset(acce3, DwordReverseHex(0), true);
             patchBssOffset(acce4, DwordReverseHex(0), true);      
             patchBssOffset(acce5, DwordReverseHex(0), true);
             patchBssOffset(acce6, DwordReverseHex(0), true);      
             patchBssOffset(acce7, DwordReverseHex(0), true);
             patchBssOffset(acce8, DwordReverseHex(0), true);      
             patchBssOffset(acce9, DwordReverseHex(0), true);
             patchBssOffset(acce10, DwordReverseHex(0), true);      
             patchBssOffset(acce11, DwordReverseHex(0), true);
             patchBssOffset(acce12, DwordReverseHex(0), true);      
             patchBssOffset(acce17, DwordReverseHex(0), true);
             patchBssOffset(acce14, DwordReverseHex(0), true);      
             patchBssOffset(acce15, DwordReverseHex(0), true);
             patchBssOffset(acce16, DwordReverseHex(0), true);      

             }
  break;
} /* case 108:
        if (boolean) {
executeBinary();
               }
        break;
        */
    case 101:
        if (boolean = true) {
            PATCH("0x2016FEC", "28 6B 6E 4E");
        } else {
            patchOffset(targetLibName, string2Offset(OBFUSCATE("0x2016FEC")), "28 6B 6E 4E", false);
        }
        break;
		
		case 2010: {
       
            switch (value){
           case 0:
           originalFaceID = ReadMemoryAsHex(height, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID = ReadMemoryAsHex(height, 4);
           break;          
           case 2:
              patchBssOffset(height, originalFaceID, true);
           break;
              }
    break;
  }  

		case 2011: {
       
            switch (value){
           case 0:
           originalFaceID = ReadMemoryAsHex(weight, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID = ReadMemoryAsHex(weight, 4);
           break;          
           case 2:
              patchBssOffset(weight, originalFaceID, true);
           break;
              }
    break;
  }  
  
  case 2008: {
       
            switch (value){
           case 0:
           originalFaceID1 = ReadMemoryAsHex(firstname, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID1 = ReadMemoryAsHex(firstname, 4);
           break;          
           case 2:
              patchBssOffset(firstname, originalFaceID1, true);
           break;
              }
    break;
  }  
  
  case 2009: {
       
            switch (value){
           case 0:
           originalFaceID1 = ReadMemoryAsHex(lastname, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID1 = ReadMemoryAsHex(lastname, 4);
           break;          
           case 2:
              patchBssOffset(lastname, originalFaceID1, true);
           break;
              }
    break;
  }  
  case 2024: {
       
            switch (value){
           case 0:
           originalFaceID1 = ReadMemoryAsHex(faceid, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID1 = ReadMemoryAsHex(faceid, 4);
           break;          
           case 2:
              patchBssOffset(faceid, originalFaceID1, true);
           break;
              }
    break;
  }  
  case 2025: {
       
            switch (value){
           case 0:
           originalFaceID1 = ReadMemoryAsHex(faceoption1, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID1 = ReadMemoryAsHex(faceoption1, 4);
           break;          
           case 2:
              patchBssOffset(faceoption1, originalFaceID1, true);
           break;
              }
    break;
  }  
          case 929: {
       
            switch (value){
           case 0:
           ace = ReadMemoryAsHex(acce1, 4);
           ace2 = ReadMemoryAsHex(acce2, 4);
           ace3 = ReadMemoryAsHex(acce3, 4);
           ace4 = ReadMemoryAsHex(acce4, 4);
           ace5 = ReadMemoryAsHex(acce5, 4);
           ace6 = ReadMemoryAsHex(acce6, 4);
           ace7 = ReadMemoryAsHex(acce7, 4);
           ace8 = ReadMemoryAsHex(acce8, 4);
           ace9 = ReadMemoryAsHex(acce9, 4);
           ace10 = ReadMemoryAsHex(acce10, 4);
           ace11 = ReadMemoryAsHex(acce11, 4);
           ace12 = ReadMemoryAsHex(acce12, 4);
           ace13 = ReadMemoryAsHex(acce13, 4);
           ace14 = ReadMemoryAsHex(acce14, 4);
           ace15 = ReadMemoryAsHex(acce15, 4);
           ace16 = ReadMemoryAsHex(acce16, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           ace = ReadMemoryAsHex(acce1, 4);
           ace2 = ReadMemoryAsHex(acce2, 4);
           ace3 = ReadMemoryAsHex(acce3, 4);
           ace4 = ReadMemoryAsHex(acce4, 4);
           ace5 = ReadMemoryAsHex(acce5, 4);
           ace6 = ReadMemoryAsHex(acce6, 4);
           ace7 = ReadMemoryAsHex(acce7, 4);
           ace8 = ReadMemoryAsHex(acce8, 4);
           ace9 = ReadMemoryAsHex(acce9, 4);
           ace10 = ReadMemoryAsHex(acce10, 4);
           ace11 = ReadMemoryAsHex(acce11, 4);
           ace12 = ReadMemoryAsHex(acce12, 4);
           ace13 = ReadMemoryAsHex(acce13, 4);
           ace14 = ReadMemoryAsHex(acce14, 4);
           ace15 = ReadMemoryAsHex(acce15, 4);
           ace16 = ReadMemoryAsHex(acce16, 4);
           break;          
           case 2:
             patchBssOffset(acce1, ace, true);
             patchBssOffset(acce2, ace2, true);      
             patchBssOffset(acce3, ace3, true);
             patchBssOffset(acce4, ace4, true);      
             patchBssOffset(acce5, ace5, true);
             patchBssOffset(acce6, ace6, true);      
             patchBssOffset(acce7, ace7, true);
             patchBssOffset(acce8, ace8, true);      
             patchBssOffset(acce9, ace9, true);
             patchBssOffset(acce10, ace10, true);      
             patchBssOffset(acce11, ace11, true);
             patchBssOffset(acce12, ace12, true);      
             patchBssOffset(acce17, ace13, true);
             patchBssOffset(acce14, ace14, true);      
             patchBssOffset(acce15, ace15, true);
             patchBssOffset(acce16, ace16, true);      
           break;
              }
    break;
  }  
    
   case 2000: {
       
            switch (value){
           case 0:
           originalFaceID = ReadMemoryAsHex(faceid, 4);
           originalFaceID1 = ReadMemoryAsHex(faceoption1, 4);
           originalFaceID2 = ReadMemoryAsHex(faceoption2, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           originalFaceID = ReadMemoryAsHex(faceid, 4);
           originalFaceID1 = ReadMemoryAsHex(faceoption1, 4);
           originalFaceID2 = ReadMemoryAsHex(faceoption2, 4);
           break;          
           case 2:
              patchBssOffset(faceid, originalFaceID, true);
              patchBssOffset(faceoption1, originalFaceID1, true);
              patchBssOffset(faceoption2, originalFaceID2, true);
           break;
              }
    break;
  }   case 2001: {
       speed = boolean;
    break;    
  }   
   

    case 201: {
    uintptr_t teamid = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DCA0")); // Example offset
    uintptr_t option1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC98")); // Example offset
    uintptr_t option2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC9C")); // Example offset
    
    
       if (value == 0){
        std::string reverseHex = DwordReverseHex(0); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 1){
       std::string reverseHex = DwordReverseHex(1); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 2){
       std::string reverseHex = DwordReverseHex(2); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 3){
       std::string reverseHex = DwordReverseHex(3); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 4){
      std::string reverseHex = DwordReverseHex(4); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 5){
       std::string reverseHex = DwordReverseHex(5); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 6){
       std::string reverseHex = DwordReverseHex(6); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 7){
       std::string reverseHex = DwordReverseHex(7); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 8){
       std::string reverseHex = DwordReverseHex(8); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 9){
      std::string reverseHex = DwordReverseHex(9); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 10){
       std::string reverseHex = DwordReverseHex(10); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 11){
       std::string reverseHex = DwordReverseHex(11); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 12){
       std::string reverseHex = DwordReverseHex(12); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 13){
       std::string reverseHex = DwordReverseHex(13); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 14){
       std::string reverseHex = DwordReverseHex(14); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 15){
       std::string reverseHex = DwordReverseHex(15); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 16){
       std::string reverseHex = DwordReverseHex(16); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 17){
       std::string reverseHex = DwordReverseHex(17); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 18){
       std::string reverseHex = DwordReverseHex(18); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 19){
       std::string reverseHex = DwordReverseHex(19); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 20){
       std::string reverseHex = DwordReverseHex(20); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 21){
       std::string reverseHex = DwordReverseHex(21); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 22){
       std::string reverseHex = DwordReverseHex(22); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 23){
       std::string reverseHex = DwordReverseHex(23); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 24){
       std::string reverseHex = DwordReverseHex(24); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 25){
       std::string reverseHex = DwordReverseHex(25); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 26){
       std::string reverseHex = DwordReverseHex(26); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 27){
       std::string reverseHex = DwordReverseHex(27); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 28){
       std::string reverseHex = DwordReverseHex(28); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 29){
       std::string reverseHex = DwordReverseHex(29); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }else if(value == 30){
       std::string reverseHex = DwordReverseHex(30); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "02000000", true);
        patchBssOffset(option2, "02000000", true);  
   }
   break;
 }  case 202: {
    uintptr_t teamid = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DCA0")); // Example offset
    uintptr_t option1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC98")); // Example offset
    uintptr_t option2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC9C")); // Example offset
       if (value == 1){
        std::string reverseHex = DwordReverseHex(0); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 2){
       std::string reverseHex = DwordReverseHex(1); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 3){
       std::string reverseHex = DwordReverseHex(2); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 4){
       std::string reverseHex = DwordReverseHex(3); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 5){
      std::string reverseHex = DwordReverseHex(4); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 6){
       std::string reverseHex = DwordReverseHex(5); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 7){
       std::string reverseHex = DwordReverseHex(6); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 8){
       std::string reverseHex = DwordReverseHex(7); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 9){
       std::string reverseHex = DwordReverseHex(8); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 10){
      std::string reverseHex = DwordReverseHex(9); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 11){
       std::string reverseHex = DwordReverseHex(10); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 12){
       std::string reverseHex = DwordReverseHex(11); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 13){
       std::string reverseHex = DwordReverseHex(12); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 14){
       std::string reverseHex = DwordReverseHex(13); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 15){
       std::string reverseHex = DwordReverseHex(14); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 16){
       std::string reverseHex = DwordReverseHex(15); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 17){
       std::string reverseHex = DwordReverseHex(16); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 18){
       std::string reverseHex = DwordReverseHex(17); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 19){
       std::string reverseHex = DwordReverseHex(18); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 20){
       std::string reverseHex = DwordReverseHex(19); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 21){
       std::string reverseHex = DwordReverseHex(20); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 22){
       std::string reverseHex = DwordReverseHex(21); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 23){
       std::string reverseHex = DwordReverseHex(22); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);   
   }else if(value == 24){
       std::string reverseHex = DwordReverseHex(23); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 25){
       std::string reverseHex = DwordReverseHex(24); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 26){
       std::string reverseHex = DwordReverseHex(25); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 27){
       std::string reverseHex = DwordReverseHex(26); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);   
   }else if(value == 28){
       std::string reverseHex = DwordReverseHex(27); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 29){
       std::string reverseHex = DwordReverseHex(28); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 30){
       std::string reverseHex = DwordReverseHex(29); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }else if(value == 31){
       std::string reverseHex = DwordReverseHex(30); // e.g., "0000FAC3"
        patchBssOffset(teamid, reverseHex, true);
        patchBssOffset(option1, "04000000", true);
        patchBssOffset(option2, "03000000", true);  
   }
   break;
 }
 
     case 903: {
       if (value>0 && value <= 20000){
         std::string reverseHex = DwordReverseHex(value); 
        patchBssOffset(faceid, reverseHex, true);
        patchBssOffset(faceoption1, reverseHex, true);
        patchBssOffset(faceoption2, "00000000", true);
          }  else{
              patchBssOffset(faceid, originalFaceID, true);
          }
    break;
  }   
  
      case 904: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce1, reverseHex, true);
          }  
    break;
  }   
  
  case 905: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce2, reverseHex, true);
          }  
    break;
  }
  
  case 906: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce3, reverseHex, true);
          }  
    break;
  }
  
  case 907: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce5, reverseHex, true);
          }  
    break;
  }
  
  case 908: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce6, reverseHex, true);
          }  
    break;
  }
  
  case 909: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce7, reverseHex, true);
          }  
    break;
  }
  
  case 910: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce8, reverseHex, true);
          }  
    break;
  }
  
  case 911: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce9, reverseHex, true);
          }  
    break;
  }
  
  case 912: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce10, reverseHex, true);
          }  
    break;
  }
  
  case 913: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce11, reverseHex, true);
          }  
    break;
  }
  
  case 914: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce12, reverseHex, true);
          }  
    break;
  }
  
  case 915: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce13, reverseHex, true);
          }  
    break;
  }
  
  case 916: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce14, reverseHex, true);
          }  
    break;
  }
  
  case 917: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce15, reverseHex, true);
          }  
    break;
  }
  
  case 918: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce16, reverseHex, true);
          }  
    break;
  }
  
  case 919: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(acce17, reverseHex, true);
          }  
    break;
  } case 200: {
    // Get the absolute address of the target
    uintptr_t stats99 = getAbsoluteAddress(targetLibName, string2Offset(patches[0].offset));
       if(boolean){
    // Apply all patches
autoPatch(targetLibName);
   }
    break;
} case 920: {
    if (boolean) {
     autoPatch(targetLibName);
        }
    break;
}
     case 2012: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(year, reverseHex, true);
          }  
    break;
  }   
  
  case 2013: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(cont, reverseHex, true);
          }  
    break;
  }   

case 2014: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(cont2, reverseHex, true);
          }  
    break;
  }   

case 2015: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(cont3, reverseHex, true);
          }  
    break;
  }   
  
  case 2016: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(cont4, reverseHex, true);
          }  
    break;
  }   
  
  case 2017: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(cont5, reverseHex, true);
          }  
    break;
  }   
  
  case 2018: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(cont6, reverseHex, true);
          }  
    break;
  }   
 case 81: {
       if (value){
         std::string reverseHex = DwordReverseHex(value);
        patchBssOffset(vc1, reverseHex, true);
		patchBssOffset(vc2, reverseHex, true);
		patchBssOffset(vc3, reverseHex, true);
		patchBssOffset(vc4, reverseHex, true);
          }  
    break;
  }   





   case 921: {
       if(boolean){
        patchBssOffset(replay1, "0000BE06", true);
        patchBssOffset(replay2, "BE06", true);

   }
    break;
}           case 923: {
       
            switch (value){
           case 0:
           ace = ReadMemoryAsHex(dunkpackages, 4);
           ace2 = ReadMemoryAsHex(dunkpackages2, 4);
           ace3 = ReadMemoryAsHex(dunkpackages3, 4);
           ace4 = ReadMemoryAsHex(dunkpackages4, 4);
           ace5 = ReadMemoryAsHex(dunkpackages5, 4);
           ace6 = ReadMemoryAsHex(dunkpackages6, 4);
           ace7 = ReadMemoryAsHex(dunkpackages7, 4);
           ace8 = ReadMemoryAsHex(dunkpackages8, 4);
           ace9 = ReadMemoryAsHex(dunkpackages9, 4);
           ace10 = ReadMemoryAsHex(dunkpackages10, 4);
           ace11 = ReadMemoryAsHex(dunkpackages11, 4);
           ace12 = ReadMemoryAsHex(dunkpackages12, 4);
           ace13 = ReadMemoryAsHex(dunkpackages13, 4);
           ace14 = ReadMemoryAsHex(dunkpackages14, 4);
           ace15 = ReadMemoryAsHex(dunkpackages15, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           ace = ReadMemoryAsHex(dunkpackages, 4);
           ace2 = ReadMemoryAsHex(dunkpackages2, 4);
           ace3 = ReadMemoryAsHex(dunkpackages3, 4);
           ace4 = ReadMemoryAsHex(dunkpackages4, 4);
           ace5 = ReadMemoryAsHex(dunkpackages5, 4);
           ace6 = ReadMemoryAsHex(dunkpackages6, 4);
           ace7 = ReadMemoryAsHex(dunkpackages7, 4);
           ace8 = ReadMemoryAsHex(dunkpackages8, 4);
           ace9 = ReadMemoryAsHex(dunkpackages9, 4);
           ace10 = ReadMemoryAsHex(dunkpackages10, 4);
           ace11 = ReadMemoryAsHex(dunkpackages11, 4);
           ace12 = ReadMemoryAsHex(dunkpackages12, 4);
           ace13 = ReadMemoryAsHex(dunkpackages13, 4);
           ace14 = ReadMemoryAsHex(dunkpackages14, 4);
           ace15 = ReadMemoryAsHex(dunkpackages15, 4);
           break;          
           case 2:
             patchBssOffset(dunkpackages, ace, true);
             patchBssOffset(dunkpackages2, ace2, true);      
             patchBssOffset(dunkpackages3, ace3, true);
             patchBssOffset(dunkpackages4, ace4, true);      
             patchBssOffset(dunkpackages5, ace5, true);
             patchBssOffset(dunkpackages6, ace6, true);      
             patchBssOffset(dunkpackages7, ace7, true);
             patchBssOffset(dunkpackages8, ace8, true);      
             patchBssOffset(dunkpackages9, ace9, true);
             patchBssOffset(dunkpackages10, ace10, true);      
             patchBssOffset(dunkpackages11, ace11, true);
             patchBssOffset(dunkpackages12, ace12, true);      
             patchBssOffset(dunkpackages13, ace13, true);
             patchBssOffset(dunkpackages14, ace14, true);      
             patchBssOffset(dunkpackages15, ace15, true);    
           break;
              }
    break;
  }     
       case 6024: {
       switch (value){
          case 0:
         originalFaceID = ReadMemoryAsHex(playerattire2, 4);
         originalFaceID1 = ReadMemoryAsHex(clothes2, 4);
         originalFaceID2 = ReadMemoryAsHex(playerID2, 4);
         stats23 = ReadMemoryAsHex(rts, 4);
		 stats24 = ReadMemoryAsHex(rts2, 4);
            break;
          case 1:
         originalFaceID = ReadMemoryAsHex(playerattire2, 4);
         originalFaceID1 = ReadMemoryAsHex(clothes2, 4);
         originalFaceID2 = ReadMemoryAsHex(playerID2, 4);
         stats23 = ReadMemoryAsHex(rts, 4);
		 stats24 = ReadMemoryAsHex(rts2, 4);
           break;
         // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 2:
              patchBssOffset(playerattire, originalFaceID, true);
              patchBssOffset(clothes, originalFaceID1, true);
              patchBssOffset(playerID, originalFaceID2, true);          
              patchBssOffset(rts, stats23, true);     
		      patchBssOffset(rts2, stats24, true);
              break;
       } 
     break;
} 
        case 6025: {
       switch (value){
          case 0:
         originalFaceID = ReadMemoryAsHex(playerattire, 4);
         originalFaceID1 = ReadMemoryAsHex(clothes, 4);
         originalFaceID2 = ReadMemoryAsHex(playerID, 4);
		 stats23 = ReadMemoryAsHex(rts, 4);
		 stats24 = ReadMemoryAsHex(rts2, 4);
          break;
          case 1:
         originalFaceID = ReadMemoryAsHex(playerattire, 1);
         originalFaceID1 = ReadMemoryAsHex(clothes, 4);
         originalFaceID2 = ReadMemoryAsHex(playerID, 4);
		 stats23 = ReadMemoryAsHex(rts, 4);
		 stats24 = ReadMemoryAsHex(rts2, 4);
          break;
         // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 2:
              patchBssOffset(playerattire, originalFaceID, true);
              patchBssOffset(clothes, originalFaceID1, true);
              patchBssOffset(playerID, originalFaceID2, true); 
			  patchBssOffset(rts, stats23, true);     
		      patchBssOffset(rts2, stats24, true);
          break;
       } 
     break;
}   
      case 2071: {
       
            switch (value){
           case 0:
           ace = ReadMemoryAsHex(faceid, 4);
           ace2 = ReadMemoryAsHex(faceoption1, 4);
           ace3 = ReadMemoryAsHex(faceoption2, 4);
           ace4 = ReadMemoryAsHex(skintone, 4);
           ace5 = ReadMemoryAsHex(shoot, 4);
           ace6 = ReadMemoryAsHex(dunk, 4);
           ace7 = ReadMemoryAsHex(year, 4);
           ace8 = ReadMemoryAsHex(cont, 4);
           ace9 = ReadMemoryAsHex(cont2, 4);
           ace10 = ReadMemoryAsHex(cont3, 4);
           ace11 = ReadMemoryAsHex(cont4, 4);
           ace12 = ReadMemoryAsHex(cont5, 4);
           ace13 = ReadMemoryAsHex(cont6, 4);
           ace14 = ReadMemoryAsHex(height, 4);
           ace15 = ReadMemoryAsHex(weight, 4);
           break;
                  // Read 4 bytes as hex
    //    patchBssOffset(faceoption1, originalFaceID, true);
          case 1:
           ace = ReadMemoryAsHex(faceid, 4);
           ace2 = ReadMemoryAsHex(faceoption1, 4);
           ace3 = ReadMemoryAsHex(faceoption2, 4);
           ace4 = ReadMemoryAsHex(skintone, 4);
           ace5 = ReadMemoryAsHex(shoot, 4);
           ace6 = ReadMemoryAsHex(dunk, 4);
           ace7 = ReadMemoryAsHex(year, 4);
           ace8 = ReadMemoryAsHex(cont, 4);
           ace9 = ReadMemoryAsHex(cont2, 4);
           ace10 = ReadMemoryAsHex(cont3, 4);
           ace11 = ReadMemoryAsHex(cont4, 4);
           ace12 = ReadMemoryAsHex(cont5, 4);
           ace13 = ReadMemoryAsHex(cont6, 4);
           ace14 = ReadMemoryAsHex(height, 4);
           ace15 = ReadMemoryAsHex(weight, 4);
           break;          
           case 2:
             patchBssOffset(faceid, ace, true);
             patchBssOffset(faceoption1, ace2, true);      
             patchBssOffset(faceoption2, ace3, true);
             patchBssOffset(skintone, ace4, true);      
             patchBssOffset(shoot, ace5, true);
             patchBssOffset(dunk, ace6, true);      
             patchBssOffset(year, ace7, true);
             patchBssOffset(cont, ace8, true);      
             patchBssOffset(cont2, ace9, true);
             patchBssOffset(cont3, ace10, true);      
             patchBssOffset(cont4, ace11, true);
             patchBssOffset(cont5, ace12, true);      
             patchBssOffset(cont6, ace13, true);
             patchBssOffset(height, ace14, true);      
             patchBssOffset(weight, ace15, true);    
           break;
              }
    break;
  }     
      case 2050: {
         uintptr_t span = getAbsoluteAddress(targetLibName, string2Offset("0x20DB184")); // Example offset       
      float mh = 1.0f;
      float mxh = 10.0f;

       if (value) {
        float scaledValue = mh / mxh + ((value / mxh) * (1.0f - mh / mxh)); 
        std::string reverseHex = floatToReverseHex(scaledValue); // E.g., "0000FAC3"
        patchBssOffset(span, reverseHex, true);
    }
    break;
 }  
        case 925: {
       if (value){
         std::string reverseHex = ByteReverseHex(value);
        patchBssOffset(speciality, reverseHex, true);
          }  
    break;
  } 
}
       
     }  


__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("Background"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Background)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
			{OBFUSCATE("GetFeatureList2"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList2)},
			{OBFUSCATE("GetFeatureList3"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList3)},
			{OBFUSCATE("GetFeatureList4"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList4)},
			{OBFUSCATE("GetFeatureList5"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList5)},
			{OBFUSCATE("GetFeatureList6"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList6)},
			{OBFUSCATE("GetFeatureList7"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList7)},
			{OBFUSCATE("GetFeatureList8"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList8)},
			{OBFUSCATE("GetFeatureList9"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList9)},
			{OBFUSCATE("GetFeatureList10"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList10)},
			{OBFUSCATE("GetFeatureList11"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList11)},
			{OBFUSCATE("GetFeatureList12"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList12)},
			{OBFUSCATE("GetFeatureList13"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList13)},
			{OBFUSCATE("GetFeatureList14"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList14)},
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}


extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

