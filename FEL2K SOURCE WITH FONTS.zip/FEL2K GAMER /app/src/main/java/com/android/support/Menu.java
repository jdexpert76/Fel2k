//Please don't replace listeners with lambda!

package com.android.support;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;
import android.widget.ProgressBar;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.os.Handler;
import android.os.Looper;
import android.widget.ProgressBar;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.content.SharedPreferences;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.animation.ValueAnimator;
import android.animation.ArgbEvaluator;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.OvershootInterpolator;
import android.annotation.TargetApi;
import android.view.textservice.TextInfo;
import android.system.Os;
import android.icu.util.VersionInfo;

import org.xml.sax.ErrorHandler;
import android.graphics.Canvas;
import android.widget.ActionMenuView.LayoutParams;
import android.view.View.OnClickListener;
import java.util.Objects;
import android.graphics.Rect;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Paint;
import android.animation.ValueAnimator;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.LinearGradient;
import android.animation.ArgbEvaluator;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.view.animation.LinearInterpolator;
import android.widget.SeekBar.OnSeekBarChangeListener;
import java.util.Random;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import java.util.ArrayList;
import android.view.animation.RotateAnimation;
import android.view.animation.Animation;
import android.graphics.PorterDuffColorFilter;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.animation.AnimatorSet;
import android.graphics.drawable.StateListDrawable;
import android.animation.ObjectAnimator;
import java.util.Locale;
import android.animation.PropertyValuesHolder;
import android.view.animation.DecelerateInterpolator;
import android.graphics.drawable.shapes.PathShape;
import android.speech.tts.UtteranceProgressListener;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.graphics.Bitmap;
import android.view.animation.OvershootInterpolator;
import android.graphics.ColorFilter;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.transition.TransitionManager;
import android.transition.AutoTransition;
import android.transition.Transition;
import android.transition.TransitionSet;
import android.transition.Fade;
import android.transition.ChangeBounds;
import android.animation.TimeInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.animation.AnimatorListenerAdapter;
import android.animation.Animator;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.view.animation.AccelerateInterpolator;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.widget.GridLayout;
import android.view.inputmethod.EditorInfo;
import android.view.KeyEvent;
import android.view.Window;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.PathMeasure;
import android.os.Looper;
import android.graphics.SweepGradient;
import android.graphics.Matrix;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RoundRectShape;
import java.io.InputStream;
import android.graphics.drawable.Drawable;
import java.io.IOException;
import android.widget.PopupWindow;
import java.io.InputStream;
import android.graphics.drawable.Drawable;
import java.io.IOException;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;

import com.android.animation.AnimationSetupCallback;
import com.android.animation.Shimmer;
import com.android.animation.ShimmerTextView;
import com.android.animation.ShimmerButton;
import com.android.animation.ShimmerSwitch;
import com.android.animation.Titanic;
import com.android.animation.TitanicTextView;
import com.android.animation.TitanicSwitch;
import com.android.animation.TitanicButton;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.Html;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import android.view.ContextMenu.ContextMenuInfo;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Looper;
import java.io.File;
import android.widget.ProgressBar;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.animation.ValueAnimator;
import android.view.animation.LinearInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.animation.ValueAnimator;
import android.view.Choreographer;
import com.android.support.Handlers;
import android.app.ProgressDialog;
import android.widget.LinearLayout;
public class Menu {
	private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    //********** Here you can easly change the menu appearance **********//

    //region Variable
    public static final String TAG = "Mod_Menu"; //Tag for logcat

    int TEXT_COLOR = Color.WHITE;
    int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
	int TEXT_COLOR_3 = Color.GRAY;
	int BUTTONS_COLOR = Color.argb(170,0,0,0); //#AARRGGBB
    int BTN_COLOR = Color.parseColor("#FF000000");
    int MENU_BG_COLOR = Color.argb(170,0,0,0); //#AARRGGBB
    int MENU_FEATURE_BG_COLOR = Color.parseColor("#cc002040");
    int MENU_HEIGHT = 260;
    int MENU_WIDTH = 700;
    
    int POS_X = 0;
    int POS_Y = 0;

	int ToggleTrackON = Color.BLACK;
	int ToggleThumbOFF = Color.WHITE;
	int ToggleThumbON = Color.BLACK;
	int ToggleTrackOFF = Color.argb(170,255,255,255);

    float MENU_CORNER = 4f;
    int ICON_SIZE = 45; //Change both width and height of image
    float ICON_ALPHA = 0.7f; //Transparent
    int ToggleON = Color.GREEN;
    int ToggleOFF = Color.RED;
    int CategoryBG = Color.TRANSPARENT;
    int SeekBarColor = Color.parseColor("#FFFFFF");
    int SeekBarProgressColor = Color.parseColor("#FFFFFF");
    int CheckBoxColor = Color.parseColor("#FFFFFF");
    int RadioColor = Color.parseColor("#FFFFFF");
	int Toggle_BG_COLOR = Color.parseColor("#cc002040");
    String NumberTxtColor = "#FFFFFF";


	float TAB_TEXT_SIZE = 14f;
	LinearLayout MainsubLayout,subLayout,linearLayoutbt;
	TextView t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
	TextView rt1,rt2,rt3,rt4,rt5,rt6,rt7,rt8,rt9,rt10,rt11,rt12,rt13,rt14,rt15,rt16,rt17,rt18,rt19,rt20,rt21,rt22,rt23,rt24;
	LinearLayout v1,v2,v3;
	GradientDrawable drawable,TabunCheked;
	
    //********************************************************************//

	public void SetFont(TextView myTextView) {
		Typeface newTypeface = Typeface.createFromAsset(getContext.getAssets(), "FontsV2/PixelFont.ttf"); 
		myTextView.setTypeface(newTypeface);
	}
	
    RelativeLayout mCollapsed, mRootContainer;
    LinearLayout mExpanded, mods,mods2,mods3,mods4,mods5,mods6,mods7,mods8,mods9,mods10,mods11,mods12,mods13,mods14, mSettings, mCollapse;
    LinearLayout.LayoutParams scrlLLExpanded, scrlLL;
	LinearLayout LeftLayout;
	
	int screenHeight, screenWidth, type, dpi, lastSelectedPage = 0;
    WindowManager mWindowManager;
    WindowManager.LayoutParams vmParams;
    ImageView startimage;
    FrameLayout rootFrame;
    ScrollView scrollView,scrollView2;
    boolean stopChecking,backupFiles,restoreFiles,downloadAndUnzip, overlayRequired;
    Context getContext;
	
		
	/*private View.OnTouchListener ontouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX, initialTouchY;
            private int initialX, initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        createResizeTriangle();
                        initialX = vmParams.x;
                        initialY = vmParams.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        mExpanded.setAlpha(1f);
                        mCollapsed.setAlpha(1f);
                        if (Math.abs(motionEvent.getRawX() - initialTouchX) < 10 && 
                            Math.abs(motionEvent.getRawY() - initialTouchY) < 10 && 
                            isViewCollapsed()) {
                            toggleViews();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:

                        mExpanded.setAlpha(0.7f);
                        mCollapsed.setAlpha(0.7f);
                        vmParams.x = initialX + (int)(motionEvent.getRawX() - initialTouchX);
                        vmParams.y = initialY + (int)(motionEvent.getRawY() - initialTouchY);
                        mWindowManager.updateViewLayout(rootFrame, vmParams);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void createResizeTriangle() {
        final TextView resizeHandle = new TextView(getContext);
        resizeHandle.setText("⇘");
        // Color inicial (verde normal)
        resizeHandle.setTextColor(Color.parseColor("#4CAF50"));
        // Efecto de sombra para brillo
        resizeHandle.setShadowLayer(15, 0, 0, Color.parseColor("#80FF00")); // Sombra verde neón
        resizeHandle.setTextSize(24);
        resizeHandle.setPadding(8, 8, 8, 8);
        resizeHandle.setBackgroundColor(Color.parseColor("#20000000"));

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM | Gravity.END
        );
        params.setMargins(0, 0, 0, 0);
        resizeHandle.setLayoutParams(params);

        ((ViewGroup) rootFrame).addView(resizeHandle);

        resizeHandle.setOnTouchListener(new View.OnTouchListener() {
                private float startX, startY;
                private int startWidth, startHeight;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = event.getRawX();
                            startY = event.getRawY();
                            startWidth = vmParams.width;
                            startHeight = vmParams.height;

                            // Efecto brillante al tocar
                            resizeHandle.setTextColor(Color.GREEN); // Color intenso
                            resizeHandle.setTextSize(28); // Tamaño aumentado
                            resizeHandle.setShadowLayer(25, 0, 0, Color.GREEN); // Sombra más grande y brillante
                            return true;

                        case MotionEvent.ACTION_MOVE:
                            float deltaX = event.getRawX() - startX;
                            float deltaY = event.getRawY() - startY;

                            if (deltaX < 0) {
                                vmParams.height = Math.max(58, startHeight + (int)(deltaY * 1));
                            } else {
                                vmParams.height = startHeight + (int)deltaY;
                            }

                            vmParams.width = startWidth + (int)deltaX;
                            vmParams.width = Math.max(150, vmParams.width);
                            vmParams.height = Math.max(58, vmParams.height);

                            mWindowManager.updateViewLayout(rootFrame, vmParams);
                            return true;

                        case MotionEvent.ACTION_UP:
                            // Restaurar apariencia original
                            resizeHandle.setTextColor(Color.parseColor("#4CAF50"));
                            resizeHandle.setTextSize(24);
                            resizeHandle.setShadowLayer(15, 0, 0, Color.parseColor("#80FF00"));
                            return true;

                        default:
                            return false;
                    }
                }
            });
    }

    private void toggleViews() {
        try {
            if (mCollapsed.getVisibility() == View.VISIBLE) {
                mCollapsed.setVisibility(View.GONE);
                mExpanded.setVisibility(View.VISIBLE);
            } else {
                mCollapsed.setVisibility(View.VISIBLE);
                mExpanded.setVisibility(View.GONE);
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }*/

	private void AddColor(View view, int color, int strokeWidth, int dashWidth, int dashGap, int strokeColor, int r1, int r2, int r3, int r4, int r5, int r6, int r7, int r8, int r9) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadii(new float[]{r1, r2, r3, r4, r5, r6, r7, r8, r9});
        gd.setStroke(strokeWidth, strokeColor, dashWidth, dashGap);
        view.setBackgroundDrawable(gd);
    }
	
	private void ShowToast(final String featName) {
		Toast toast = new Toast(getContext);
		toast.setDuration(0);

		LinearLayout linearLayout = new LinearLayout(getContext);
		GradientDrawable gradientDrawable = new GradientDrawable();
		gradientDrawable.setStroke(dp(2),TEXT_COLOR_2);
		gradientDrawable.setColor(BTN_COLOR);
		gradientDrawable.setCornerRadii(new float[]{dp(7), dp(7), 0, 0, dp(7), dp(7),0 ,0});
		linearLayout.setBackground(gradientDrawable);

		TextView textView = new TextView(getContext);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setPadding(dp(7), dp(4), dp(7), dp(4));
        textView.setText(Html.fromHtml(featName));
        linearLayout.addView(textView);
        toast.setView(linearLayout);
        toast.show();
	}

	//ShowToast("<b>"+"<u>" +featName+" -> "+"</u>"+"</b>"+featName);

    //initialize methods from the native library
    native void Init(Context context, TextView title, TextView subTitle);
 
	//native String[] CreateResizeTriangle();
	
	native String[] ToggleViews();
	
	native String Icon();
	
	native String Right();
	
	native String Left();
	
    native String Background();

    native String IconWebViewData();

    native String[] GetFeatureList();

	native String[] GetFeatureList2();

	native String[] GetFeatureList3();

	native String[] GetFeatureList4();

	native String[] GetFeatureList5();

	native String[] GetFeatureList6();
	
	native String[] GetFeatureList7();
	
	native String[] GetFeatureList8();
	
	native String[] GetFeatureList9();
	
	native String[] GetFeatureList10();
	
	native String[] GetFeatureList11();
	
	native String[] GetFeatureList12();
	
	native String[] GetFeatureList13();
	
	native String[] GetFeatureList14();
	
//	native String[] GetFeatureList11();
	
	//native String[] GetFeatureList12();

    native String[] SettingsList();

    native boolean IsGameLibLoaded();

    int iconSize = 20;
    private Drawable getScaledDrawable(int drawableResId) {
        try {
            Drawable icon = getContext.getResources().getDrawable(drawableResId);
            int sizePx = dp(iconSize);
            icon.setBounds(0, 0, sizePx, sizePx);
            return icon;
        } catch (Exception e) {
            // Si hay error, retornar null (no se mostrará icono)
            return null;
        }
    }

    private TextToSpeech tts22;

    private void startWelcomeTextToSpeech() {
        tts22 = new TextToSpeech(getContext, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status == TextToSpeech.SUCCESS) {
                        // Establecer idioma (español de España)
                        tts22.setLanguage(Locale.getDefault());

                        // Configurar parámetros de voz
                        tts22.setPitch(1.0f); // Tono normal
                        tts22.setSpeechRate(1.0f); // Velocidad normal

                        // Obtener el nombre de la aplicación y la versión
                        String appName = "";
                        String versionName = "";
                        try {
                            PackageManager packageManager = getContext.getPackageManager();
                            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getContext.getPackageName(), 0);
                            appName = (String) packageManager.getApplicationLabel(applicationInfo);
                            PackageInfo packageInfo = packageManager.getPackageInfo(getContext.getPackageName(), 0);
                            versionName = packageInfo.versionName;
                        } catch (PackageManager.NameNotFoundException e) {
                            Log.e("TTS", "Error al obtener la información de la aplicación", e);
                            appName = "Desconocido";
                            versionName = "Desconocida";
                        }

                        // Construir el mensaje de bienvenida con el nombre de la app y la versión
                        String welcomeMessage = String.format(
                            "THIS MOD MENU IS MODDED BY Fel2K GAMER OFFICIAL" +
                            "This is Developed by Fel2k Please Dont Sell it.",
                            appName, versionName
                        );

                        // Configurar listener para cerrar el TTS cuando termine
                        tts22.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                                @Override
                                public void onStart(String utteranceId) {}

                                @Override
                                public void onDone(String utteranceId) {
                                    tts22.stop();
                                    tts22.shutdown();
                                }

                                @Override
                                public void onError(String utteranceId) {
                                    Log.e("TTS", "Error al reproducir el mensaje");
                                }
                            });

                        // Reproducir el mensaje
                        tts22.speak(welcomeMessage, TextToSpeech.QUEUE_FLUSH, null, "welcomeMessage");
                    } else {
                        Log.e("TTS", "Error al inicializar TextToSpeech");
                    }
                }
            });
    }


    //Here we write the code for our Menu
    // Reference: https://www.androidhive.info/2016/11/android-floating-widget-like-facebook-chat-head/
    public Menu(Context context) {

        getContext = context;
        Preferences.context = context;
        rootFrame = new FrameLayout(context); // Global markup
        rootFrame.setOnTouchListener(onTouchListener());
        mRootContainer = new RelativeLayout(context); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(context); // Markup of the icon (when the menu is minimized)
        mCollapsed.setVisibility(View.VISIBLE);
        mCollapsed.setAlpha(ICON_ALPHA);

        //********** The box of the mod menu **********
        mExpanded = new LinearLayout(context); // Menu markup (when the menu is expanded)
        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(MENU_BG_COLOR);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
      //  mExpanded.setPadding(5,10,20,70); //So borders would be visible
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(MENU_WIDTH), WRAP_CONTENT));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(this.MENU_CORNER);
        gradientDrawable.setColor(Color.parseColor("#93002030"));
        gradientDrawable.setStroke(8, -1);
        gradientDrawable = new GradientDrawable(Orientation.BL_TR, new int[]{Color.parseColor("#cc000000"), Color.parseColor("#cc002040")});
        gradientDrawable.setShape(0);
        gradientDrawable.setStroke(8, -12303292);
        gradientDrawable.setCornerRadius((float) 10);
        this.mExpanded.setBackground(gradientDrawable);
        gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor("#33000000"));
        gradientDrawable.setCornerRadius(40.0f);
        LayoutParams layoutParams2 = new LayoutParams(dp(38), dp(26));
        layoutParams2.setMargins(5, 5, 5, 5);
		
		//startWelcomeTextToSpeech();

	   //********** The icon to open mod menu **********
       startimage = new ImageView(context);
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension = (int) TypedValue.applyDimension(1, ICON_SIZE, context.getResources().getDisplayMetrics()); //Icon size
       startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
		
		ColorMatrix colorMatrix = new ColorMatrix();
		colorMatrix.setSaturation(0.3f); // Reduce la saturación
		float[] matrix = {
			0.5f, 0,   0,   0, 0,
			0,   0.5f, 0,   0, 0,
			0,   0,   1.2f, 0, 0,
			0,   0,   0,   1, 0
		};
		colorMatrix.set(matrix);
		startimage.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
      //icon 
		LayoutParams layoutParams3 = new LayoutParams(dp(38), dp(26));
        layoutParams3.setMargins(5, 5, 5, 5);
        Button startimage = new Button(context);
        startimage.setText("FEL2K");
        startimage.setShadowLayer((float) 12, (float) 0, (float) 0, -1);
        startimage.setBackground(gradientDrawable);
        startimage.setTextSize((float) 14);
        startimage.setLayoutParams(layoutParams2);
        startimage.setPadding(dp(2), 5, 5, 5);
		startimage.setTypeface(Typeface.createFromAsset(getContext.getAssets(),"FontsV2/BoldFont.ttf"));
		
		startimage.setOnTouchListener(onTouchListener());
		startimage.setOnClickListener(new View.OnClickListener() {		
			public void onClick(View view) {
					mCollapsed.setVisibility(View.GONE);
					mExpanded.setVisibility(View.VISIBLE);
				}
			});
			
			
					
			
		

// Floating up-down animation
		

        //********** The icon in Webview to open mod menu **********
        WebView wView = new WebView(context); //Icon size width=\"50\" height=\"50\"
        wView.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension2 = (int) TypedValue.applyDimension(1, ICON_SIZE, context.getResources().getDisplayMetrics()); //Icon size
        wView.getLayoutParams().height = applyDimension2;
        wView.getLayoutParams().width = applyDimension2;
        wView.loadData("<html>" +
					   "<head></head>" +
					   "<body style=\"margin: 0; padding: 0\">" +
					   "<img src=\"" + IconWebViewData() + "\" width=\"" + ICON_SIZE + "\" height=\"" + ICON_SIZE + "\" >" +
					   "</body>" +
					   "</html>", "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setAlpha(ICON_ALPHA);
        wView.getSettings().setAppCacheEnabled(true);
        wView.setOnTouchListener(onTouchListener());

		MainsubLayout = new LinearLayout(context);
		MainsubLayout.setOrientation(LinearLayout.HORIZONTAL);
		MainsubLayout.setPadding(5,5,5,5);

		subLayout = new LinearLayout(context);
		subLayout.setOrientation(LinearLayout.VERTICAL);

        //********** Settings icon **********
        TextView textView = new TextView(context); //Android 5 can't show ⚙, instead show other icon instead
        textView.setText(Build.VERSION.SDK_INT >= 23 ? "❌" : "❌");
		textView.setTextColor(this.TEXT_COLOR);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(15.0f);
        RelativeLayout.LayoutParams rlsettings = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rlsettings.addRule(ALIGN_PARENT_RIGHT);
        textView.setLayoutParams(rlsettings);
        textView.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					mCollapsed.setVisibility(View.VISIBLE);
					mCollapsed.setAlpha(ICON_ALPHA);
					mExpanded.setVisibility(View.GONE);
					
				}
			});
		
	



        //********** Settings **********
        mSettings = new LinearLayout(context);
        mSettings.setOrientation(LinearLayout.VERTICAL);
        featureList(SettingsList(), mSettings);

        //********** Title **********
        RelativeLayout titleText = new RelativeLayout(context);
        titleText.setPadding(10, 5, 10, 5);
        titleText.setVerticalGravity(16);
        TextView title = new TextView(context);
        title.setTextColor(Color.parseColor("#347591"));
        title.setTextSize(15.0f);
        title.setShadowLayer((float) 12, (float) 0, (float) 0, -1);
        title.setGravity(17);
        RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.CENTER_HORIZONTAL);
        title.setLayoutParams(rl);

        //********** Sub title **********
        TextView subTitle = new TextView(context);
        subTitle.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        subTitle.setMarqueeRepeatLimit(-1);
        subTitle.setSingleLine(true);
        subTitle.setSelected(true);
        subTitle.setTextColor(TEXT_COLOR);
		//subTitle.setBackgroundColor(Color.parseColor("#347591"));
        subTitle.setTextSize(10.0f);
        subTitle.setGravity(Gravity.CENTER);
		subTitle.setTypeface(Typeface.createFromAsset(getContext.getAssets(),"FontsV2/Custom.ttf"));
        subTitle.setPadding(0, 0, 0, 5);
		LayoutParams layoutParams4 = new LayoutParams(-1, 5);
        layoutParams4.setMargins(16, 100, 16, 8);
		//subTitle.setTypeface(Typeface.createFromAsset(getContext.getAssets(),"MyFonts"));
			

		final LinearLayout mkl = new LinearLayout(context);
		mkl.setOrientation(LinearLayout.HORIZONTAL);

		scrollView2 = new ScrollView(context);

		LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(20));
        dp.setMargins(5,5,5,5);

		final LinearLayout rightPanel = new LinearLayout(context);

        LayoutParams right = new LayoutParams(MATCH_PARENT, WRAP_CONTENT); 
        rightPanel.setOrientation(LinearLayout.VERTICAL);
        rightPanel.setLayoutParams(right);
        rightPanel.setGravity(Gravity.CENTER);

		linearLayoutbt = new LinearLayout(context);
		linearLayoutbt.setOrientation(LinearLayout.VERTICAL);
		try {

    InputStream is = context.getAssets().open("image.png");
    Bitmap bitmap = BitmapFactory.decodeStream(is);

    ImageView imageView = new ImageView(context);
	//startimage.setText("FEL2K");
    imageView.setLayoutParams(new LayoutParams(MATCH_PARENT, dp(80))); 
    imageView.setImageBitmap(bitmap);		
			
			final Context finalContext;
			finalContext = context;
			
			imageView.setOnClickListener(new View.OnClickListener() {
					boolean settingsOpen;

					@Override
					public void onClick(View v) {
						Intent var2 = new Intent("android.intent.action.VIEW");
						var2.setFlags(268435456);
						var2.setData(Uri.parse("https://www.youtube.com/@Fel2kgamerofficial"));
						finalContext.startActivity(var2);
					
					}
				});
		           
				 
				 
    linearLayoutbt.addView(imageView);

} catch (IOException e) {
    e.printStackTrace();
    System.exit(0);
}
		TextView description = new TextView(context);
		description.setText("MOD MENU BY FEL2K");
		description.setTextColor(Color.parseColor("#FFE2E2E2"));
		description.setTextSize(7);
		//description.setGravity(Gravity.CENTER);
		description.setPadding(12, 0, 12, 12);
		try {
			Typeface descFont = Typeface.createFromAsset(context.getAssets(), "FontsV2/PixelFont.ttf");
			description.setTypeface(descFont);
		} catch (Exception e) {
			e.printStackTrace();
		}
		linearLayoutbt.addView(description);
		

		LayoutParams layoutParams = new LayoutParams(MATCH_PARENT, WRAP_CONTENT);
		
		layoutParams.setMargins(5, 5, 5, 5);

		drawable = new GradientDrawable();
		//TabCheked.setColor(Color.YELLOW);
		drawable.setColor(MENU_FEATURE_BG_COLOR);
		drawable.setStroke(dp(1),-1);
		drawable.setCornerRadius(20f);

		TabunCheked = new GradientDrawable();
		TabunCheked.setColor(Color.TRANSPARENT);
		TabunCheked.setStroke(dp(2),-1); 
		TabunCheked.setCornerRadius(20f);		

		t1 = new Button(context);
        t1.setText("BASICS");
        t1.setGravity(17);
        t1.setTextColor(TEXT_COLOR_2);
        t1.setTextSize(TAB_TEXT_SIZE);
        t1.setPadding(15, 5, 15, 5);
        t1.setBackground(drawable);
        t1.setLayoutParams(dp);
		t1.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
                    //scrollView.removeAllViews();
					//scrollView.addView(mods);
					rt1.setVisibility(View.VISIBLE);
                    rt2.setVisibility(View.GONE);
					rt3.setVisibility(View.GONE);
                    rt4.setVisibility(View.GONE);
                    rt5.setVisibility(View.GONE);
                    rt6.setVisibility(View.GONE);
                    rt7.setVisibility(View.GONE);
					rt8.setVisibility(View.GONE);
					rt9.setVisibility(View.GONE);
					rt10.setVisibility(View.GONE);
					rt11.setVisibility(View.GONE);
					rt12.setVisibility(View.VISIBLE);
					rt13.setVisibility(View.GONE);
					rt14.setVisibility(View.GONE);
					rt15.setVisibility(View.GONE);
					
                    t1.setTextColor(Color.parseColor("#FFBF00"));
                    t2.setTextColor(Color.parseColor("#FFFFFF"));
                    t3.setTextColor(Color.parseColor("#FFFFFF"));
                    t4.setTextColor(Color.parseColor("#FFFFFF"));
                    t5.setTextColor(Color.parseColor("#FFFFFF"));
                    t6.setTextColor(Color.parseColor("#FFFFFF"));
					t7.setTextColor(Color.parseColor("#FFFFFF"));
					if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });

		t2 = new Button(context);
        t2.setText("HD COURT");
        t2.setGravity(17);
        t2.setTextColor(TEXT_COLOR_2);
        t2.setTextSize(TAB_TEXT_SIZE);
        t2.setPadding(15, 5, 15, 5);
        t2.setBackground(drawable);
        t2.setLayoutParams(dp);
		t2.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
                    //scrollView.removeAllViews();
					//scrollView.addView(mods2);
					rt1.setVisibility(View.GONE);
                    rt2.setVisibility(View.VISIBLE);
					rt3.setVisibility(View.GONE);
                    rt4.setVisibility(View.GONE);
                    rt5.setVisibility(View.GONE);
                    rt6.setVisibility(View.GONE);
                    rt7.setVisibility(View.GONE);
					rt8.setVisibility(View.GONE);
					rt9.setVisibility(View.GONE);
					rt10.setVisibility(View.GONE);
					rt11.setVisibility(View.GONE);
					rt12.setVisibility(View.GONE);
					rt13.setVisibility(View.GONE);
					rt14.setVisibility(View.GONE);
					rt15.setVisibility(View.GONE);
					
                    t1.setTextColor(Color.parseColor("#FFFFFF"));
                    t2.setTextColor(Color.parseColor("#FFBF00"));
                    t3.setTextColor(Color.parseColor("#FFFFFF"));
                    t4.setTextColor(Color.parseColor("#FFFFFF"));
                    t5.setTextColor(Color.parseColor("#FFFFFF"));
					t6.setTextColor(Color.parseColor("#FFFFFF"));
                    t7.setTextColor(Color.parseColor("#FFFFFF"));
                    if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });
            

		t3 = new Button(context);
        t3.setText("INGAME");
        t3.setGravity(17);
        t3.setTextColor(TEXT_COLOR_2);
        t3.setTextSize(TAB_TEXT_SIZE);
        t3.setPadding(15, 5, 15, 5);
        t3.setBackground(drawable);
        t3.setLayoutParams(dp);
		t3.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
                 //   scrollView.removeAllViews();
				//	scrollView.addView(mods3);
					rt1.setVisibility(View.GONE);
                    rt2.setVisibility(View.GONE);
                    rt3.setVisibility(View.GONE);
                    rt4.setVisibility(View.GONE);
                    rt5.setVisibility(View.VISIBLE);
                    rt6.setVisibility(View.VISIBLE);
                    rt7.setVisibility(View.VISIBLE);
					rt8.setVisibility(View.VISIBLE);
					rt9.setVisibility(View.GONE);
					rt10.setVisibility(View.GONE);
					rt11.setVisibility(View.GONE);
					rt12.setVisibility(View.GONE);
					rt13.setVisibility(View.GONE);
					rt14.setVisibility(View.GONE);
					rt15.setVisibility(View.GONE);
					
                    t1.setTextColor(Color.parseColor("#FFFFFF"));
                    t2.setTextColor(Color.parseColor("#FFFFFF"));
                    t3.setTextColor(Color.parseColor("#FFBF00"));
                    t4.setTextColor(Color.parseColor("#FFFFFF"));
                    t5.setTextColor(Color.parseColor("#FFFFFF"));
					t6.setTextColor(Color.parseColor("#FFFFFF"));
                    t7.setTextColor(Color.parseColor("#FFFFFF"));
               if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });

	    t4 = new Button(context);
        t4.setText("PLAYER INFO");
        t4.setGravity(17);
        t4.setTextColor(TEXT_COLOR_2);
        t4.setTextSize(TAB_TEXT_SIZE);
        t4.setPadding(15, 5, 15, 5);
        t4.setBackground(drawable);
        t4.setLayoutParams(dp);
		t4.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
           //         scrollView.removeAllViews();
				//	scrollView.addView(mods4);
					rt1.setVisibility(View.GONE);
                    rt2.setVisibility(View.GONE);
                    rt3.setVisibility(View.VISIBLE);
                    rt4.setVisibility(View.GONE);
                    rt5.setVisibility(View.GONE);
                    rt6.setVisibility(View.GONE);
                    rt7.setVisibility(View.GONE);
					rt8.setVisibility(View.GONE);
					rt9.setVisibility(View.VISIBLE);
					rt10.setVisibility(View.GONE);
					rt11.setVisibility(View.VISIBLE);
					rt12.setVisibility(View.GONE);
					rt13.setVisibility(View.GONE);
					rt14.setVisibility(View.GONE);
					rt15.setVisibility(View.GONE);
					
                    t1.setTextColor(Color.parseColor("#FFFFFF"));
                    t2.setTextColor(Color.parseColor("#FFFFFF"));
                    t3.setTextColor(Color.parseColor("#FFFFFF"));
                    t4.setTextColor(Color.parseColor("#FFBF00"));
                    t5.setTextColor(Color.parseColor("#FFFFFF"));
					t6.setTextColor(Color.parseColor("#FFFFFF"));
					t7.setTextColor(Color.parseColor("#FFFFFF"));
					
                if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });

		t5 = new Button(context);
        t5.setText("EQUIPMENT");
        t5.setGravity(17);
        t5.setTextColor(TEXT_COLOR_2);
        t5.setTextSize(TAB_TEXT_SIZE);
        t5.setPadding(15, 5, 15, 5);
        t5.setBackground(drawable);
        t5.setLayoutParams(dp);
		t5.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
                  //  scrollView.removeAllViews();
				//	scrollView.addView(mSettings);
					rt1.setVisibility(View.GONE);
                    rt2.setVisibility(View.GONE);
                    rt3.setVisibility(View.GONE);
                    rt4.setVisibility(View.VISIBLE);
                    rt5.setVisibility(View.GONE);
                    rt6.setVisibility(View.GONE);
                    rt7.setVisibility(View.GONE);
                    rt8.setVisibility(View.GONE);
                    rt9.setVisibility(View.GONE);
					rt10.setVisibility(View.GONE);
					rt11.setVisibility(View.GONE);
					rt12.setVisibility(View.GONE);
					rt13.setVisibility(View.GONE);
					rt14.setVisibility(View.GONE);
					rt15.setVisibility(View.GONE);
					
                    t1.setTextColor(Color.parseColor("#FFFFFF"));
                    t2.setTextColor(Color.parseColor("#FFFFFF"));
                    t3.setTextColor(Color.parseColor("#FFFFFF"));
                    t4.setTextColor(Color.parseColor("#FFFFFF"));
                    t5.setTextColor(Color.parseColor("#FFBF00"));
                    t6.setTextColor(Color.parseColor("#FFFFFF"));
					t7.setTextColor(Color.parseColor("#FFFFFF"));
                if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });
			
		t6 = new Button(context);
        t6.setText("JERSEY");
        t6.setGravity(17);
        t6.setTextColor(TEXT_COLOR_2);
        t6.setTextSize(TAB_TEXT_SIZE);
        t6.setPadding(15, 5, 15, 5);
        t6.setBackground(drawable);
        t6.setLayoutParams(dp);
		t6.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
					//  scrollView.removeAllViews();
					//	scrollView.addView(mSettings);
					rt1.setVisibility(View.GONE);
                    rt2.setVisibility(View.GONE);
                    rt3.setVisibility(View.GONE);
                    rt4.setVisibility(View.GONE);
                    rt5.setVisibility(View.GONE);
                    rt6.setVisibility(View.GONE);
                    rt7.setVisibility(View.GONE);
                    rt8.setVisibility(View.GONE);
                    rt9.setVisibility(View.GONE);
					rt10.setVisibility(View.GONE);
					rt11.setVisibility(View.GONE);
					rt12.setVisibility(View.GONE);
					rt13.setVisibility(View.VISIBLE);
					rt14.setVisibility(View.VISIBLE);
					rt15.setVisibility(View.VISIBLE);
					t1.setTextSize(13);
                    t2.setTextSize(13);
                    t3.setTextSize(13);
                    t4.setTextSize(13);
                    t5.setTextSize(13);
					t6.setTextSize(15);
					t7.setTextSize(13);

                    t1.setTextColor(Color.parseColor("#FFFFFF"));
                    t2.setTextColor(Color.parseColor("#FFFFFF"));
                    t3.setTextColor(Color.parseColor("#FFFFFF"));
                    t4.setTextColor(Color.parseColor("#FFFFFF"));
                    t5.setTextColor(Color.parseColor("#FFFFFF"));
					t6.setTextColor(Color.parseColor("#FFBF00"));
					t7.setTextColor(Color.parseColor("#FFFFFF"));

					if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });
			
		t7 = new Button(context);
        t7.setText("SETTINGS");
        t7.setGravity(17);
        t7.setTextColor(TEXT_COLOR_2);
        t7.setTextSize(TAB_TEXT_SIZE);
        t7.setPadding(15, 5, 15, 5);
        t7.setBackground(drawable);
        t7.setLayoutParams(dp);
		t7.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1) {
					//  scrollView.removeAllViews();
					//	scrollView.addView(mSettings);
					rt1.setVisibility(View.GONE);
                    rt2.setVisibility(View.GONE);
                    rt3.setVisibility(View.GONE);
                    rt4.setVisibility(View.GONE);
                    rt5.setVisibility(View.GONE);
                    rt6.setVisibility(View.GONE);
                    rt7.setVisibility(View.GONE);
                    rt8.setVisibility(View.GONE);
                    rt9.setVisibility(View.GONE);
					rt10.setVisibility(View.VISIBLE);
					rt11.setVisibility(View.GONE);
					rt12.setVisibility(View.GONE);
					rt13.setVisibility(View.GONE);
					rt14.setVisibility(View.GONE);
					rt15.setVisibility(View.GONE);
					

                    t1.setTextColor(Color.parseColor("#FFFFFF"));
                    t2.setTextColor(Color.parseColor("#FFFFFF"));
                    t3.setTextColor(Color.parseColor("#FFFFFF"));
                    t4.setTextColor(Color.parseColor("#FFFFFF"));
                    t5.setTextColor(Color.parseColor("#FFFFFF"));
					t6.setTextColor(Color.parseColor("#FFFFFF"));
					t7.setTextColor(Color.parseColor("#FFBF00"));

					if (mkl.indexOfChild(rightPanel) == -1) {
                        mkl.addView(rightPanel);
					}}
            });
			
		
			
			
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬2ndTAB▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
		rt1 = new Button(context);
        rt1.setSingleLine(true); 
        rt1.setText("BASIC");
        rt1.setTextColor(TEXT_COLOR_2);
        rt1.setTextSize(TAB_TEXT_SIZE);          
        rt1.setGravity(17);    
        rt1.setBackground(drawable);
        rt1.setPadding(dp(2), 0, 0, 0);
        rt1.setLayoutParams(dp);
        rt1.setOnClickListener(new OnClickListener() {
        //rt1.setOnClickListener(new OnClickListener() {
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods);
					
				}});


		rightPanel.addView(rt1);



		rt2 = new Button(context);
        rt2.setSingleLine(true);
        rt2.setText("HD COURT");
        rt2.setGravity(17);
        rt2.setTextColor(TEXT_COLOR_2);
        rt2.setTextSize(TAB_TEXT_SIZE);
        rt2.setPadding(dp(2), 0, 0, 0);
        rt2.setBackground(drawable);
        rt2.setLayoutParams(dp);
		rt2.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods2);
			
				}});	


		rightPanel.addView(rt2);

		rt8 = new Button(context);
        rt8.setSingleLine(true); 
        rt8.setText("HIGHRATES");
        rt8.setTextColor(TEXT_COLOR_2);
        rt8.setTextSize(TAB_TEXT_SIZE);          
        rt8.setGravity(17);    
        rt8.setBackground(drawable);
        rt8.setPadding(dp(2), 0, 0, 0);
        rt8.setLayoutParams(dp);
		rt8.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods3);
					
				}});	


		rightPanel.addView(rt8);

		rt9 = new Button(context);
        rt9.setSingleLine(true); 
        rt9.setText("INFORMATION");
        rt9.setTextColor(TEXT_COLOR_2);
        rt9.setTextSize(TAB_TEXT_SIZE);          
        rt9.setGravity(17);    
        rt9.setBackground(drawable);
        rt9.setPadding(dp(2), 0, 0, 0);
        rt9.setLayoutParams(dp);
		rt9.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods4);
					
				}});	


		rightPanel.addView(rt9);

		rt3 = new Button(context);
        rt3.setSingleLine(true);
        rt3.setText("MY CAREER");
        rt3.setGravity(17);
        rt3.setTextColor(TEXT_COLOR_2);
        rt3.setTextSize(TAB_TEXT_SIZE);
        rt3.setPadding(dp(2), 0, 0, 0);
        rt3.setBackground(drawable);
        rt3.setLayoutParams(dp);
		rt3.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods5);
					
				}});	


		rightPanel.addView(rt3);

		rt4 = new Button(context);
        rt4.setSingleLine(true);
        rt4.setText("ACCESSORIES");
        rt4.setGravity(17);
        rt4.setTextColor(TEXT_COLOR_2);
        rt4.setTextSize(TAB_TEXT_SIZE);
        rt4.setPadding(dp(2), 0, 0, 0);
        rt4.setBackground(drawable);
        rt4.setLayoutParams(dp);
		rt4.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods6);
					
				}});	


		rightPanel.addView(rt4);

		rt5 = new Button(context);
        rt5.setText("DARK CROWD");
        rt5.setGravity(17);
        rt5.setTextColor(TEXT_COLOR_2);
        rt5.setTextSize(TAB_TEXT_SIZE);
        rt5.setPadding(15, 5, 15, 5);
        rt5.setBackground(drawable);
        rt5.setLayoutParams(dp);
		rt5.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods7);
					
				}});	


		rightPanel.addView(rt5);

		rt6 = new Button(context);
        rt6.setText("HD CROWD");
        rt6.setGravity(17);
        rt6.setTextColor(TEXT_COLOR_2);
        rt6.setTextSize(TAB_TEXT_SIZE);
        rt6.setPadding(15, 5, 15, 5);
        rt6.setBackground(drawable);
        rt6.setLayoutParams(dp);
		rt6.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods8);
					
				}});	


		rightPanel.addView(rt6);

		rt7 = new Button(context);
        rt7.setText("HD FEATURES");
        rt7.setGravity(17);
        rt7.setTextColor(TEXT_COLOR_2);
        rt7.setTextSize(TAB_TEXT_SIZE);
        rt7.setPadding(15, 5, 15, 5);
        rt7.setBackground(drawable);
        rt7.setLayoutParams(dp);
		rt7.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods9);
					
				}});	


		rightPanel.addView(rt7);
		
		
		rt10 = new Button(context);
        rt10.setSingleLine(true);
        rt10.setText("SETTINGS");
        rt10.setGravity(17);
        rt10.setTextColor(TEXT_COLOR_2);
        rt10.setTextSize(TAB_TEXT_SIZE);
        rt10.setPadding(dp(2), 0, 0, 0);
        rt10.setBackground(drawable);
        rt10.setLayoutParams(dp);
		rt10.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mSettings);
					
				}});	


		rightPanel.addView(rt10);
			
		rt11 = new Button(context);
        rt11.setSingleLine(true);
        rt11.setText("COPY...");
        rt11.setGravity(17);
        rt11.setTextColor(TEXT_COLOR_2);
        rt11.setTextSize(TAB_TEXT_SIZE);
        rt11.setPadding(dp(2), 0, 0, 0);
        rt11.setBackground(drawable);
        rt11.setLayoutParams(dp);
		rt11.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods10);
					
				}});	


		rightPanel.addView(rt11);
		
		rt12 = new Button(context);
        rt12.setSingleLine(true);
        rt12.setText("GET ROSTERS");
        rt12.setGravity(17);
        rt12.setTextColor(TEXT_COLOR_2);
        rt12.setTextSize(TAB_TEXT_SIZE);
        rt12.setPadding(dp(2), 0, 0, 0);
        rt12.setBackground(drawable);
        rt12.setLayoutParams(dp);
		rt12.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods11);
					
				}});	


		rightPanel.addView(rt12);
		
		rt13 = new Button(context);
        rt13.setSingleLine(true);
        rt13.setText("HOME");
        rt13.setGravity(17);
        rt13.setTextColor(TEXT_COLOR_2);
        rt13.setTextSize(TAB_TEXT_SIZE);
        rt13.setPadding(dp(2), 0, 0, 0);
        rt13.setBackground(drawable);
        rt13.setLayoutParams(dp);
		rt13.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods12);
				}});	


		rightPanel.addView(rt13);
		
		rt14 = new Button(context);
        rt14.setSingleLine(true);
        rt14.setText("AWAY");
        rt14.setGravity(17);
        rt14.setTextColor(TEXT_COLOR_2);
        rt14.setTextSize(TAB_TEXT_SIZE);
        rt14.setPadding(dp(2), 0, 0, 0);
        rt14.setBackground(drawable);
        rt14.setLayoutParams(dp);
		rt14.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods13);
				}});	


		rightPanel.addView(rt14);
		
		rt15 = new Button(context);
        rt15.setSingleLine(true);
        rt15.setText("ALTERNATE");
        rt15.setGravity(17);
        rt15.setTextColor(TEXT_COLOR_2);
        rt15.setTextSize(TAB_TEXT_SIZE);
        rt15.setPadding(dp(2), 0, 0, 0);
        rt15.setBackground(drawable);
        rt15.setLayoutParams(dp);
		rt15.setOnClickListener(new OnClickListener(){
				@Override
                public void onClick(View p1) {
					scrollView.removeAllViews();  
					scrollView.addView(mods14);
				}});	


		rightPanel.addView(rt15);

        //********** Mod menu feature list **********
        scrollView = new ScrollView(context);
		scrollView.setLayoutParams(new LayoutParams(MATCH_PARENT,MATCH_PARENT));
        //Auto size. To set size manually, change the width and height example 500, 500
        scrlLL = new LinearLayout.LayoutParams(MATCH_PARENT, dp(MENU_HEIGHT));
        scrlLLExpanded = new LinearLayout.LayoutParams(mExpanded.getLayoutParams());
        scrlLLExpanded.weight = 1.0f;
        MainsubLayout.setLayoutParams(Preferences.isExpanded ? scrlLLExpanded : scrlLL);
       // scrollView.setBackgroundColor(MENU_FEATURE_BG_COLOR);
		
        mods = new LinearLayout(context);
        mods.setOrientation(LinearLayout.VERTICAL);

		mods2 = new LinearLayout(context);
		mods2.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList2(),mods2);

		mods3 = new LinearLayout(context);
		mods3.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList3(),mods3);

		mods4 = new LinearLayout(context);
		mods4.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList4(),mods4);

		mods5 = new LinearLayout(context);
		mods5.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList5(),mods5);

		mods6 = new LinearLayout(context);
		mods6.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList6(),mods6);
		
		mods7 = new LinearLayout(context);
		mods7.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList7(),mods7);
		
		mods8 = new LinearLayout(context);
		mods8.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList8(),mods8);
		
		mods9 = new LinearLayout(context);
		mods9.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList9(),mods9);
		
		mods10 = new LinearLayout(context);
		mods10.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList10(),mods10);
		
		mods11 = new LinearLayout(context);
		mods11.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList11(),mods11);
		
		mods12 = new LinearLayout(context);
		mods12.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList12(),mods12);
		
		mods13 = new LinearLayout(context);
		mods13.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList13(),mods13);
		
		mods14 = new LinearLayout(context);
		mods14.setOrientation(LinearLayout.VERTICAL);
		featureList(GetFeatureList14(),mods14);

        //********** Adding view components **********
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        if (IconWebViewData() != null) {
            mCollapsed.addView(wView);
        } else {
            mCollapsed.addView(startimage);
        }
        titleText.addView(title);
        titleText.addView(textView);
        mExpanded.addView(titleText);
        mExpanded.addView(subTitle);
		mExpanded.addView(MainsubLayout);
		MainsubLayout.addView(subLayout);
		subLayout.addView(mkl);
		mkl.addView(scrollView2);
		scrollView2.addView(linearLayoutbt);
		linearLayoutbt.addView(t1);
		linearLayoutbt.addView(t2);
		linearLayoutbt.addView(t3);
		linearLayoutbt.addView(t4);
		linearLayoutbt.addView(t5);
		linearLayoutbt.addView(t6);
		linearLayoutbt.addView(t7);
		//linearLayoutbt.addView(t8);
	//	linearLayoutbt.addView(t9);
	//	linearLayoutbt.addView(t10);
        scrollView.addView(mods);
        MainsubLayout.addView(scrollView);
        Init(context, title, subTitle);
    }

    public void ShowMenu() {
        rootFrame.addView(mRootContainer);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
				boolean viewLoaded = false;

				@Override
				public void run() {
					//If the save preferences is enabled, it will check if game lib is loaded before starting menu
					//Comment the if-else code out except startService if you want to run the app and test preferences
					if (Preferences.loadPref && !IsGameLibLoaded() && !stopChecking) {
						if (!viewLoaded) {
							Category(mods, "Save preferences was been enabled. Waiting for game lib to be loaded...\n\nForce load menu may not apply mods instantly. You would need to reactivate them again");
							Button(mods, -100, "Force load menu");
							viewLoaded = true;
						}
						handler.postDelayed(this, 600);
					} else {
						mods.removeAllViews();
						featureList(GetFeatureList(), mods);
					}
				}
			}, 500);
    }

    @SuppressLint("WrongConstant")
    public void SetWindowManagerWindowService() {
        //Variable to check later if the phone supports Draw over other apps permission
        int iparams = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
        vmParams = new WindowManager.LayoutParams(MATCH_PARENT, WRAP_CONTENT, iparams, 8, -3);

        //params = new WindowManager.LayoutParams(WindowManager.LayoutParams.LAST_APPLICATION_WINDOW, 8, -3);
        vmParams.gravity = 10;
        vmParams.x = 0;
        vmParams.y = 0;

        mWindowManager = (WindowManager) getContext.getSystemService(getContext.WINDOW_SERVICE);
        mWindowManager.addView(rootFrame,vmParams);


        overlayRequired = true;
    }

    @SuppressLint("WrongConstant")
    public void SetWindowManagerActivity() {
        vmParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            POS_X,//initialX
            POS_Y,//initialy
            WindowManager.LayoutParams.TYPE_APPLICATION,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |     
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
            WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
            PixelFormat.TRANSPARENT
        );
        vmParams.gravity = 10;
        vmParams.x = 0;
        vmParams.y = 0;

        mWindowManager = ((Activity) getContext).getWindowManager();
        mWindowManager.addView(rootFrame, vmParams);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX, initialTouchY;
            private int initialX, initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = vmParams.x;
                        initialY = vmParams.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);
                        mExpanded.setAlpha(1f);
                        mCollapsed.setAlpha(1f);
                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            try {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            } catch (NullPointerException e) {

                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        mExpanded.setAlpha(0.5f);
                        mCollapsed.setAlpha(0.5f);
                        //Calculate the X and Y coordinates of the view.
                        vmParams.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        vmParams.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(rootFrame, vmParams);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }
	

    private void featureList(String[] listFT, LinearLayout linearLayout) {
        //Currently looks messy right now. Let me know if you have improvements
        int featNum, subFeat = 0;
        LinearLayout llBak = linearLayout;

        for (int i = 0; i < listFT.length; i++) {
            boolean switchedOn = false;
            //Log.i("featureList", listFT[i]);
            String feature = listFT[i];
            if (feature.contains("_True")) {
                switchedOn = true;
                feature = feature.replaceFirst("_True", "");
            }

            linearLayout = llBak;
            if (feature.contains("CollapseAdd_")) {
                //if (collapse != null)
                linearLayout = mCollapse;
                feature = feature.replaceFirst("CollapseAdd_", "");
            }
            String[] str = feature.split("_");

            //Assign feature number
            if (TextUtils.isDigitsOnly(str[0]) || str[0].matches("-[0-9]*")) {
                featNum = Integer.parseInt(str[0]);
                feature = feature.replaceFirst(str[0] + "_", "");
                subFeat++;
            } else {
                //Subtract feature number. We don't want to count ButtonLink, Category, RichTextView and RichWebView
                featNum = i - subFeat;
            }
            String[] strSplit = feature.split("_");
            switch (strSplit[0]) {
                case "PagerController":
                    String[] pages2 = strSplit[1].split("_");
                    String[] pages = strSplit[2].split(",");
                    PagerController(linearLayout, featNum, pages,pages2);
                    break;
                case "Toggle":
                    // Instead of calling Switch, call ToggleTextView to add the TextView with toggle effect
                    linearLayout.addView(Switch(featNum, strSplit[1],switchedOn));
                    break;
                case "SeekBar":
                    linearLayout.addView(SeekBar(featNum, strSplit[1], Integer.parseInt(strSplit[2]), Integer.parseInt(strSplit[3])));
                    break;
                case "Button":
                    Button(linearLayout, featNum, strSplit[1]);
                    break;
                case "ButtonOnOff":
                    ButtonOnOff(linearLayout, featNum, strSplit[1], switchedOn);
                    break;
                case "Spinner":
                    TextView(linearLayout, strSplit[1]);
                    Spinner(linearLayout, featNum, strSplit[1], strSplit[2]);
                    break;
                case "InputText":
                    InputText(linearLayout, featNum, strSplit[1]);
                    break;
                case "InputValue":
                    if (strSplit.length == 3)
                        InputNum(linearLayout, featNum, strSplit[2], Integer.parseInt(strSplit[1]));
                    if (strSplit.length == 2)
                        InputNum(linearLayout, featNum, strSplit[1], 0);
                    break;
                case "CheckBox":
					linearLayout.addView(CheckBox( featNum, strSplit[1], switchedOn));
                    break;
                case "RadioButton":
                    linearLayout.addView(RadioButton(featNum, strSplit[1], strSplit[2]));
                    break;
                case "Collapse":
                    Collapse(linearLayout, strSplit[1], switchedOn);
                    subFeat++;
                    break; 
                case "ButtonLink":
                    subFeat++;
                    ButtonLink(linearLayout, strSplit[1], strSplit[2]);
                    break;
                case "Category":
                    subFeat++;
                    Category(linearLayout, strSplit[1]);
                    break;
                case "Category2":
                    subFeat++;
                    Category2(linearLayout, strSplit[1]);
                    break;
                case "RichTextView":
                    subFeat++;
                    TextView(linearLayout, strSplit[1]);
                    break;
                case "RichWebView":
                    subFeat++;
                    WebTextView(linearLayout, strSplit[1]);
                    break;
			    case "Button2":
					linearLayout.addView(Button2(featNum, strSplit[1],switchedOn));
                    break;
				case "Button3":
					linearLayout.addView(Button3(featNum, strSplit[1],switchedOn));
                    break;
				case "EndGame":
					linearLayout.addView(Buttons4(featNum, strSplit[1],switchedOn));
                    break;
				case "Buttons5":
					linearLayout.addView(Buttons5(featNum, strSplit[1],switchedOn));
                    break;
            }
        }
    }
	private View Buttons5(final int featNum, final String featName, boolean SwiOn) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create a horizontal LinearLayout to contain the TextView and icons
        LinearLayout layout = new LinearLayout(getContext);        
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackground(strokeBackground);
        layout.setPadding(10, 5, 10, 5); // Add padding if needed


        LinearLayout.LayoutParams Swittch = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        Swittch.setMargins(15,5,15,5);
        layout.setLayoutParams(Swittch);



        // Create the TextView for the feature name
        final TextView toggleTextView = new TextView(getContext);
        toggleTextView.setTextColor(Color.WHITE);
        toggleTextView.setText(featName); // Only the feature name
		SetFont(toggleTextView);
        toggleTextView.setTextSize(16); // Set text size
        toggleTextView.setGravity(Gravity.START); // Align to the left
        toggleTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1)); // Use weight for alignment

        // Create the TextView for the icon
        final TextView iconTextView = new TextView(getContext);
		iconTextView.setText(swiOn ? "🔄" : "🔄"); // Set the initial icon
        iconTextView.setTextSize(16); // Set text size
        iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED); // Set initial color
        iconTextView.setGravity(Gravity.END); // Align to the right

        // Add the TextViews to the LinearLayout
        layout.addView(toggleTextView);
        layout.addView(iconTextView);

        // Set up the onClickListener to toggle the state
        layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
					//backupFiles(1,"","","","");
                    // Toggle the swiOn state
                    swiOn = !swiOn;

                    // Update the icon and its color
                    iconTextView.setText(swiOn ? "🔄" : "🔄");
                    iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED);
					

					// Save the updated state in SharedPreferences or your custom storage
                    Preferences.changeFeatureBool(featName, featNum, swiOn);


                    // Perform any additional changes based on featNum
                    switch (featNum) {
                        case -1: // Save preferences
                            Preferences.with(toggleTextView.getContext()).writeBoolean(-1, swiOn);
                            if (!swiOn)
                                Preferences.with(toggleTextView.getContext()).clear(); // Clear preferences if switched off
                            break;
                        case -3:
                            Preferences.isExpanded = swiOn;




                            scrollView.setLayoutParams(swiOn ? scrlLLExpanded : scrlLL);


                            break;
                    }
                }
            });

        return layout; // Return the entire layout as a View
    }
	
	private View Buttons4(final int featNum, final String featName, boolean SwiOn) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create a horizontal LinearLayout to contain the TextView and icons
        LinearLayout layout = new LinearLayout(getContext);        
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackground(strokeBackground);
        layout.setPadding(10, 5, 10, 5); // Add padding if needed


        LinearLayout.LayoutParams Swittch = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        Swittch.setMargins(15,5,15,5);
        layout.setLayoutParams(Swittch);



        // Create the TextView for the feature name
        final TextView toggleTextView = new TextView(getContext);
        toggleTextView.setTextColor(Color.WHITE);
        toggleTextView.setText(featName); // Only the feature name
		SetFont(toggleTextView);
        toggleTextView.setTextSize(16); // Set text size
        toggleTextView.setGravity(Gravity.START); // Align to the left
        toggleTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1)); // Use weight for alignment

        // Create the TextView for the icon
        final TextView iconTextView = new TextView(getContext);
		iconTextView.setText(swiOn ? "End" : "End"); // Set the initial icon
        iconTextView.setTextSize(16); // Set text size
        iconTextView.setTextColor(swiOn ? Color.WHITE : Color.WHITE); // Set initial color
        iconTextView.setGravity(Gravity.END); // Align to the right

        // Add the TextViews to the LinearLayout
        layout.addView(toggleTextView);
        layout.addView(iconTextView);

        // Set up the onClickListener to toggle the state
        layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Toggle the swiOn state
                    swiOn = !swiOn;

                    // Update the icon and its color
                    iconTextView.setText(swiOn ? "End" : "End");
                    iconTextView.setTextColor(swiOn ? Color.WHITE : Color.WHITE);

					// Save the updated state in SharedPreferences or your custom storage
                    Preferences.changeFeatureBool(featName, featNum, swiOn);


                    // Perform any additional changes based on featNum
                    switch (featNum) {
                        case -1: // Save preferences
                            Preferences.with(toggleTextView.getContext()).writeBoolean(-1, swiOn);
                            if (!swiOn)
                                Preferences.with(toggleTextView.getContext()).clear(); // Clear preferences if switched off
                            break;
                        case -3:
                            Preferences.isExpanded = swiOn;




                            scrollView.setLayoutParams(swiOn ? scrlLLExpanded : scrlLL);


                            break;				
                    }
                }
            });

        return layout; // Return the entire layout as a View
    }
	
	private View Button3(final int featNum, final String featName, boolean SwiOn) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create a horizontal LinearLayout to contain the TextView and icons
        LinearLayout layout = new LinearLayout(getContext);        
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackground(strokeBackground);
        layout.setPadding(10, 5, 10, 5); // Add padding if needed


        LinearLayout.LayoutParams Swittch = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        Swittch.setMargins(15,5,15,5);
        layout.setLayoutParams(Swittch);



        // Create the TextView for the feature name
        final TextView toggleTextView = new TextView(getContext);
        toggleTextView.setTextColor(Color.WHITE);
        toggleTextView.setText(featName); // Only the feature name
		SetFont(toggleTextView);
        toggleTextView.setTextSize(16); // Set text size
        toggleTextView.setGravity(Gravity.START); // Align to the left
        toggleTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1)); // Use weight for alignment

        // Create the TextView for the icon
        final TextView iconTextView = new TextView(getContext);
		iconTextView.setText(swiOn ? "🔄" : "🔄"); // Set the initial icon
        iconTextView.setTextSize(16); // Set text size
        iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED); // Set initial color
        iconTextView.setGravity(Gravity.END); // Align to the right

        // Add the TextViews to the LinearLayout
        layout.addView(toggleTextView);
        layout.addView(iconTextView);

        // Set up the onClickListener to toggle the state
        layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
					backupFiles(1,"","","","");
                    // Toggle the swiOn state
                    swiOn = !swiOn;

                    // Update the icon and its color
                    iconTextView.setText(swiOn ? "🔄" : "🔄");
                    iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED);

					// Save the updated state in SharedPreferences or your custom storage
                 
					Preferences.changeFeatureBool(featName, featNum, swiOn);


                    // Perform any additional changes based on featNum
                    switch (featNum) {
                        case -1: // Save preferences
                            Preferences.with(toggleTextView.getContext()).writeBoolean(-1, swiOn);
                            if (!swiOn)
                                Preferences.with(toggleTextView.getContext()).clear(); // Clear preferences if switched off
                            break;
                        case -3:
                            Preferences.isExpanded = swiOn;




                            scrollView.setLayoutParams(swiOn ? scrlLLExpanded : scrlLL);


                            break;
						case -6:
                            backupFiles = true;
                            break;	
						
                    }
                }
            });

        return layout; // Return the entire layout as a View
    }
	private void backupFiles(final int featNum, String MainStr, String SubStr, String btn, String btn2) {
        executor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        File sourceDir = getContext.getFilesDir();
                        File destDir = new File(getContext.getExternalFilesDir(null), "Fel2KFiles");
                        copyDir(sourceDir, destDir);
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext, "Backup Completed", Toast.LENGTH_SHORT).show();
                                }
                            });
                    } catch (final Exception e) {
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext, "Backup Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            });
                    }
                }
            });
    }	
				
	private View Button2(final int featNum, final String featName, boolean SwiOn) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create a horizontal LinearLayout to contain the TextView and icons
        LinearLayout layout = new LinearLayout(getContext);        
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackground(strokeBackground);
        layout.setPadding(10, 5, 10, 5); // Add padding if needed


        LinearLayout.LayoutParams Swittch = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        Swittch.setMargins(15,5,15,5);
        layout.setLayoutParams(Swittch);



        // Create the TextView for the feature name
        final TextView toggleTextView = new TextView(getContext);
        toggleTextView.setTextColor(Color.WHITE);
        toggleTextView.setText(featName); // Only the feature name
		SetFont(toggleTextView);
        toggleTextView.setTextSize(16); // Set text size
        toggleTextView.setGravity(Gravity.START); // Align to the left
        toggleTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1)); // Use weight for alignment

        // Create the TextView for the icon
        final TextView iconTextView = new TextView(getContext);
		iconTextView.setText(swiOn ? "🔄" : "🔄"); // Set the initial icon
        iconTextView.setTextSize(16); // Set text size
        iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED); // Set initial color
        iconTextView.setGravity(Gravity.END); // Align to the right

        // Add the TextViews to the LinearLayout
        layout.addView(toggleTextView);
        layout.addView(iconTextView);

        // Set up the onClickListener to toggle the state
        layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
					restoreFiles(1,"","","","");
                    // Toggle the swiOn state
                    swiOn = !swiOn;

                    // Update the icon and its color
                    iconTextView.setText(swiOn ? "🔄" : "🔄");
                    iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED);

              // Save the updated state in SharedPreferences or your custom storage
                    Preferences.changeFeatureBool(featName, featNum, swiOn);


                    // Perform any additional changes based on featNum
                    switch (featNum) {
                        case -1: // Save preferences
                            Preferences.with(toggleTextView.getContext()).writeBoolean(-1, swiOn);
                            if (!swiOn)
                                Preferences.with(toggleTextView.getContext()).clear(); // Clear preferences if switched off
                            break;
                        case -3:
                            Preferences.isExpanded = swiOn;




                            scrollView.setLayoutParams(swiOn ? scrlLLExpanded : scrlLL);
							
						break;
						case -100:
                            restoreFiles = true;
                            break;
                    }
                }
            });

        return layout; // Return the entire layout as a View
    }

    private void restoreFiles(final int featNum, String MainStr, String SubStr, String btn, String btn2) {
		executor.execute(new Runnable() {
				@Override
				public void run() {
					try {
						File sourceDir = new File(getContext.getExternalFilesDir(null), "Fel2KFiles");
						File destDir = getContext.getFilesDir();
						copyDir(sourceDir, destDir);
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(getContext, "Restore Completed", Toast.LENGTH_SHORT).show();
								}
							});
					} catch (final Exception e) {
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(getContext, "Restore Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
								}
							});
					}
				}
			});
	}


    private void PagerController(LinearLayout linLayout, final int featNum,final String[] pages,final String[] pages2 ) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create the LinearLayout for the pager controller with horizontal orientation
        LinearLayout pagerLayout = new LinearLayout(getContext);
        LinearLayout.LayoutParams pager = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        pager.setMargins(15,5,15,5);
        pagerLayout.setLayoutParams(pager);
        pagerLayout.setOrientation(LinearLayout.HORIZONTAL);
        pagerLayout.setGravity(Gravity.CENTER_VERTICAL);  // Center vertically
        pagerLayout.setWeightSum(3);  // Allocate equal space for buttons and TextView
        pagerLayout.setBackground(strokeBackground);



        GradientDrawable txtv = new GradientDrawable();
        txtv.setColor(Color.parseColor("#00000000")); // Black background
        txtv.setCornerRadius(40f); // Corner radius of 15dp
        LinearLayout.LayoutParams ly = new LinearLayout.LayoutParams(dp(5), dp(3));
        ly.setMargins(0,0,0,0);

        final Button textView2 = new Button(getContext);        
        textView2.setText(pages2[0]);  // Initially set to the first page text
		SetFont(textView2);
        textView2.setTextColor(TEXT_COLOR_2);
        textView2.setTextSize(13);        
        textView2.setBackground(txtv);

        // Create the TextView to display the current page
        final TextView textView = new TextView(getContext);        
        textView.setText(pages[0]);  // Initially set to the first page text
        SetFont(textView);
		textView.setTextColor(TEXT_COLOR_2);
        textView.setTextSize(13);        

        textView.setGravity(Gravity.CENTER);  // Ensure text is centered
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, WRAP_CONTENT, 1);  // Take remaining space
        textView.setLayoutParams(textParams);

        // Create a TextView for the Left button ("<") with a stroke around it
        TextView prevTextView = new TextView(getContext);
        prevTextView.setText("➢");
        prevTextView.setRotation(180);
        prevTextView.setTranslationY(10);       
        prevTextView.setTextColor(Color.parseColor("#347591"));
        prevTextView.setTextSize(20);
        prevTextView.setGravity(Gravity.CENTER);
        prevTextView.setPadding(10, 5, 10, 5); // Add padding to make the text bigger

        prevTextView.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP_CONTENT, 1));  // Set weight for equal distribution

        prevTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navigate to the previous page text
                    int currentIndex = Arrays.asList(pages).indexOf(textView.getText().toString());
                    if (currentIndex > 0) {
                        textView.setText(pages[currentIndex - 1]);  // Show the previous page text
                    } else {
                        textView.setText(pages[pages.length - 1]);  // Loop back to the last page text
                    }
                    // Save the current page index to preferences and trigger update
                    Preferences.changeFeatureInt("PagerText", featNum, Arrays.asList(pages).indexOf(textView.getText().toString()));
                }
            });

        // Create a TextView for the Right button (">") with a stroke around it
        TextView nextTextView = new TextView(getContext);
        nextTextView.setText("➣");
        nextTextView.setTextColor(Color.parseColor("#347591"));
        nextTextView.setTextSize(20);        
        nextTextView.setGravity(Gravity.CENTER);
        nextTextView.setPadding(10, 5, 10, 5); // Add padding to make the text bigger

        // Set the border for the nextTextView programmatically
        nextTextView.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP_CONTENT, 1));  // Set weight for equal distribution

        nextTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navigate to the next page text
                    int currentIndex = Arrays.asList(pages).indexOf(textView.getText().toString());
                    if (currentIndex < pages.length - 1) {
                        textView.setText(pages[currentIndex + 1]);  // Show the next page text
                    } else {
                        textView.setText(pages[0]);  // Loop back to the first page text
                    }
                    // Save the current page index to preferences and trigger update
                    Preferences.changeFeatureInt("PagerText", featNum, Arrays.asList(pages).indexOf(textView.getText().toString()));
                }
            });


        pagerLayout.addView(textView2);
        // Add the views to the pagerLayout
        pagerLayout.addView(prevTextView);
        pagerLayout.addView(textView);
        pagerLayout.addView(nextTextView);

        // Add the pager layout to the main layout
        linLayout.addView(pagerLayout);
    }    
    private boolean swiOn = false; 
    private View Switch(final int featNum, final String featName, boolean SwiOn) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create a horizontal LinearLayout to contain the TextView and icons
        LinearLayout layout = new LinearLayout(getContext);        
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackground(strokeBackground);
        layout.setPadding(10, 5, 10, 5); // Add padding if needed


        LinearLayout.LayoutParams Swittch = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        Swittch.setMargins(15,5,15,5);
        layout.setLayoutParams(Swittch);
	



        // Create the TextView for the feature name
        final TextView toggleTextView = new TextView(getContext);
        toggleTextView.setTextColor(Color.WHITE);
        toggleTextView.setText(featName); // Only the feature name
		SetFont(toggleTextView);
        toggleTextView.setTextSize(16); // Set text size
        toggleTextView.setGravity(Gravity.START); // Align to the left
        toggleTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1)); // Use weight for alignment

        // Create the TextView for the icon
        final TextView iconTextView = new TextView(getContext);
        iconTextView.setText(swiOn ? "🟢" : "🔴"); // Set the initial icon
        iconTextView.setTextSize(16); // Set text size
        iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED); // Set initial color
        iconTextView.setGravity(Gravity.END); // Align to the right

        // Add the TextViews to the LinearLayout
        layout.addView(toggleTextView);
        layout.addView(iconTextView);

        // Set up the onClickListener to toggle the state
        layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Toggle the swiOn state
                    swiOn = !swiOn;

                    // Update the icon and its color
                    iconTextView.setText(swiOn ? "🟢" : "🔴");
                    iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED);
					

                    // Save the updated state in SharedPreferences or your custom storage
                    Preferences.changeFeatureBool(featName, featNum, swiOn);


                    // Perform any additional changes based on featNum
                    switch (featNum) {
                        case -1: // Save preferences
                            Preferences.with(toggleTextView.getContext()).writeBoolean(-1, swiOn);
                            if (!swiOn)
                                Preferences.with(toggleTextView.getContext()).clear(); // Clear preferences if switched off
                            break;
                        case -3:
                            Preferences.isExpanded = swiOn;




                            scrollView.setLayoutParams(swiOn ? scrlLLExpanded : scrlLL);


                            break;
                    }
                }
            });

        return layout; // Return the entire layout as a View
    }


    private View SeekBar(final int featNum, final String featName, final int min, int max) {
        int loadedProg = Preferences.loadPrefInt(featName, featNum);

        FrameLayout frameLayout = new FrameLayout(getContext);

// Set padding inside the FrameLayout
        frameLayout.setPadding(10, 5, 0, 5);

// Set the layout parameters with margin
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, // Width
            FrameLayout.LayoutParams.WRAP_CONTENT // Height
        );
        layoutParams.setMargins(15, 5, 15, 5); // Set the margin for all sides (left, top, right, bottom)
        frameLayout.setLayoutParams(layoutParams);

// Gradient background for the SeekBar container
        GradientDrawable frameBackground = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, // Gradient orientation
            new int[]{ 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        frameBackground.setStroke(3, Color.parseColor("#000000")); // Stroke with color
        frameBackground.setCornerRadius(10f); // Rounded corners
        frameLayout.setBackground(frameBackground);

        GradientDrawable lyts = new GradientDrawable();
        lyts.setColor(Color.parseColor("#00000000")); // Black background
        lyts.setCornerRadius(40f); // Corner radius of 15dp
        LinearLayout.LayoutParams ly = new LinearLayout.LayoutParams(dp(38), dp(26));
        ly.setMargins(5,5,5,5);
        // TextView para sa pangalan ng feature
        final Button textView = new Button(getContext);
        if (Preferences.loadPref) {
            textView.setText(Html.fromHtml(featName + " -> <font color='" + "'>" + loadedProg + " (SAVED VALUE)"));
        } else {
            textView.setText(Html.fromHtml(featName + " -> <font color='" + "'>" + ":"));
        }
        textView.setTextColor(TEXT_COLOR_2);
		SetFont(textView);
        textView.setBackground(lyts);
        textView.setTextSize(13);
        textView.setLayoutParams(ly);
        textView.setShadowLayer(7.0f, 0.0f, 0.0f, Color.BLACK);

        // Layout params para mailagay ang TextView sa kaliwa
        FrameLayout.LayoutParams textViewParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.START | Gravity.CENTER_VERTICAL
        );
        textViewParams.setMargins(25, 0, 10, 0);

        // SeekBar
        SeekBar seekBar = new SeekBar(getContext);
        seekBar.setMax(max);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            seekBar.setMin(min);
        }
        seekBar.setProgress((loadedProg == 0) ? min : loadedProg);

        // Alisin ang thumb (walang bilog)
        seekBar.setThumb(null);

        // Custom progress drawable
        ShapeDrawable progressDrawableLeft = new ShapeDrawable();
        progressDrawableLeft.getPaint().setColor(Color.GRAY);
        progressDrawableLeft.getPaint().setStyle(Paint.Style.FILL);

        ClipDrawable clipDrawableLeft = new ClipDrawable(progressDrawableLeft, Gravity.LEFT, ClipDrawable.HORIZONTAL);

        ShapeDrawable progressDrawableRight = new ShapeDrawable();
        progressDrawableRight.getPaint().setColor(SeekBarProgressColor);
        progressDrawableRight.getPaint().setStyle(Paint.Style.FILL);

        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{progressDrawableRight, clipDrawableLeft});
        seekBar.setProgressDrawable(layerDrawable);

        // Layout params para gawing mas malaki ang width ng SeekBar
        FrameLayout.LayoutParams seekBarParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.END | Gravity.CENTER_VERTICAL
        );
        seekBarParams.width = 1100;

        // TextView para sa progress value, ilalagay sa loob ng SeekBar
        final TextView progressTextView = new TextView(getContext);
        progressTextView.setTextColor(Color.BLACK);
        progressTextView.setTextSize(16);
        progressTextView.setTranslationX(100);
        progressTextView.setGravity(Gravity.CENTER);
        progressTextView.setText(String.valueOf(loadedProg)); // Initial progress display

        // Layout params para mailagay ang progressTextView sa loob ng SeekBar
        FrameLayout.LayoutParams progressTextParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER // Nasa gitna ng SeekBar
        );

        // Listener para i-update ang progressTextView habang gumagalaw ang SeekBar
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {}

                public void onStopTrackingTouch(SeekBar seekBar) {}

                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    progress = Math.max(progress, min); // Ensure progress doesn't go below min
                    seekBar.setProgress(progress);
                    Preferences.changeFeatureInt(featName, featNum, progress);
                    progressTextView.setText(String.valueOf(progress)); // Update progress display
                }
            });

        // Idagdag ang mga view sa FrameLayout
        frameLayout.addView(textView, textViewParams);          // TextView sa kaliwa
        frameLayout.addView(seekBar, seekBarParams);            // SeekBar sa kanan
        frameLayout.addView(progressTextView, progressTextParams); // ProgressTextView sa loob ng SeekBar

        return frameLayout;
    }

    private void SeekBar(LinearLayout linLayout, final int featNum, final String featName, final int min, int max) {
        int loadedProg = Preferences.loadPrefInt(featName, featNum);
        LinearLayout linearLayout = new LinearLayout(getContext);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);

        final TextView textView = new TextView(getContext);
        if(Preferences.loadPref) {
            textView.setText(Html.fromHtml(featName + " -> <font color='"+ "'>" +loadedProg+ ("SAVED VALUE")));
        }else{
            textView.setText(Html.fromHtml(featName + " -> <font color='" + "'>" + "[DEFAULT]"));
        }
        textView.setTextColor(TEXT_COLOR_2);
        textView.setShadowLayer(7.0f, 0.0f, 0.0f, Color.BLACK);

        SeekBar seekBar = new SeekBar(getContext);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setMax(max);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            seekBar.setMin(min); //setMin for Oreo and above
        seekBar.setProgress((loadedProg == 0) ? min : loadedProg);
        seekBar.getThumb().setColorFilter(SeekBarColor, PorterDuff.Mode.SRC_ATOP);
        seekBar.getProgressDrawable().setColorFilter(SeekBarProgressColor, PorterDuff.Mode.SRC_ATOP);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    //if progress is greater than minimum, don't go below. Else, set progress
                    if(min < i){
                        seekBar.setProgress(i < min ? min : i);
                        Preferences.changeFeatureInt(featName, featNum, i < min ? min : i);
                        textView.setText(Html.fromHtml(featName + " -> <font color='" +  "'>" + (i < min ? min : i) + "%"));
                    }
                    else{
                        seekBar.setProgress(i < min ? min : i);
                        Preferences.changeFeatureInt(featName, featNum, i < min ? min : i);
                        textView.setText(Html.fromHtml(featName + " -> <font color='" + "'>" + "[DEFAULT]"));
                    }

                    switch (featNum) {


                    }
                }
            });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);

        linLayout.addView(linearLayout);
    }
	private void Button(LinearLayout linLayout, final int featNum, final String featName) {
        final Button button = new Button(getContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setTextColor(TEXT_COLOR_2);
        button.setAllCaps(false); //Disable caps to support html
        button.setText(Html.fromHtml(featName));
        button.setBackgroundColor(BTN_COLOR);
        button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					switch (featNum) {

						case -6:
							scrollView.removeView(mSettings);
							scrollView.addView(mods);
							break;
						case -100:
							stopChecking = true;
							break;
					}
					Preferences.changeFeatureInt(featName, featNum, 0);
				}
			});

        linLayout.addView(button);
    }

    private void ButtonLink(LinearLayout linLayout, final String featName, final String url) {
        final Button button = new Button(getContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setAllCaps(false); //Disable caps to support html
        button.setTextColor(TEXT_COLOR_2);
        button.setText(Html.fromHtml(featName));
        button.setBackgroundColor(BTN_COLOR);
        button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.setData(Uri.parse(url));
					getContext.startActivity(intent);
				}
			});
        linLayout.addView(button);
    }

    private void ButtonOnOff(LinearLayout linLayout, final int featNum, String featName, boolean switchedOn) {
        final Button button = new Button(getContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setTextColor(TEXT_COLOR_2);
        button.setAllCaps(false); //Disable caps to support html

        final String finalfeatName = featName.replace("OnOff_", "");
        boolean isOn = Preferences.loadPrefBool(featName, featNum, switchedOn);
        if (isOn) {
            button.setText(Html.fromHtml(finalfeatName + ": ON"));
            isOn = false;
        } else {
            button.setText(Html.fromHtml(finalfeatName + ": OFF"));
            isOn = true;
        }
        final boolean finalIsOn = isOn;
        button.setOnClickListener(new View.OnClickListener() {
				boolean isOn = finalIsOn;

				public void onClick(View v) {
					Preferences.changeFeatureBool(finalfeatName, featNum, isOn);
					//Log.d(TAG, finalfeatName + " " + featNum + " " + isActive2);
					if (isOn) {
						button.setText(Html.fromHtml(finalfeatName + ": ON"));
						isOn = false;
					} else {
						button.setText(Html.fromHtml(finalfeatName + ": OFF"));
						isOn = true;
					}
				}
			});
        linLayout.addView(button);
    }

	private void Spinner(LinearLayout linLayout, final int featNum, final String featName, final String list) {
        Log.d(TAG, "spinner " + featNum + " " + featName + " " + list);
        final List<String> lists = new LinkedList<>(Arrays.asList(list.split(",")));

        // Create another LinearLayout as a workaround to use it as a background
        // to keep the down arrow symbol. No arrow symbol if setBackgroundColor set

        LinearLayout linearLayout2 = new LinearLayout(getContext);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams2.setMargins(15, 5, 15, 5);
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setLayoutParams(layoutParams2);
        linearLayout2.setBackground(createItemStrokeBackground());

        final Spinner spinner = new Spinner(getContext, Spinner.MODE_DROPDOWN);
        spinner.setLayoutParams(layoutParams2);


        // Create a custom adapter to add stroke and margins to dropdown items
        ArrayAdapter<String> aa = new ArrayAdapter<String>(getContext, android.R.layout.simple_spinner_dropdown_item, lists) {
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);

                // Apply stroke to each dropdown item
                view.setBackground(createItemStrokeBackground());

                // Apply margins to dropdown items
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 
                    LinearLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(15, 5, 5, 15); // Apply 10px margin horizontally and 5px vertically
                view.setLayoutParams(params);

                // Optionally change text color for selected items
                if (position == spinner.getSelectedItemPosition()) {
                    ((TextView) view).setTextColor(Color.parseColor("#FFBF00"));
                    ((TextView) view).setShadowLayer(12, 0, 0, Color.BLACK);
                } else {
                    ((TextView) view).setTextColor(Color.WHITE); // Normal text color
                    ((TextView) view).setShadowLayer(12, 0, 0, Color.BLACK);
                }

                return view;
            }
        };

        // Set the adapter for the spinner
        spinner.setAdapter(aa);
        spinner.setSelection(Preferences.loadPrefInt(featName, featNum));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    Preferences.changeFeatureInt(spinner.getSelectedItem().toString(), featNum, position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

        linearLayout2.addView(spinner);
        linLayout.addView(linearLayout2);
    }

    private GradientDrawable createItemStrokeBackground() {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(2, Color.parseColor("#000000")); // Stroke width and color
        return strokeBackground;
    }


    private void InputNum(final LinearLayout linLayout, final int featNum, final String featName, final int maxValue) {

		LinearLayout rowLayout = new LinearLayout(getContext);
		rowLayout.setOrientation(LinearLayout.HORIZONTAL);
		rowLayout.setPadding(10, 5, 10, 5);
		
		

		LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
		GradientDrawable inp = new GradientDrawable();
        inp.setColor(Color.parseColor("#badddddd")); // Black background
        inp.setCornerRadius(20f); // Corner radius of 15dp
        inp.setStroke(4,Color.parseColor("#077794"));
		// Para sa kanan (number display)
		LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
			dpToPx(80), // fixed width (80dp example)
			LinearLayout.LayoutParams.WRAP_CONTENT
		);

		inputParams.setMargins(10, 0, 0, 0);

		// Label (featName) sa kaliwa
		TextView label = new TextView(getContext);
		label.setLayoutParams(nameParams);
		SetFont(label);
		label.setText(featName);	
		label.setTextColor(TEXT_COLOR_2);
		label.setTextSize(14);

		// Displayed number sa kanan (hindi editable)
		final TextView numberDisplay = new TextView(getContext);
		numberDisplay.setLayoutParams(inputParams);
		numberDisplay.setBackgroundResource(android.R.drawable.edit_text);
		numberDisplay.setGravity(Gravity.CENTER);
		numberDisplay.setTextColor(TEXT_COLOR_2);
		GradientDrawable strokeDrawable = new GradientDrawable();
		strokeDrawable.setColor(Color.GRAY); // background color
		strokeDrawable.setStroke(dpToPx(1), Color.BLACK); // stroke width & color
		strokeDrawable.setCornerRadius(dpToPx(4));
		numberDisplay.setBackground(strokeDrawable);
		numberDisplay.setPadding(10, 5, 10, 5);

		int num = Preferences.loadPrefInt(featName, featNum);
		numberDisplay.setText(String.valueOf((num == 0) ? 1 : num));

		// Pag click sa number, open dialog
		numberDisplay.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					AlertDialog.Builder alertName = new AlertDialog.Builder(getContext);

					final EditText editText = new EditText(getContext);
					editText.setInputType(InputType.TYPE_CLASS_TEXT);
					editText.setBackgroundResource(android.R.drawable.edit_text);
					editText.setGravity(Gravity.CENTER);
					editText.setText(numberDisplay.getText().toString());

					if (maxValue != 0) {
						editText.setHint("Max value: " + maxValue);
					}

					// Focus + keyboard auto show
					editText.requestFocus();
					editText.postDelayed(new Runnable() {
							@Override
							public void run() {
								InputMethodManager imm = (InputMethodManager) getContext.getSystemService(Context.INPUT_METHOD_SERVICE);
								imm.showSoftInput(editText, InputMethodManager.SHOW_FORCED);
							}
						}, 200);

					alertName.setTitle("Input number");
					alertName.setView(editText);

					alertName.setPositiveButton("OK", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
								int newValue;
								try {
									newValue = Integer.parseInt(editText.getText().toString());
									if (maxValue != 0 && newValue > maxValue) {
										newValue = maxValue;
									}
								} catch (NumberFormatException ex) {
									newValue = (maxValue != 0) ? maxValue : 1;
								}

								// Apply sa display at save
								numberDisplay.setText(String.valueOf(newValue));
								Preferences.changeFeatureInt(featName, featNum, newValue);
							}
						});

					alertName.setNegativeButton("Cancel", null);

					AlertDialog dialog = alertName.create();
					if (overlayRequired) {
						dialog.getWindow().setType(Build.VERSION.SDK_INT >= 26 ? 2038 : 2002);
					}
					dialog.show();
					
				}
			});

		// Add sa row layout
		rowLayout.addView(label);
		rowLayout.addView(numberDisplay);
		linLayout.addView(rowLayout);
	}

    private void InputText(LinearLayout linLayout, final int featNum, final String featName) {
        final EditTextString edittextstring = new EditTextString();
        LinearLayout linearLayout = new LinearLayout(getContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(15, 10, 15, 10);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(10, 8, 8, 8);
        linearLayout.setLayoutParams(layoutParams);
     //   AddColor(linearLayout, Color.TRANSPARENT, 3, 0, 0, TEXT_COLOR_2, 30, 30, 0, 0, 30, 30, 0, 0);

        LayoutParams lp = new LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lp.weight = 1.0f;

        LinearLayout linearLayout2 = new LinearLayout(getContext);
        linearLayout2.setLayoutParams(lp);
        linearLayout2.setOrientation(1);
        linearLayout2.setGravity(Gravity.CENTER);

        TextView textView = new TextView(getContext);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setText(featName);
        textView.setTextSize(14.0F);
        textView.setGravity(3);
        textView.setSingleLine(true);
        textView.setPadding(5, 0, 0, 0);


        final TextView textView2 = new TextView(getContext);
        String string = Preferences.loadPrefString(featName, featNum);
        edittextstring.setString((string == "") ? "" : string);
        textView2.setText(Html.fromHtml("-> " + "<font color='" + "'>" + string + "</font>"));

        textView2.setTextColor(TEXT_COLOR_2);
        textView2.setTextSize(14.0F);
        textView2.setGravity(3);
        textView2.setPadding(5, 0, 0, 0);


        final Button button = new Button(getContext);
        button.setText("ENTER");
   //     AddColor(button, BTN_COLOR, dp(1), 0, 0, TEXT_COLOR_2, 30, 30, 0, 0, 30, 30, 0, 0);
        button.setTextColor(TEXT_COLOR_2);
        button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    final AlertDialog alert = new AlertDialog.Builder(getContext, 2).create();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        Objects.requireNonNull(alert.getWindow()).setType(Build.VERSION.SDK_INT >= 26 ? 2038 : 2002);
                    }
                    alert.setOnCancelListener(new DialogInterface.OnCancelListener() {
                            public void onCancel(DialogInterface dialog) {
                                InputMethodManager imm = (InputMethodManager) getContext.getSystemService(getContext.INPUT_METHOD_SERVICE);
                                imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                            }
                        });

                    //LinearLayout
                    LinearLayout linearLayout1 = new LinearLayout(getContext);
                    linearLayout1.setPadding(5, 5, 5, 5);
                    linearLayout1.setOrientation(LinearLayout.VERTICAL);

          //          AddColor(linearLayout1, BTN_COLOR, 3, 0, 0, TEXT_COLOR_2, 0, 0, 0, 0, 0, 0, 0, 0);
                    linearLayout1.setElevation(5.0F);

                    //TextView
                    final TextView titleText = new TextView(getContext);
                    titleText.setText(Html.fromHtml(new StringBuffer().append(new StringBuffer().append("<u>").append(featName).toString()).append("</u>").toString()));        
                    titleText.setGravity(17);
                    titleText.setTypeface(Typeface.DEFAULT_BOLD);
                    titleText.setTextColor(TEXT_COLOR_2);
                    titleText.setTextSize(22f);

                    //TextView
                    final TextView TextViewNote = new TextView(getContext);
                    TextViewNote.setGravity(17);
                    TextViewNote.setTextSize(14.0F);
                    TextViewNote.setText("Click \"Set Value\" button to apply changes || outside to cancel");
                    TextViewNote.setPadding(10, 15, 10, 10);
                    TextViewNote.setTextColor(TEXT_COLOR_2);

                    LayoutParams lpl = new LayoutParams(MATCH_PARENT, WRAP_CONTENT);
                    lpl.weight = 1;

                    //Edit text
                    final EditText edittext = new EditText(getContext);
                    edittext.setLayoutParams(lpl);
                    edittext.setMaxLines(1);
                    edittext.setHint("Write Text");
                    edittext.setWidth(convertDipToPixels(300));
                    edittext.setTextColor(TEXT_COLOR_2);
                    edittext.setText(edittextstring.getString());
                    edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View v, boolean hasFocus) {
                                InputMethodManager imm = (InputMethodManager) getContext.getSystemService(getContext.INPUT_METHOD_SERVICE);
                                if (hasFocus) {
                                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                                } else {
                                    imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                                }
                            }
                        });
                    edittext.requestFocus();

                    //Button
                    LayoutParams layoutParams = new LayoutParams(MATCH_PARENT, WRAP_CONTENT);
                    layoutParams.setMargins(20, 10, 20, 15);

                    Button btndialog = new Button(getContext);
                    btndialog.setLayoutParams(layoutParams);
          //          AddColor(btndialog, BTN_COLOR, 3, 0, 0, TEXT_COLOR_2, 30, 30, 0, 0, 30, 30, 0, 0);
                    btndialog.setTextColor(TEXT_COLOR_2);
                    btndialog.setPadding(15,10,15,10);
                    btndialog.setText("SET VALUE");
                    btndialog.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                String str = edittext.getText().toString();
                                edittextstring.setString(edittext.getText().toString());
                                textView2.setText(Html.fromHtml("-> "+ "<font color='" + "'>" + str + "</font>"));
                                alert.dismiss();
                                Preferences.changeFeatureString(featName, featNum, str);
                                edittext.setFocusable(false);
                            }
                        });
                    linearLayout1.addView(titleText);
                    linearLayout1.addView(TextViewNote);
                    linearLayout1.addView(edittext);
                    linearLayout1.addView(btndialog);
                    alert.setView(linearLayout1);
                    alert.show();
                }
            });

        linearLayout.addView(linearLayout2);
        linearLayout2.addView(textView);
        linearLayout2.addView(textView2);
        linearLayout.addView(button);

        linLayout.addView(linearLayout);
    }

    private View CheckBox(final int featNum, final String featName, boolean SwiOn) {
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling
        strokeBackground.setStroke(3, Color.parseColor("#000000")); // Stroke width and color

        // Create a horizontal LinearLayout to contain the TextView and icons
        LinearLayout layout = new LinearLayout(getContext);        
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackground(strokeBackground);
        layout.setPadding(10, 5, 10, 5); // Add padding if needed


        LinearLayout.LayoutParams Swittch = new LinearLayout.LayoutParams(MATCH_PARENT,WRAP_CONTENT);
        Swittch.setMargins(15,5,15,5);
        layout.setLayoutParams(Swittch);



        // Create the TextView for the feature name
        final TextView toggleTextView = new TextView(getContext);
        toggleTextView.setTextColor(Color.WHITE);
        toggleTextView.setText(featName); // Only the feature name
		SetFont(toggleTextView);
        toggleTextView.setTextSize(16); // Set text size
        toggleTextView.setGravity(Gravity.START); // Align to the left
        toggleTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1)); // Use weight for alignment

        // Create the TextView for the icon
        final TextView iconTextView = new TextView(getContext);
		iconTextView.setText(swiOn ? "🔄" : "🔄"); // Set the initial icon
        iconTextView.setTextSize(16); // Set text size
        iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED); // Set initial color
        iconTextView.setGravity(Gravity.END); // Align to the right

        // Add the TextViews to the LinearLayout
        layout.addView(toggleTextView);
        layout.addView(iconTextView);

        // Set up the onClickListener to toggle the state
        layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
					//backupFiles(1,"","","","");
                    // Toggle the swiOn state
                    swiOn = !swiOn;

                    // Update the icon and its color
                    iconTextView.setText(swiOn ? "🔄" : "🔄");
                    iconTextView.setTextColor(swiOn ? Color.GREEN : Color.RED);


					// Save the updated state in SharedPreferences or your custom storage
                    Preferences.changeFeatureBool(featName, featNum, swiOn);


                    // Perform any additional changes based on featNum
                    switch (featNum) {
                        case -1: // Save preferences
                            Preferences.with(toggleTextView.getContext()).writeBoolean(-1, swiOn);
                            if (!swiOn)
                                Preferences.with(toggleTextView.getContext()).clear(); // Clear preferences if switched off
                            break;
                        case -3:
                            Preferences.isExpanded = swiOn;




                            scrollView.setLayoutParams(swiOn ? scrlLLExpanded : scrlLL);


                            break;
                    }
                }
            });

        return layout; // Return the entire layout as a View
    }

    private View RadioButton(final int featNum, String featName, final String list) {
        // Credit: LoraZalora
        final List<String> lists = new LinkedList<>(Arrays.asList(list.split(",")));
        GradientDrawable strokeBackground = new GradientDrawable(
            GradientDrawable.Orientation.TR_BL, // Gradient orientation (Top to Bottom)
            new int[] { 
                Color.parseColor("#88141e30"), // Start color (light red)
                Color.parseColor("#88243b55")  // End color (light orange)
            }
        );
        strokeBackground.setStroke(3, Color.parseColor("#000000"));
        strokeBackground.setCornerRadius(10f); // Corner radius to match previous styling

// Create a GridLayout
        final GridLayout gridLayout = new GridLayout(getContext);
        gridLayout.setColumnCount(3); // Number of columns in the grid
        gridLayout.setPadding(5, 5, 5, 5); // Padding for the grid layout
        gridLayout.setBackground(strokeBackground);

// Set layout parameters with margins (no constants)
        GridLayout.LayoutParams gridParams = new GridLayout.LayoutParams();
        gridParams.width = -1; // MATCH_PARENT equivalent
        gridParams.height = -2; // WRAP_CONTENT equivalent
        gridParams.setMargins(15, 5, 15, 5); // Margins: left, top, right, bottom
        gridLayout.setLayoutParams(gridParams);

        // Create the single TextView that will be shared by all RadioButtons
        final TextView textView = new TextView(getContext);
        textView.setText(featName + ":");
        textView.setTextColor(TEXT_COLOR_2);

        // Add the TextView at the top of the GridLayout (spanning the entire row)
        GridLayout.LayoutParams textParams = new GridLayout.LayoutParams();
        textParams.columnSpec = GridLayout.spec(0, 3);  // Spans both columns
        textView.setLayoutParams(textParams);
        gridLayout.addView(textView);

        // Variable to keep track of the last selected option
        final View[] lastSelected = {null};

        for (int i = 0; i < lists.size(); i++) {
            // Create a TextView as a replacement for RadioButton
            final TextView optionView = new TextView(getContext);
            final String finalFeatName = featName, optionName = lists.get(i);

            // Set uniform size and properties for each option
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0; // Set width to 0 to use weight
            params.height = 80; // Uniform height for each option
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); // Set weight for uniform width
            params.setMargins(5, 5, 5, 5); // Add margins for spacing
            params.setGravity(Gravity.FILL); // Fill the space equally

            optionView.setLayoutParams(params);
            optionView.setSingleLine(true);
            optionView.setEllipsize(TextUtils.TruncateAt.END); // Add ellipsize for long text
            optionView.setText(optionName);
            optionView.setTextSize(15); // Adjust text size as needed
            optionView.setTextColor(Color.WHITE);
            optionView.setGravity(Gravity.CENTER); // Center the text

            // Create a default background
            final GradientDrawable defaultDrawable = new GradientDrawable();
            defaultDrawable.setShape(GradientDrawable.RECTANGLE);
            defaultDrawable.setStroke(4, Color.DKGRAY); // 4-pixel stroke width with dark gray color
            defaultDrawable.setColor(Color.TRANSPARENT); // Transparent background

            // Create a selected background
            final GradientDrawable selectedDrawable = new GradientDrawable();
            selectedDrawable.setShape(GradientDrawable.RECTANGLE);
            selectedDrawable.setStroke(4, Color.DKGRAY); // Same stroke
            selectedDrawable.setColor(Color.GRAY); // Green background for selected

            // Set the default background
            optionView.setBackground(defaultDrawable);

            // Add click listener
            optionView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Reset the background of the last selected option
                        if (lastSelected[0] != null) {
                            lastSelected[0].setBackground(defaultDrawable);
                        }

                        // Set the background of the current option
                        v.setBackground(selectedDrawable);

                        // Update the text and save the selection
                        textView.setText(Html.fromHtml(finalFeatName + ": <font color='" + NumberTxtColor + "'>" + optionName));
                        Preferences.changeFeatureInt(finalFeatName, featNum, gridLayout.indexOfChild(v));

                        // Update lastSelected
                        lastSelected[0] = v;
                    }
                });

            // Add the TextView to the GridLayout (each TextView will occupy one cell)
            gridLayout.addView(optionView);
        }

        // Set the previously selected item, if any, based on preferences
        int index = Preferences.loadPrefInt(featName, featNum);
        if (index > 0) {
            textView.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + lists.get(index - 1)));
            View selectedView = gridLayout.getChildAt(index + 1);  // +1 because TextView is the first child
            selectedView.setBackgroundColor(Color.GREEN); // Mark it as selected
            lastSelected[0] = selectedView;
        }

        return gridLayout;
    }
    final List<LinearLayout> allBoxContainers = new ArrayList<>();

    private void OpenSub(final LinearLayout linLayout, final String text, final boolean expanded, int maxPerRow) {
        // Track the current row container using a single-element array as a wrapper
        final LinearLayout[] currentRow = new LinearLayout[1];

        // Get the child count of the parent layout to handle rows dynamically
        int childCount = linLayout.getChildCount();

        // If no row exists or the last row is full, create a new row
        if (childCount == 0 || ((LinearLayout) linLayout.getChildAt(childCount - 1)).getChildCount() >= maxPerRow) {
            currentRow[0] = new LinearLayout(getContext);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            rowParams.setMargins(10, 10, 10, 10); // Add margin around the row
            currentRow[0].setLayoutParams(rowParams);
            currentRow[0].setOrientation(LinearLayout.HORIZONTAL);
            linLayout.addView(currentRow[0]);
        } else {
            // Get the last row
            currentRow[0] = (LinearLayout) linLayout.getChildAt(childCount - 1);
        }

        // Create a box container for the collapse section
        final LinearLayout boxContainer = new LinearLayout(getContext);       
        LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(
            0, // Set width to 0 to use weight
            LinearLayout.LayoutParams.MATCH_PARENT, // Ensure all boxes fill available height
            1.0f // Use weight to distribute space equally
        );
        boxParams.setMargins(1, 1, 1, 1); // Add margin around the box
        boxContainer.setLayoutParams(boxParams);
        boxContainer.setOrientation(LinearLayout.VERTICAL);
        boxContainer.setPadding(15, 15, 15, 15); // Add padding inside the box

        allBoxContainers.add(boxContainer);

        // Create a background for the box
        // Create a 3-color gradient for the box using hex color codes
        GradientDrawable gradientBackground = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, // Direction of the gradient
            new int[] {
                Color.parseColor("#347591"),  // Hex color for red/orange shade
                Color.parseColor("#979293"),  // Hex color for green
				// Hex color for blue
            }
        );
        gradientBackground.setCornerRadius(6); // Rounded corners
        gradientBackground.setStroke(2, Color.WHITE); // Box border color and thickness
        boxContainer.setBackground(gradientBackground);

        // Create a consistent height TextView for the title
        final TextView textView = new TextView(getContext);
        textView.setText(text); // No symbols, just the text itself
        textView.setTextSize(13);
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 10, 0, 10);
        textView.setSingleLine(false); // Allow text to wrap
        textView.setEllipsize(null); // Show full text


        final TextView backButton = new TextView(getContext);
        backButton.setText("Back");
        backButton.setTextColor(TEXT_COLOR_2); // Set text color
        backButton.setTextSize(16); // Set desired text size
        backButton.setTypeface(null, Typeface.BOLD); // Make it bold
        backButton.setPadding(10, 10, 10, 10); // Add some padding
        backButton.setVisibility(View.GONE); // Initially hidden
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        backParams.setMargins(3, 3, 3, 3); // Margins for proper positioning
        backButton.setLayoutParams(backParams);


        final LinearLayout collapseSub = new LinearLayout(getContext);
        LinearLayout.LayoutParams collapseParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, // Ensure it stretches across the full width
            LinearLayout.LayoutParams.WRAP_CONTENT // Wrap content vertically

        );
        // Create a 3-color gradient for the collapseSub section
        GradientDrawable collapseSubGradientBackground = new GradientDrawable(
            GradientDrawable.Orientation.BL_TR, // Direction of the gradient
            new int[] {
                Color.parseColor("#347591"),  // Tomato red (light red)
                Color.parseColor("#979293") // Golden yellow
                // Green yellow (yellow-green)
            }
        );
        collapseSubGradientBackground.setCornerRadius(6); // Rounded corners
        collapseSubGradientBackground.setStroke(2, Color.WHITE); // Box border color and thickness
        collapseSub.setBackground(collapseSubGradientBackground); // Set the background for collapseSub

        collapseParams.setMargins(0, 0, 0, 0); // Remove unnecessary margins
        collapseSub.setLayoutParams(collapseParams);
        collapseSub.setOrientation(LinearLayout.VERTICAL); // Ensure vertical alignment
        collapseSub.setVisibility(View.GONE); // Initially hidden
        collapseSub.setPadding(0, 0, 0, 0); // Remove unnecessary padding

        mCollapse = collapseSub;

        textView.setOnClickListener(new View.OnClickListener() {
                boolean isChecked;

                @Override
                public void onClick(View v) {
                    boolean z = !this.isChecked;
                    this.isChecked = z;

                    if (z) {
                        // Hide all other rows
                        for (LinearLayout box : allBoxContainers) {
                            if (box != boxContainer) {
                                box.setVisibility(View.GONE); // Hide other rows
                            }
                        }

                        // Show the current row and its collapseSub

                        backButton.setVisibility(View.VISIBLE);
                        boxContainer.setVisibility(View.VISIBLE);
                        collapseSub.setVisibility(View.VISIBLE);
                        textView.setText(text);
                    }  {
                        // Hide the current row's collapseSub


                    }
                }
            });

// Add click listener to Back button
        backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    collapseSub.setVisibility(View.GONE);
                    textView.setVisibility(View.VISIBLE);
                    backButton.setVisibility(View.GONE);
                    textView.setText("▽ " + text + " ▽");

                    // Optionally, show all rows again
                    for (LinearLayout box : allBoxContainers) {
                        box.setVisibility(View.VISIBLE);
                    }
                }
            });
// Add buttons to the container

        boxContainer.addView(textView);
        boxContainer.addView(collapseSub);
        boxContainer.addView(backButton); // Add the Back button at the bottom
        currentRow[0].addView(boxContainer);
	}


    private void Collapse(LinearLayout linLayout, final String text, final boolean expanded) {
        LinearLayout.LayoutParams layoutParamsLL = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParamsLL.setMargins(0, 5, 0, 0);

        LinearLayout collapse = new LinearLayout(getContext);
        collapse.setLayoutParams(layoutParamsLL);
        collapse.setVerticalGravity(16);
        collapse.setOrientation(LinearLayout.VERTICAL);

        final LinearLayout collapseSub = new LinearLayout(getContext);
        collapseSub.setVerticalGravity(16);
        collapseSub.setPadding(0, 5, 0, 5);
        collapseSub.setOrientation(LinearLayout.VERTICAL);
        collapseSub.setBackgroundColor(Color.parseColor("#00222D38"));
        collapseSub.setVisibility(View.GONE);
        mCollapse = collapseSub;

        final TextView textView = new TextView(getContext);
        textView.setBackgroundColor(CategoryBG);
        textView.setText("▽ " + text + " ▽");
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.BLACK);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 20, 0, 20);

        if (expanded) {
            collapseSub.setVisibility(View.VISIBLE);
            textView.setText("△ " + text + " △");
        }

        textView.setOnClickListener(new View.OnClickListener() {
                boolean isChecked = expanded;

                @Override
                public void onClick(View v) {

                    boolean z = !isChecked;
                    isChecked = z;
                    if (z) {
                        collapseSub.setVisibility(View.VISIBLE);
                        textView.setText("△ " + text + " △");
                        return;
                    }
                    collapseSub.setVisibility(View.GONE);
                    textView.setText("▽ " + text + " ▽");
                }
            });
        collapse.addView(textView);
        collapse.addView(collapseSub);
        linLayout.addView(collapse);
    }

    private void Category(LinearLayout linLayout, String text) {

        LinearLayout lay = new LinearLayout(getContext);
        lay.setOrientation(LinearLayout.HORIZONTAL);

        TextView textView = new TextView(getContext);
        textView.setBackgroundColor(Color.TRANSPARENT);
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.LEFT);
        textView.setTextSize(25);
        textView.setTranslationX(15);
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);
        LinearLayout.LayoutParams textViewParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textViewParams.setMargins(16, 8, 16, 8); // Set left, top, right, bottom margins
        textView.setLayoutParams(textViewParams);

        lay.addView(textView);
        linLayout.addView(lay);
        View separator = new View(getContext);
        LinearLayout.LayoutParams separatorParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 5); // 2px height for the line
        separatorParams.setMargins(16, 8, 16, 8);  // Set margin for the separator (optional)
        separator.setLayoutParams(separatorParams);
        separator.setBackgroundColor(Color.parseColor("#347591")); // Set the line color

        // Add the separator below the TextView
        linLayout.addView(separator);
    }

    private void Category2(LinearLayout linLayout, String text) {
        // Create and style the TextView
        TextView textView = new TextView(getContext);
        textView.setBackgroundColor(Color.DKGRAY);
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);

        // Set margin for the TextView
        LinearLayout.LayoutParams textViewParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textViewParams.setMargins(16, 8, 16, 8);  // Set left, top, right, bottom margins (in pixels)
        textView.setLayoutParams(textViewParams);

        // Add the TextView to the layout
        linLayout.addView(textView);

        // Create a separator (a simple line)
        View separator = new View(getContext);
        LinearLayout.LayoutParams separatorParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 5); // 2px height for the line
        separatorParams.setMargins(16, 8, 16, 8);  // Set margin for the separator (optional)
        separator.setLayoutParams(separatorParams);
        separator.setBackgroundColor(Color.parseColor("#347591")); // Set the line color

        // Add the separator below the TextView
        linLayout.addView(separator);
    }


    private void TextView(LinearLayout linLayout, String text) {
        TextView textView = new TextView(getContext);
        textView.setText(Html.fromHtml(text));
        textView.setTextColor(TEXT_COLOR_2);
        textView.setPadding(10, 5, 10, 5);
        linLayout.addView(textView);
    }

    private void WebTextView(LinearLayout linLayout, String text) {
        WebView wView = new WebView(getContext);
        wView.loadData(text, "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setPadding(0, 5, 0, 5);
        wView.getSettings().setAppCacheEnabled(false);
        linLayout.addView(wView);
    }
	
	private int dpToPx(int dp) {
		float density = getContext.getResources().getDisplayMetrics().density;
		return Math.round(dp * density);
	}

    private class EditTextString {
        private String text;

        public void setString(String s) {
            text = s;
        }

        public String getString() {
            return text;
        }
    }

    private class EditTextNum {
        private int val;

        public void setNum(int i) {
            val = i;
        }

        public int getNum() {
            return val;
        }
    }

    private boolean isViewCollapsed() {
        return rootFrame == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getContext.getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) i, getContext.getResources().getDisplayMetrics());
    }

    public void setVisibility(int view) {
        if (rootFrame != null) {
            rootFrame.setVisibility(view);
        }
    }

    public void onDestroy() {
        if (rootFrame != null) {
            mWindowManager.removeView(rootFrame);
        }
    }
	
	private static void unzipAndFlatten(File zipFile, File targetDir) throws Exception {
        ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
        ZipEntry ze;
        byte[] buffer = new byte[1024];
        while ((ze = zis.getNextEntry()) != null) {
            String name = ze.getName();
            int firstSlash = name.indexOf('/');
            if (firstSlash != -1) {
                name = name.substring(firstSlash + 1);
            }
            if (name.isEmpty()) continue;

            File newFile = new File(targetDir, name);
            if (ze.isDirectory()) {
                newFile.mkdirs();
            } else {
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
        }
        zis.closeEntry();
        zis.close();
    }

	private static void copyDir(File src, File dst) throws Exception {
        if (!dst.exists()) dst.mkdirs();
        String[] files = src.list();
        if (files == null) return;
        for (String fileName : files) {
            File srcFile = new File(src, fileName);
            File dstFile = new File(dst, fileName);
            if (srcFile.isDirectory()) {
                copyDir(srcFile, dstFile);
            } else {
                InputStream in = new FileInputStream(srcFile);
                OutputStream out = new FileOutputStream(dstFile);
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
            }
        }
    }
}

