package com.android.support;

public interface Animation1 {
    void onAnimationEnd(Animation3 hTextView);
}

