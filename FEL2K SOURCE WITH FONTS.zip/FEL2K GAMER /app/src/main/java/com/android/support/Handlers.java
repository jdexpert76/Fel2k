package com.android.support;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Handlers {

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    private static View floatingView;
    private static WindowManager windowManager;


    public static void showFloatingIcon(final Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            Toast.makeText(context, "Please allow Draw Over Apps permission", Toast.LENGTH_LONG).show();
            context.startActivity(new android.content.Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                             Uri.parse("package:" + context.getPackageName())));
            return;
        }

        if (floatingView != null) return; 

        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        TextView icon = new TextView(context);
        icon.setText("⚙️"); 
        icon.setTextSize(20); 
        icon.setPadding(20, 20, 20, 20);
        icon.setBackgroundColor(0x00000000);

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION, 
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.BOTTOM | Gravity.START; 
        params.x = 20; 
        params.y = 20; 

        icon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showOptionsDialog(context);
                }
            });

        floatingView = icon;
        windowManager.addView(floatingView, params);
    }


    public static void hideFloatingIcon() {
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
            floatingView = null;
        }
    }


    public static void showOptionsDialog(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Select Action");
        builder.setItems(new CharSequence[]{"Get New Files"}, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which) {
                             case 0:
                            downloadAndUnzip(context);
                            break;
                    }
                }
            });
        builder.show();
    }


    public static void backupFiles(final Context context) {
        executor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        File sourceDir = context.getFilesDir();
                        File destDir = new File(context.getExternalFilesDir(null), "Fel2KFiles");
                        copyDir(sourceDir, destDir);
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(context, "Backup Completed", Toast.LENGTH_SHORT).show();
                                }
                            });
                    } catch (final Exception e) {
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(context, "Backup Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            });
                    }
                }
            });
    }


    public static void restoreFiles(final Context context) {
        executor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        File sourceDir = new File(context.getExternalFilesDir(null), "Fel2KFiles");
                        File destDir = context.getFilesDir();
                        copyDir(sourceDir, destDir);
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(context, "Restore Completed", Toast.LENGTH_SHORT).show();
                                }
                            });
                    } catch (final Exception e) {
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(context, "Restore Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            });
                    }
                }
            });
    }


    public static void downloadAndUnzip(final Context context) {
        mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    showDownloadDialog(context);
                }
            });
    }

    private static void showDownloadDialog(final Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final ProgressBar progressBar = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        layout.addView(progressBar);

        final TextView percentageText = new TextView(context);
        percentageText.setText("0%");
        percentageText.setTextSize(16);
        percentageText.setGravity(Gravity.CENTER);
        layout.addView(percentageText);

        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Downloading Rosters...");
        builder.setView(layout);
        builder.setCancelable(false);
        builder.setNegativeButton("Cancel", null);

        final AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    executor.shutdownNow();
                    dialog.dismiss();
                    Toast.makeText(context, "Download Cancelled", Toast.LENGTH_SHORT).show();
                }
            });

        executor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL githubUrl = new URL((new Object() {
                                                    int t;
                                                    public String toString() {
                                                        byte[] buf = new byte[63];
                                                        t = 120679683;
                                                        buf[0] = (byte) (t >>> 5);
                                                        t = 1453745384;
                                                        buf[1] = (byte) (t >>> 1);
                                                        t = 1081368180;
                                                        buf[2] = (byte) (t >>> 16);
                                                        t = -904614397;
                                                        buf[3] = (byte) (t >>> 5);
                                                        t = 1557977047;
                                                        buf[4] = (byte) (t >>> 22);
                                                        t = -1659384640;
                                                        buf[5] = (byte) (t >>> 23);
                                                        t = 927876585;
                                                        buf[6] = (byte) (t >>> 5);
                                                        t = 1405863260;
                                                        buf[7] = (byte) (t >>> 14);
                                                        t = 152255618;
                                                        buf[8] = (byte) (t >>> 11);
                                                        t = -1152550087;
                                                        buf[9] = (byte) (t >>> 19);
                                                        t = 1058878706;
                                                        buf[10] = (byte) (t >>> 14);
                                                        t = 413185117;
                                                        buf[11] = (byte) (t >>> 7);
                                                        t = 1215646893;
                                                        buf[12] = (byte) (t >>> 16);
                                                        t = 428534250;
                                                        buf[13] = (byte) (t >>> 18);
                                                        t = 1710251298;
                                                        buf[14] = (byte) (t >>> 9);
                                                        t = -1728312468;
                                                        buf[15] = (byte) (t >>> 22);
                                                        t = -231154733;
                                                        buf[16] = (byte) (t >>> 6);
                                                        t = -1297887818;
                                                        buf[17] = (byte) (t >>> 2);
                                                        t = 791017281;
                                                        buf[18] = (byte) (t >>> 24);
                                                        t = -422467105;
                                                        buf[19] = (byte) (t >>> 10);
                                                        t = -1000032922;
                                                        buf[20] = (byte) (t >>> 16);
                                                        t = -1176087423;
                                                        buf[21] = (byte) (t >>> 12);
                                                        t = 504254055;
                                                        buf[22] = (byte) (t >>> 22);
                                                        t = -400384990;
                                                        buf[23] = (byte) (t >>> 6);
                                                        t = 1451910601;
                                                        buf[24] = (byte) (t >>> 8);
                                                        t = -1453886006;
                                                        buf[25] = (byte) (t >>> 2);
                                                        t = 976341604;
                                                        buf[26] = (byte) (t >>> 23);
                                                        t = -1984374539;
                                                        buf[27] = (byte) (t >>> 19);
                                                        t = -1492278697;
                                                        buf[28] = (byte) (t >>> 14);
                                                        t = 2013180094;
                                                        buf[29] = (byte) (t >>> 2);
                                                        t = 1879338556;
                                                        buf[30] = (byte) (t >>> 12);
                                                        t = 717943276;
                                                        buf[31] = (byte) (t >>> 17);
                                                        t = 391174299;
                                                        buf[32] = (byte) (t >>> 9);
                                                        t = 1762996859;
                                                        buf[33] = (byte) (t >>> 8);
                                                        t = 1455365795;
                                                        buf[34] = (byte) (t >>> 20);
                                                        t = 147575917;
                                                        buf[35] = (byte) (t >>> 14);
                                                        t = -1328127218;
                                                        buf[36] = (byte) (t >>> 3);
                                                        t = -281454934;
                                                        buf[37] = (byte) (t >>> 15);
                                                        t = -913717707;
                                                        buf[38] = (byte) (t >>> 4);
                                                        t = -363968891;
                                                        buf[39] = (byte) (t >>> 4);
                                                        t = 1773121725;
                                                        buf[40] = (byte) (t >>> 24);
                                                        t = 1859597037;
                                                        buf[41] = (byte) (t >>> 1);
                                                        t = 1710030721;
                                                        buf[42] = (byte) (t >>> 24);
                                                        t = 1343731668;
                                                        buf[43] = (byte) (t >>> 15);
                                                        t = -1992731016;
                                                        buf[44] = (byte) (t >>> 15);
                                                        t = -876767306;
                                                        buf[45] = (byte) (t >>> 10);
                                                        t = 1504204904;
                                                        buf[46] = (byte) (t >>> 22);
                                                        t = -147420244;
                                                        buf[47] = (byte) (t >>> 20);
                                                        t = 114071460;
                                                        buf[48] = (byte) (t >>> 7);
                                                        t = -848762247;
                                                        buf[49] = (byte) (t >>> 16);
                                                        t = 2121897923;
                                                        buf[50] = (byte) (t >>> 10);
                                                        t = 289041166;
                                                        buf[51] = (byte) (t >>> 3);
                                                        t = -1853277406;
                                                        buf[52] = (byte) (t >>> 3);
                                                        t = 1314998562;
                                                        buf[53] = (byte) (t >>> 21);
                                                        t = 1354826491;
                                                        buf[54] = (byte) (t >>> 4);
                                                        t = 1099832189;
                                                        buf[55] = (byte) (t >>> 6);
                                                        t = -1737843962;
                                                        buf[56] = (byte) (t >>> 22);
                                                        t = 189586837;
                                                        buf[57] = (byte) (t >>> 19);
                                                        t = -1149928081;
                                                        buf[58] = (byte) (t >>> 19);
                                                        t = -1362192544;
                                                        buf[59] = (byte) (t >>> 7);
                                                        t = -228999880;
                                                        buf[60] = (byte) (t >>> 7);
                                                        t = -292939188;
                                                        buf[61] = (byte) (t >>> 6);
                                                        t = 194006545;
                                                        buf[62] = (byte) (t >>> 5);
                                                        return new String(buf);
                                                    }
                                                }.toString()));
                        HttpURLConnection conn = (HttpURLConnection) githubUrl.openConnection();
                        conn.connect();

                        final int fileLength = conn.getContentLength();
                        final boolean hasLength = fileLength > 0;

                        InputStream input = new BufferedInputStream(conn.getInputStream());
                        File tempZip = new File(context.getFilesDir(), "temp_download.zip");
                        OutputStream output = new FileOutputStream(tempZip);

                        byte[] data = new byte[8192];
                        long total = 0;
                        int count;
                        while ((count = input.read(data)) != -1 && !executor.isShutdown()) {
                            total += count;
                            output.write(data, 0, count);

                            final int progress = hasLength ? (int) (total * 100 / fileLength) : Math.min(99, (int) (total / 50000));
                            mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBar.setProgress(progress);
                                        percentageText.setText(progress + "%");
                                    }
                                });
                        }

                        output.flush();
                        output.close();
                        input.close();

                        if (!executor.isShutdown()) {
                            unzipAndFlatten(tempZip, context.getFilesDir());
                            tempZip.delete();
                            mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBar.setProgress(100);
                                        percentageText.setText("100%");
                                        dialog.dismiss();
                                        Toast.makeText(context, "Download and Unzip Completed", Toast.LENGTH_SHORT).show();
                                    }
                                });
                        }

                    } catch (final Exception e) {
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    dialog.dismiss();
                                    Toast.makeText(context, "Download Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            });
                    }
                }
            });
    }


    private static void copyDir(File src, File dst) throws Exception {
        if (!dst.exists()) dst.mkdirs();
        String[] files = src.list();
        if (files == null) return;
        for (String fileName : files) {
            File srcFile = new File(src, fileName);
            File dstFile = new File(dst, fileName);
            if (srcFile.isDirectory()) {
                copyDir(srcFile, dstFile);
            } else {
                InputStream in = new FileInputStream(srcFile);
                OutputStream out = new FileOutputStream(dstFile);
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
            }
        }
    }

    private static void unzipAndFlatten(File zipFile, File targetDir) throws Exception {
        ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
        ZipEntry ze;
        byte[] buffer = new byte[1024];
        while ((ze = zis.getNextEntry()) != null) {
            String name = ze.getName();
            int firstSlash = name.indexOf('/');
            if (firstSlash != -1) {
                name = name.substring(firstSlash + 1);
            }
            if (name.isEmpty()) continue;

            File newFile = new File(targetDir, name);
            if (ze.isDirectory()) {
                newFile.mkdirs();
            } else {
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
        }
        zis.closeEntry();
        zis.close();
    }
}

