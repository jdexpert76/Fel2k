package com.android.animation;

import com.android.support.Menu;

public interface AnimationSetupCallback {
    public void onSetupAnimation(TitanicTextView titanicTextView);
    public void onSetupAnimation(TitanicButton Button);
	public void onSetupAnimation(TitanicSwitch Switch);
}
