package com.android.support;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends Activity {

    // Only if you have changed MainActivity to yours and you want to call the game's activity
    public String GameActivity = "com.unity3d.player.UnityPlayerActivity";
    public boolean hasLaunched = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Detect GameGuardian
        if (isGameGuardianInstalled(this) || isGameGuardianRunning()) {
            // Display a fake error message
            Toast.makeText(this, "Application error: Please contact support", Toast.LENGTH_SHORT).show();

            // Terminate the app
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        }

        // Launch the game's main activity
        if (!hasLaunched) {
            try {
                hasLaunched = true;
                startActivity(new Intent(MainActivity.this, Class.forName(GameActivity)));
                Main.Start(this); // Call your mod menu initialization method
                return;
            } catch (ClassNotFoundException e) {
                Log.e("Mod_menu", "Error. Game's main activity does not exist");
            }
        }

        // Launch mod menu (if needed outside the game's activity)
        Main.Start(this);
        
        
        
    }

    // Check if GameGuardian is installed
    private boolean isGameGuardianInstalled(Context context) {
        try {
            // List of common GameGuardian package names
            String[] ggPackageNames = {
                "com.gameguardian",
                "com.twaxytfgovae",
                "com.gguardian" // Add more variations if needed
            };

            for (String packageName : ggPackageNames) {
                context.getPackageManager().getPackageInfo(packageName, 0);
                return true; // GameGuardian detected
            }
        } catch (PackageManager.NameNotFoundException e) {
            // Package not found, GameGuardian is not installed
        }
        return false;
    }

    // Check if GameGuardian is running as a process
    private boolean isGameGuardianRunning() {
        try {
            // Execute the "ps" command to list running processes
            Process process = Runtime.getRuntime().exec("ps");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            // Read each line of the process list
            while ((line = reader.readLine()) != null) {
                // Look for GameGuardian-related processes
                if (line.contains("gg") || line.contains("gameguardian")) {
                    return true; // GameGuardian is running
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}

