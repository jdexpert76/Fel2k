
#define targetLibName OBFUSCATE("libnba2k20_clean_opt.so")
#define targetRange OBFUSCATE("libc_malloc")
//#define targetRanges OBFUSCATE("libc_malloc")

std::vector<uintptr_t> patchedAddresses;
//pionters
  
 float value = 1.0f;


std::string floatToReverseHex(float value) {
    uint8_t bytes[4];
    memcpy(bytes, &value, sizeof(float)); 
    char hex[9];
    snprintf(hex, sizeof(hex), "%02X%02X%02X%02X", bytes[0], bytes[1], bytes[2], bytes[3]);
    return std::string(hex);
}

std::string DwordReverseHex(uint32_t value) {
    uint8_t bytes[4];
    memcpy(bytes, &value, sizeof(uint32_t));
    char hex[9]; 
    snprintf(hex, sizeof(hex), "%02X%02X%02X%02X", bytes[0], bytes[1], bytes[2], bytes[3]); // Reverse the byte order
    return std::string(hex);
}

std::string ByteReverseHex(uint8_t value) {
    char hex[3];
    snprintf(hex, sizeof(hex), "%02X", value); 
    return std::string(hex);
}


bool writeMemory(void *address, const void *data, size_t size) {
    uintptr_t pageStart = reinterpret_cast<uintptr_t>(address) & ~0xFFF; // Align to page size
    if (mprotect(reinterpret_cast<void *>(pageStart), 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        LOGE("mprotect failed: %d", errno);
        return false;
    }
    memcpy(address, data, size);
    return true;
}

void patchBssOffset(uintptr_t absoluteAddress, const std::string &hexBytes, bool enable) {
    if (absoluteAddress == 0) {
        LOGE("Invalid address: %p", absoluteAddress);
        return;
    }


    std::vector<uint8_t> bytes;
    for (size_t i = 0; i < hexBytes.length(); i += 2) {
        bytes.push_back(static_cast<uint8_t>(std::stoi(hexBytes.substr(i, 2), nullptr, 16)));
    }


    if (bytes.size() != 4) {
        LOGE("Expected 4 bytes, but got %zu bytes", bytes.size());
        return;
    }

    if (enable) {
        if (writeMemory(reinterpret_cast<void *>(absoluteAddress), bytes.data(), bytes.size())) {
            patchedAddresses.push_back(absoluteAddress);
            LOGI("Successfully patched address: %p with bytes: %s", absoluteAddress, hexBytes.c_str());
        } else {
            LOGE("Failed to patch address: %p", absoluteAddress);
        }
    } else {
        if (writeMemory(reinterpret_cast<void *>(absoluteAddress), bytes.data(), bytes.size())) {
            patchedAddresses.erase(std::remove(patchedAddresses.begin(), patchedAddresses.end(), absoluteAddress), patchedAddresses.end());
            LOGI("Successfully restored address: %p with bytes: %s", absoluteAddress, hexBytes.c_str());
        } else {
            LOGE("Failed to restore address: %p", absoluteAddress);
        }
    }
}



//copy runs the street shirts
//put2E2B100
//hdskin relaistix
uintptr_t rls = getAbsoluteAddress(targetRange, string2Offset("0x2EC5B44"));
uintptr_t rls2 = getAbsoluteAddress(targetRange, string2Offset("0x2EC5B46"));
uintptr_t rls3 = getAbsoluteAddress(targetRange, string2Offset("0x2EC5B48"));
uintptr_t rls4 = getAbsoluteAddress(targetRange, string2Offset("0x2EC5B4A"));

uintptr_t rls5 = getAbsoluteAddress(targetLibName, string2Offset("0x2104A38"));
uintptr_t rls6 = getAbsoluteAddress(targetLibName, string2Offset("0x20361B4"));
uintptr_t rls7 = getAbsoluteAddress(targetLibName, string2Offset("0x20361B8"));
uintptr_t rls8 = getAbsoluteAddress(targetLibName, string2Offset("0x20361BC"));
uintptr_t rls9 = getAbsoluteAddress(targetLibName, string2Offset("0x20361C0"));
uintptr_t rls10 = getAbsoluteAddress(targetLibName, string2Offset("0x20361C4"));
uintptr_t rls11 = getAbsoluteAddress(targetLibName, string2Offset("0x20361C8"));
uintptr_t rls12 = getAbsoluteAddress(targetLibName, string2Offset("0x28E6FC0"));
uintptr_t rls13 = getAbsoluteAddress(targetLibName, string2Offset("0x28E6FC4"));
uintptr_t rls14 = getAbsoluteAddress(targetLibName, string2Offset("0x28E6FC8"));

uintptr_t rl = getAbsoluteAddress(targetRange, string2Offset("0x5ea5898"));
uintptr_t rl2 = getAbsoluteAddress(targetRange, string2Offset("0x5ea64b8"));
uintptr_t rl3 = getAbsoluteAddress(targetRange, string2Offset("0x60279c0"));
uintptr_t rl4 = getAbsoluteAddress(targetRange, string2Offset("0x6034988"));
uintptr_t rl5 = getAbsoluteAddress(targetRange, string2Offset("0x603de10"));
uintptr_t rl6 = getAbsoluteAddress(targetRange, string2Offset("0x60512f0"));










uintptr_t chemistry = getAbsoluteAddress(targetRange, string2Offset("0x2fce503"));


uintptr_t nvs1 = getAbsoluteAddress(targetRange, string2Offset("0x2fcd260"));

uintptr_t foul = getAbsoluteAddress(targetRange, string2Offset("0x2fcd390"));
uintptr_t foul2 = getAbsoluteAddress(targetRange, string2Offset("0x2fcd398"));
//sweat

uintptr_t swt = getAbsoluteAddress(targetRange, string2Offset("0x5ea5c1c"));
uintptr_t swt2 = getAbsoluteAddress(targetRange, string2Offset("0x5ea683c"));
uintptr_t swt3 = getAbsoluteAddress(targetRange, string2Offset("0x6027d44"));
uintptr_t swt4 = getAbsoluteAddress(targetRange, string2Offset("0x6034d0c"));
uintptr_t swt5 = getAbsoluteAddress(targetRange, string2Offset("0x603e194"));
uintptr_t swt6 = getAbsoluteAddress(targetRange, string2Offset("0x6051674"));
//uintptr_t hdshoe = getAbsoluteAddress(targetRange, string2Offset("0x5fc4000"));
//nevermiss*/
 uintptr_t nv1 = getAbsoluteAddress(targetLibName, string2Offset("0x387B528")); // Example offset   
 uintptr_t nv2 = getAbsoluteAddress(targetLibName, string2Offset("0x387B52C")); // Example offset       
 uintptr_t nv3 = getAbsoluteAddress(targetLibName, string2Offset("0x387B530")); // Example offset       
 uintptr_t nv4 = getAbsoluteAddress(targetLibName, string2Offset("0x387B534")); // Example offset
 uintptr_t nv5 = getAbsoluteAddress(targetLibName, string2Offset("0x387B538")); // Example offset
 uintptr_t nv6 = getAbsoluteAddress(targetLibName, string2Offset("0x387B53C")); // Example offset
 uintptr_t nv7 = getAbsoluteAddress(targetLibName, string2Offset("0x387B548")); // Example offset
 uintptr_t nv8 = getAbsoluteAddress(targetLibName, string2Offset("0x387B54C")); // Example offset   
 uintptr_t nv9 = getAbsoluteAddress(targetLibName, string2Offset("0x387B550")); // Example offset    
 uintptr_t nv10 = getAbsoluteAddress(targetLibName, string2Offset("0x387B554")); // Example offset    
 uintptr_t nv11 = getAbsoluteAddress(targetLibName, string2Offset("0x387B558")); // Example offset
 
uintptr_t vc1= getAbsoluteAddress(targetLibName, string2Offset("0x2B20320"));
uintptr_t vc2= getAbsoluteAddress(targetLibName, string2Offset("0x2B20324"));
uintptr_t vc3= getAbsoluteAddress(targetLibName, string2Offset("0x2B20328"));
uintptr_t vc4= getAbsoluteAddress(targetLibName, string2Offset("0x2B2032C"));



uintptr_t year= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B19C"));
uintptr_t cont= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B228"));
uintptr_t cont2= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B22C"));
uintptr_t cont3= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B230"));
uintptr_t cont4= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B234"));
uintptr_t cont5= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B238"));
uintptr_t cont6= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B23C"));

uintptr_t height= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B100"));
uintptr_t weight = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B104"));

uintptr_t mc1 = getAbsoluteAddress(targetLibName, string2Offset("0x3844400")); // Example offset
uintptr_t mc2 = getAbsoluteAddress(targetLibName, string2Offset("0x3844430")); // Example offset
uintptr_t mc3 = getAbsoluteAddress(targetLibName, string2Offset("0x3844B18")); // Example offset
uintptr_t mc4 = getAbsoluteAddress(targetLibName, string2Offset("0x386D980"));


uintptr_t brokenrim = getAbsoluteAddress(targetLibName, string2Offset("0x38E826C")); // Example offset

uintptr_t firstname = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B0FC")); // Example offset   
uintptr_t lastname = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B0F8")); // Example offset   

uintptr_t playerattire = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B218")); // Example offset   
uintptr_t clothes = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B268")); // Example offset   
uintptr_t playerID = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B26C")); // Example offset   
//copy
uintptr_t playerattire2 = getAbsoluteAddress(targetLibName, string2Offset("0x3B273A8")); // Example offset   
uintptr_t clothes2 = getAbsoluteAddress(targetLibName, string2Offset("0x3B273F8")); // Example offset   
uintptr_t playerID2 = getAbsoluteAddress(targetLibName, string2Offset("0x3B273FC")); // Example offset   

//speciality
uintptr_t opt1= getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC98"));
uintptr_t opt2= getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC9C"));
uintptr_t historic= getAbsoluteAddress(targetLibName, string2Offset("0x2E6DCA8"));

uintptr_t shoot= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B143"));
uintptr_t dunk= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B144"));

uintptr_t skintone= getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1C9"));
//Historic
uintptr_t option1= getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC98"));
uintptr_t option2= getAbsoluteAddress(targetLibName, string2Offset("0x2E6DC9C"));
uintptr_t hidden = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DCA8"));

//hd courts
uintptr_t sixers = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t sixers2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t sixers3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t bucks = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t bucks2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t bucks3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t bulls = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t bulls2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t bulls3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t cavs = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t cavs2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t cavs3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t celtics = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t celtics2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t celtics3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t clippers = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t clippers2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t clippers3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t memphpis = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t memphis2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t memphis3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t hawks = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t hawks2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t hawks3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t heat = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t heat2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t heat3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t hornets = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t hornets2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t hornets3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t jazz = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t jazz2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t jazz3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t kings = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t kings2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t kings3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t knicks = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t knicks2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t knicks3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t lakers = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t lakers2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t lakers3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t magic = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t magic2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t magic3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t mavs = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t mavs2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t mavs3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t nets = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t nets2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t nets3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t den = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t den2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t den3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t ind = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t ind2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t ind3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t nop = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t nop2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t nop3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t det = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t det2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t det3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t tor = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t tor2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t tor3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t hou = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t hou2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t hou3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t sa = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t sa2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t sa3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t suns = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t suns2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t suns3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t okc= getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t okc2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t okc3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t wolves = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t wolves2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t wolves3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t blazers = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t blazers2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t blazers3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t gs = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t gs2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t gs3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t was = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t was2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t was3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));

uintptr_t r = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
uintptr_t g = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
uintptr_t b = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));
//copy runs the street shirts
//put
//speciality
uintptr_t speciality = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B29E")); // Example offset 
//dunkpackages

uintptr_t position= getAbsoluteAddress(targetLibName, string2Offset("0X2E2B141"));

uintptr_t dunkpackages = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B200")); // Example offset   
uintptr_t dunkpackages2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B201")); // Example offset   
uintptr_t dunkpackages3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B202")); // Example offset   
uintptr_t dunkpackages4 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B203")); // Example offset   
uintptr_t dunkpackages5 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B204")); // Example offset   
uintptr_t dunkpackages6 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B205")); // Example offset   
uintptr_t dunkpackages7 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B206")); // Example offset   
uintptr_t dunkpackages8 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B207")); // Example offset   
uintptr_t dunkpackages9 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B208")); // Example offset   
uintptr_t dunkpackages10 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B209")); // Example offset   
uintptr_t dunkpackages11 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B20A")); // Example offset   
uintptr_t dunkpackages12 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B20B")); // Example offset   
uintptr_t dunkpackages13 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B20C")); // Example offset   
uintptr_t dunkpackages14 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B20D")); // Example offset   
uintptr_t dunkpackages15 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B20E")); // Example offset   

uintptr_t stat = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2A4"));
uintptr_t stat2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2A8"));
uintptr_t stat3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2AC"));
uintptr_t stat4 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B0"));
uintptr_t stat5 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B4"));
uintptr_t stat6 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B8"));
uintptr_t stat7 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BC"));
uintptr_t stat8 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C0"));
uintptr_t stat9 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C4"));
uintptr_t stat10 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C8"));
uintptr_t stat11 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CC"));
uintptr_t stat12 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D0"));
uintptr_t stat13 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D4"));
uintptr_t stat14 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D8"));
uintptr_t stat15 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DC"));
uintptr_t stat16 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E0"));
uintptr_t stat17 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E4"));
uintptr_t stat18 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E8"));
uintptr_t stat19 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2EC"));
uintptr_t stat20 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F0"));
uintptr_t stat21 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F4"));
uintptr_t stat22 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F8"));
uintptr_t stat23 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FC"));
uintptr_t stat24 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B300"));

//attributes
uintptr_t ovr1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B4")); // Example offset   
uintptr_t ovr2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B5")); // Example offset   
uintptr_t ovr3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B6")); // Example offset   
uintptr_t ovr4 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B7")); // Example offset   
uintptr_t ovr5 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2B8")); // Example offset   
uintptr_t ovr6 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BA")); // Example offset   
uintptr_t ovr7 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BB")); // Example offset   
uintptr_t ovr8 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BC")); // Example offset   
uintptr_t ovr9 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BD")); // Example offset   
uintptr_t ovr10 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BE")); // Example offset   
uintptr_t ovr11 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2BF")); // Example offset   
uintptr_t ovr12 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C0")); // Example offset   
uintptr_t ovr13 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C1")); // Example offset   
uintptr_t ovr14 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C2")); // Example offset   
uintptr_t ovr15 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C3")); // Example offset   
uintptr_t ovr16 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C4")); // Example offset   
uintptr_t ovr17 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C5")); // Example offset   
uintptr_t ovr18 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C6")); // Example offset   
uintptr_t ovr19 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C7")); // Example offset   
uintptr_t ovr20 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C8")); // Example offset   
uintptr_t ovr21 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2C9")); // Example offset   
uintptr_t ovr22 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CA")); // Example offset   
uintptr_t ovr23 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CB")); // Example offset   
uintptr_t ovr24 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CC")); // Example offset   
uintptr_t ovr25 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CD")); // Example offset   
uintptr_t ovr26 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CE")); // Example offset   
uintptr_t ovr27 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2CF")); // Example offset   
uintptr_t ovr28 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D0")); // Example offset   
uintptr_t ovr29 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D1")); // Example offset   
uintptr_t ovr30 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D2")); // Example offset   
uintptr_t ovr31 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D3")); // Example offset   
uintptr_t ovr32 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D4")); // Example offset   
uintptr_t ovr33 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D5")); // Example offset   
uintptr_t ovr34 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D6")); // Example offset   
uintptr_t ovr35 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D7")); // Example offset   
uintptr_t ovr36 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D8")); // Example offset   
uintptr_t ovr37 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2D9")); // Example offset   
uintptr_t ovr38 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DA")); // Example offset   
uintptr_t ovr39 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DB")); // Example offset   
uintptr_t ovr40 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DC")); // Example offset   
uintptr_t ovr41 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DD")); // Example offset   
//tendencies
uintptr_t ovr42 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DE")); // Example offset   
uintptr_t ovr43 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2DF")); // Example offset   
uintptr_t ovr44 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E0")); // Example offset   //44
uintptr_t ovr45 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E1")); // Example offset   
uintptr_t ovr46 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E2")); // Example offset   
uintptr_t ovr47 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E3")); // Example offset   
uintptr_t ovr48 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E4")); // Example offset   //44
uintptr_t ovr49 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E5")); // Example offset   
uintptr_t ovr50 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E6")); // Example offset   
uintptr_t ovr51 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E7")); // Example offset   
uintptr_t ovr52 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E8")); // Example offset   //44
uintptr_t ovr53 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2E9")); // Example offset   
uintptr_t ovr54 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2EA")); // Example offset   
uintptr_t ovr55 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2EB")); // Example offset   
uintptr_t ovr56 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2EC")); // Example offset   //44
uintptr_t ovr57 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2ED")); // Example offset   
uintptr_t ovr58 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2EE")); // Example offset   
uintptr_t ovr59 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2EF")); // Example offset   
uintptr_t ovr60 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F0")); // Example offset   //44
uintptr_t ovr61 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F1")); // Example offset   
uintptr_t ovr62 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F2")); // Example offset   
uintptr_t ovr63 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F3")); // Example offset   
uintptr_t ovr64 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F4")); // Example offset   //44
uintptr_t ovr65 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F5")); // Example offset   
uintptr_t ovr66 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F6")); // Example offset   
uintptr_t ovr67 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F7")); // Example offset   
uintptr_t ovr68 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F8")); // Example offset   //44
uintptr_t ovr69 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2F9")); // Example offset   
uintptr_t ovr70 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FA")); // Example offset   
uintptr_t ovr71 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FB")); // Example offset   
uintptr_t ovr72 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FC")); // Example offset   //44
uintptr_t ovr73 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FD")); // Example offset   
uintptr_t ovr74 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FE")); // Example offset   
uintptr_t ovr75 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2FF")); // Example offset   
uintptr_t ovr76 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B300")); // Example offset   //44
uintptr_t ovr77 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B301")); // Example offset   
uintptr_t ovr78 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B302")); // Example offset   
uintptr_t ovr79 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B303")); // Example offset   
uintptr_t ovr80 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B304")); // Example offset   //44
uintptr_t ovr81 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B305")); // Example offset   
uintptr_t ovr82 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B306")); // Example offset   
uintptr_t ovr83 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B307")); // Example offset   
uintptr_t ovr84 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B308")); // Example offset   //44
uintptr_t ovr85 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B309")); // Example offset   
uintptr_t ovr86 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B30A")); // Example offset   
uintptr_t ovr87 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B30B")); // Example offset   
uintptr_t ovr88 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B30C")); // Example offset   //44
uintptr_t ovr89 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B30D")); // Example offset   
uintptr_t ovr90 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B30E")); // Example offset   
uintptr_t ovr91 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B30F")); // Example offset   
uintptr_t ovr92 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B310")); // Example offset   //44
uintptr_t ovr93 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B311")); // Example offset   
uintptr_t ovr94 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B312")); // Example offset   
uintptr_t ovr95 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B313")); // Example offset   
uintptr_t ovr96 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B314")); // Example offset   
uintptr_t ovr97 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B315")); // Example offset   
uintptr_t ovr98 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B316")); // Example offset   
uintptr_t ovr99 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B317")); // Example offset   
uintptr_t ovr100 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B318")); // Example offset   //44  
//badges
uintptr_t bad = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B318")); // Example offset   
uintptr_t bad2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B319"));
uintptr_t bad3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B31A"));
uintptr_t bad4 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B31B"));
uintptr_t bad5 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B31C"));
uintptr_t bad6 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B31D"));
uintptr_t bad7 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B31E"));
uintptr_t bad8 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B31F"));
uintptr_t bad9 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B320"));
uintptr_t bad10 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B321"));
uintptr_t bad11 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B322"));
uintptr_t bad12 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B323"));

uintptr_t verticaldunk = getAbsoluteAddress(targetLibName, string2Offset("0x2005f18")); // Example offset   
uintptr_t faceid = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B14A")); // Example offset   
 uintptr_t faceoption1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B114")); // Example offset       
 uintptr_t faceoption2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1C8")); // Example offset       
 uintptr_t awaydefender = getAbsoluteAddress(targetLibName, string2Offset("0x20053BC")); // Example offset
 uintptr_t teamid = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DCA0")); // Example offset
 uintptr_t ballhandling = getAbsoluteAddress(targetLibName, string2Offset("0x2083D64")); // Example offset
 uintptr_t hand = getAbsoluteAddress(targetLibName, string2Offset("0x20db3a0")); // Example offset
 uintptr_t stats = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B2A4")); // Example offset
 uintptr_t ballhandling2 = getAbsoluteAddress(targetLibName, string2Offset("0x2083D54")); // Example offset
 
 // dark crowd
 uintptr_t crowd1 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
 uintptr_t crowd2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
 uintptr_t crowd3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));
 uintptr_t crowd4 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BB4"));
 uintptr_t crowd5 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BB8"));
 uintptr_t crowd6 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BBC"));
 
 //hd crowd
 uintptr_t crowds1 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA0"));
 uintptr_t crowds2 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA4"));
 uintptr_t crowds3 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BA8"));
 uintptr_t crowds4 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BB4"));
 uintptr_t crowds5 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BB8"));
 uintptr_t crowds6 = getAbsoluteAddress(targetLibName, string2Offset("0x3D97BBC"));
 
 //team id
 uintptr_t team = getAbsoluteAddress(targetLibName, string2Offset("0x2E6DCA0")); 
 //retro
 
 uintptr_t retro1 = getAbsoluteAddress(targetLibName, string2Offset("0x2081204")); // Example offset   
 uintptr_t retro2 = getAbsoluteAddress(targetLibName, string2Offset("0x2081208")); // Example offset       
 uintptr_t retro3 = getAbsoluteAddress(targetLibName, string2Offset("0x208120C")); // Example offset       
 uintptr_t retro4 = getAbsoluteAddress(targetLibName, string2Offset("0x2081210")); // Example offset
 uintptr_t retro5 = getAbsoluteAddress(targetLibName, string2Offset("0x2081214")); // Example offset
 uintptr_t retro6 = getAbsoluteAddress(targetLibName, string2Offset("0x2081218")); // Example offset
 uintptr_t retro7 = getAbsoluteAddress(targetLibName, string2Offset("0x208121C")); // Example offset
 uintptr_t retro8 = getAbsoluteAddress(targetLibName, string2Offset("0x2081220")); // Example offset   
 uintptr_t retro9 = getAbsoluteAddress(targetLibName, string2Offset("0x2081224")); // Example offset       
 uintptr_t retro10 = getAbsoluteAddress(targetLibName, string2Offset("0x2081228")); // Example offset       
 uintptr_t retro11 = getAbsoluteAddress(targetLibName, string2Offset("0x208122C")); // Example offset
 uintptr_t retro12 = getAbsoluteAddress(targetLibName, string2Offset("0x2081230")); // Example offset
 uintptr_t retro13 = getAbsoluteAddress(targetLibName, string2Offset("0x2081234")); // Example offset
 uintptr_t retro14 = getAbsoluteAddress(targetLibName, string2Offset("0x2081238")); // Example offset
 uintptr_t retro15 = getAbsoluteAddress(targetLibName, string2Offset("0x208124C")); // Example offset
 uintptr_t retro16 = getAbsoluteAddress(targetLibName, string2Offset("0x2081240")); // Example offset
 uintptr_t retro17 = getAbsoluteAddress(targetLibName, string2Offset("0x2081244")); // Example offset
 uintptr_t retro18 = getAbsoluteAddress(targetLibName, string2Offset("0x2081248")); // Example offset
 uintptr_t retro19 = getAbsoluteAddress(targetLibName, string2Offset("0x208124C")); // Example offset
 uintptr_t retro20 = getAbsoluteAddress(targetLibName, string2Offset("0x2081250")); // Example offset
 
 
 
 //access
 uintptr_t acces1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CB")); // Example offset   
 uintptr_t acces2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CE")); // Example offset       
 uintptr_t acces3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CF")); // Example offset       
 uintptr_t acces4 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D0")); // Example offset
 uintptr_t acces5 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D1")); // Example offset
 uintptr_t acces6 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D2")); // Example offset
 uintptr_t acces7 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D3")); // Example offset
 uintptr_t acces8 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D4")); // Example offset   
 uintptr_t acces9 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D5")); // Example offset       
 uintptr_t acces10 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D6")); // Example offset       
 uintptr_t acces11 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D7")); // Example offset
 uintptr_t acces12 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D9")); // Example offset
 uintptr_t acces13 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D9")); // Example offset
 uintptr_t acces14 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1DA")); // Example offset
 uintptr_t acces15 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1E0")); // Example offset
  uintptr_t acces16 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B29D")); // Ex
  
 uintptr_t acce1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CB")); // Example offset   
 uintptr_t acce2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CE")); // Example offset       
 uintptr_t acce3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CF")); // Example offset       
 uintptr_t acce4 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D0")); // Example offset
 uintptr_t acce5 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D1")); // Example offset
 uintptr_t acce6 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D2")); // Example offset
 uintptr_t acce7 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D3")); // Example offset
 uintptr_t acce8 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D4")); // Example offset   
 uintptr_t acce9 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D5")); // Example offset       
 uintptr_t acce10 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D6")); // Example offset       
 uintptr_t acce11 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D7")); // Example offset
 uintptr_t acce12 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D9")); // Example offset
 uintptr_t acce13 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1D9")); // Example offset
 uintptr_t acce14 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1DA")); // Example offset
 uintptr_t acce15 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1E0")); // Example offset
  uintptr_t acce16 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B29D")); // Example offset
 uintptr_t acce17 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B29D")); 
  //uintptr_t headband1 = getAbsoluteAddress(targetLibName, string2Offset("0x1e71cb")); // Example offset   
 //  uintptr_t headband2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1DD")); // Example offset   
 //  uintptr_t headband3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B218")); // Example offset   

uintptr_t headband = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1CB")); // Example offset   
  uintptr_t headband2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B1DD")); // Example offset   
  uintptr_t headband3 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B218")); // Example offset          
      
 
 //doublereplay
  uintptr_t replay1 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B278")); // Example offset
  uintptr_t replay2 = getAbsoluteAddress(targetLibName, string2Offset("0x2E2B27A")); // Example offset

  //AO
  uintptr_t awareness = getAbsoluteAddress(targetLibName, string2Offset("0x4e6e6b28")); // Get absolute address
  




// Structure to hold offset-value pairs
struct Patch {
    const char* offset; // Offset in string format
    const char* value;  // Value to write (in hex format)
};

// Array of patches
Patch patches[] = {
    {"0x2E2B2A4", "00000050"},
    {"0x2E2B2A8", "00000080"},
    {"0x2E2B2AC", "26130000"},
    {"0x2E2B2B0", "00000000"},
    {"0x2E2B2B4", "FFFFFFFF"},
    {"0x2E2B2B8", "FFFFFFFF"},
    {"0x2E2B2BC", "FFFFFFFF"},
    {"0x2E2B2C0", "FFFFFFFF"},
    {"0x2E2B2C4", "FFFFFFFF"},
    {"0x2E2B2C8", "FFFFFFFF"},
    {"0x2E2B2CC", "FFFFFFFF"},
    {"0x2E2B2D0", "FFFFFFFF"},
    {"0x2E2B2D4", "FFFFFFFF"},
    {"0x2E2B2D8", "FFFF87FF"},
    {"0x2E2B2DC", "FFFF6364"},
    {"0x2E2B2E0", "23332F4E"},
    {"0x2E2B2E4", "35220100"},
    {"0x2E2B2E8", "562B64FF"},
    {"0x2E2B2EC", "641B640E"},
    {"0x2E2B2F0", "04000B23"},
    {"0x2E2B2F4", "045F430E"},
    {"0x2E2B2F8", "0042FF61"},
    {"0x2E2B2FC", "01FF0000"},
    {"0x2E2B300", "00000001"},
};


Patch newpatches[] ={
{"0x2E2B2DE", "FF"},
{"0x2E2B2DF", "FF"},
{"0x2E2B2E0", "FF"},
{"0x2E2B2E1", "FF"},
{"0x2E2B2E2", "FF"},
{"0x2E2B2E3", "FF"},
{"0x2E2B2E4", "FF"},
{"0x2E2B2E5", "FF"},
{"0x2E2B2E6", "FF"},
{"0x2E2B2E7", "FF"},
{"0x2E2B2E8", "FF"},
{"0x2E2B2E9", "FF"},
{"0x2E2B2EA", "FF"},
{"0x2E2B2EB", "FF"},
{"0x2E2B2EC", "FF"},
{"0x2E2B2ED", "FF"},
{"0x2E2B2EE", "FF"},
{"0x2E2B2EF", "FF"},
{"0x2E2B2F0", "FF"},
{"0x2E2B2F1", "FF"},
{"0x2E2B2F2", "FF"},
{"0x2E2B2F3", "FF"},
{"0x2E2B2F4", "FF"},
{"0x2E2B2F5", "FF"},
{"0x2E2B2F6", "FF"},
{"0x2E2B2F7", "FF"},
{"0x2E2B2F8", "FF"},
{"0x2E2B2F9", "FF"},
{"0x2E2B2FA", "FF"},
{"0x2E2B2FB", "FF"},
{"0x2E2B2FC", "FF"},
{"0x2E2B2FD", "FF"},
{"0x2E2B2FE", "FF"},
{"0x2E2B2FF", "FF"},
{"0x2E2B300", "FF"},
{"0x2E2B301", "FF"},
{"0x2E2B302", "FF"},
{"0x2E2B303", "FF"},
{"0x2E2B304", "FF"},
{"0x2E2B305", "FF"},
{"0x2E2B306", "FF"},
{"0x2E2B307", "FF"},
{"0x2E2B308", "FF"},
{"0x2E2B309", "FF"},
{"0x2E2B30A", "FF"},
{"0x2E2B30B", "FF"},
{"0x2E2B30C", "FF"},
{"0x2E2B30D", "FF"},
{"0x2E2B30E", "FF"},
{"0x2E2B30F", "FF"},
{"0x2E2B310", "FF"},
{"0x2E2B311", "FF"},
{"0x2E2B312", "FF"},
{"0x2E2B313", "FF"},
{"0x2E2B314", "FF"},
{"0x2E2B315", "FF"},
{"0x2E2B316", "FF"},
{"0x2E2B317", "FF"},
{"0x2E2B318", "FFFFFFFF"},
{"0x2E2B31C", "FFFFFFFF"},
{"0x2E2B320", "FFFFFFFF"}
};


void patchBssOffset(uintptr_t baseAddress, uintptr_t offset, const char* value) {
    uintptr_t address = baseAddress + offset;

    uint32_t data = strtoul(value, nullptr, 16); 
    memcpy((void*)address, &data, sizeof(data)); 
}




uintptr_t stringToOffset(const char* offset) {
    return strtoul(offset, nullptr, 16); 
}


void autoPatch(const char* libName) {
    uintptr_t baseAddress = getAbsoluteAddress(libName, 0); 


    for (const auto& patch : patches) {
        uintptr_t offset = stringToOffset(patch.offset); 
        patchBssOffset(baseAddress, offset, patch.value);  
    }
    
    for (const auto& patch : newpatches) {
        uintptr_t offset = stringToOffset(patch.offset);  
        patchBssOffset(baseAddress, offset, patch.value);  
    }
    
}








