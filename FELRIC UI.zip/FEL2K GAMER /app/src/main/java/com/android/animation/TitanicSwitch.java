package com.android.animation;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.Switch;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.BitmapShader;
import android.graphics.Shader;

import java.io.IOException;


public class TitanicSwitch extends Switch {
    // callback fired at first onSizeChanged
    private AnimationSetupCallback animationSetupCallback;
    // wave shader coordinates
    private float maskX, maskY;
    // if true, the shader will display the wave
    private boolean sinking;
    // true after the first onSizeChanged
    private boolean setUp;

    // shader containing a repeated wave
    private Shader shader;
    // shader matrix
    private Matrix shaderMatrix;
    // wave drawable
    private android.graphics.drawable.Drawable wave;
    // (getHeight() - waveHeight) / 2
    private float offsetY;

    public TitanicSwitch(Context context) {
        super(context);
        init();
    }
    
   

    public TitanicSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TitanicSwitch(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        shaderMatrix = new Matrix();
    }

    public AnimationSetupCallback getAnimationSetupCallback() {
        return animationSetupCallback;
    }

    public void setAnimationSetupCallback(AnimationSetupCallback animationSetupCallback) {
        this.animationSetupCallback = animationSetupCallback;
    }

    public float getMaskX() {
        return maskX;
    }

    public void setMaskX(float maskX) {
        this.maskX = maskX;
        invalidate();
    }

    public float getMaskY() {
        return maskY;
    }

    public void setMaskY(float maskY) {
        this.maskY = maskY;
        invalidate();
    }

    public boolean isSinking() {
        return sinking;
    }

    public void setSinking(boolean sinking) {
        this.sinking = sinking;
    }

    public boolean isSetUp() {
        return setUp;
    }

    @Override
    public void setTextColor(int color) {
        super.setTextColor(color);
        createShader(getContext());
    }

    @Override
    public void setTextColor(android.content.res.ColorStateList colors) {
        super.setTextColor(colors);
        createShader(getContext());
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        createShader(getContext());

        if (!setUp) {
            setUp = true;
            if (animationSetupCallback != null) {
                animationSetupCallback.onSetupAnimation(TitanicSwitch.this);
            }
        }
    }
    
    
    private void createShader(Context context) {
        try {
            // Get the text color (you can customize this part to dynamically get colors if needed)
            int textColor = getCurrentTextColor();

            // Define a gradient color array using hex color codes (e.g., "#FF0000" for red)
            int[] gradientColors = {
                Color.parseColor("#FF0000"),  // Red
                Color.parseColor("#00FF00"),  // Green
                Color.parseColor("#0000FF")   // Blue
            };
            float[] positions = {0.0f, 0.5f, 1.0f};  // Corresponding positions for the colors

            // Create a LinearGradient shader with the hex color values
            shader = new LinearGradient(0, 0, getWidth(), 0, gradientColors, positions, Shader.TileMode.REPEAT);

            getPaint().setShader(shader);

            // Optionally, add offset for vertical wave
            offsetY = (getHeight() - getHeight()) / 2;

        } catch (Exception ex) {
            Toast.makeText(context, ex.toString(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // Modify text paint shader according to sinking state
        if (sinking && shader != null) {
            if (getPaint().getShader() == null) {
                getPaint().setShader(shader);
            }

            // Translate shader according to maskX and maskY positions
            shaderMatrix.setTranslate(maskX, maskY + offsetY);

            // Assign matrix to invalidate the shader
            shader.setLocalMatrix(shaderMatrix);
        } else {
            getPaint().setShader(null);
        }

        super.onDraw(canvas);
    }
}